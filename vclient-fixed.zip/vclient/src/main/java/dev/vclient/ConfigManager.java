package dev.vclient;

import com.google.gson.*;
import dev.vclient.module.Module;
import dev.vclient.setting.Setting;
import java.nio.file.*;
import net.fabricmc.loader.api.FabricLoader;

/** Конфиги лежат в config/vclient/<имя>.json — файл можно просто отправить другу. */
public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("vclient");

    public static void save(String name) {
        try {
            Files.createDirectories(DIR);
            JsonObject root = new JsonObject();
            for (Module m : VClient.modules.modules) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.oneShot ? false : m.enabled);
                o.addProperty("key", m.key);
                JsonObject s = new JsonObject();
                for (Setting<?> st : m.settings) s.add(st.name, st.toJson());
                o.add("settings", s);
                root.add(m.name, o);
            }
            Files.writeString(DIR.resolve(name + ".json"), GSON.toJson(root));
        } catch (Exception e) {
            VClient.LOG.error("Не удалось сохранить конфиг " + name, e);
        }
    }

    public static boolean load(String name) {
        Path f = DIR.resolve(name + ".json");
        if (!Files.exists(f)) return false;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            for (Module m : VClient.modules.modules) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting<?> st : m.settings) if (s.has(st.name)) st.fromJson(s.get(st.name));
                }
                if (o.has("enabled") && !m.oneShot) m.setEnabled(o.get("enabled").getAsBoolean());
            }
            return true;
        } catch (Exception e) {
            VClient.LOG.error("Не удалось загрузить конфиг " + name, e);
            return false;
        }
    }

    public static java.util.List<String> list() {
        try (var st = Files.list(DIR)) {
            return st.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5))
                    .sorted().toList();
        } catch (Exception e) {
            return java.util.List.of();
        }
    }
}
