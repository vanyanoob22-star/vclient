package dev.vclient.gui;

/**
 * Общий движок анимации. Время считается по кадрам и не прыгает после паузы или потери фокуса.
 * Вызывай tick() раз за кадр: повторные вызовы в пределах нескольких миллисекунд игнорируются.
 */
public final class Anim {
    private static long last = System.nanoTime();
    private static float dt = 0.016f;
    private static double clock;

    private Anim() {}

    public static void tick() {
        long now = System.nanoTime();
        float d = (now - last) / 1e9f;
        if (d < 0.002f) return;
        last = now;
        if (d > 0.1f) d = 0;               // пауза, сворачивание окна: не перескакиваем
        dt = Math.min(d, 0.05f);
        clock += dt;
    }

    /** Длительность последнего кадра в секундах. */
    public static float dt() { return dt; }

    /** Время анимаций в секундах (не идёт во время пауз). */
    public static double time() { return clock; }

    // ---- кривые (вход и выход от 0 до 1) ----
    public static float clamp01(float t) { return t < 0 ? 0 : Math.min(t, 1f); }

    public static float smooth(float t) { t = clamp01(t); return t * t * (3 - 2 * t); }

    public static float outCubic(float t) { t = clamp01(t); float u = 1 - t; return 1 - u * u * u; }

    public static float inOutCubic(float t) {
        t = clamp01(t);
        return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;
    }

    public static float outBack(float t) {
        t = clamp01(t);
        float c1 = 1.70158f, c3 = c1 + 1, u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }

    /** Кубическая кривая Безье, как в CSS: cubic-bezier(x1, y1, x2, y2). */
    public static float bezier(float x1, float y1, float x2, float y2, float t) {
        t = clamp01(t);
        float s = t;
        for (int i = 0; i < 6; i++) {
            float x = bez(x1, x2, s) - t, dx = dbez(x1, x2, s);
            if (Math.abs(dx) < 1e-5f) break;
            s -= x / dx;
        }
        return bez(y1, y2, clamp01(s));
    }

    private static float bez(float a, float b, float s) { float u = 1 - s; return 3 * u * u * s * a + 3 * u * s * s * b + s * s * s; }

    private static float dbez(float a, float b, float s) { float u = 1 - s; return 3 * u * u * a + 6 * u * s * (b - a) + 3 * s * s * (1 - b); }

    // ---- плавное приближение к цели (не зависит от частоты кадров) ----
    public static float approach(float cur, float target, float dt, float speed) {
        return cur + (target - cur) * (1 - (float) Math.exp(-speed * dt));
    }

    public static int lerpColor(int a, int b, float t) {
        t = clamp01(t);
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Критически демпфированная пружина: безопасно меняет цель на ходу, без рывков. */
    public static final class Spring {
        public float value, velocity, target;
        private final float freq;

        public Spring(float start, float freq) { this.value = start; this.target = start; this.freq = freq; }

        public float update(float dt) {
            float x = value - target, a = velocity + freq * x, e = (float) Math.exp(-freq * dt);
            value = target + (x + a * dt) * e;
            velocity = (velocity - freq * a * dt) * e;
            return value;
        }
    }
}
