package dev.vclient.gui;

import dev.vclient.VClient;
import dev.vclient.module.ChestTracker;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import static dev.vclient.gui.Draw.rrect;

/** Все предметы из запомненных сундуков в виде сетки иконок. Нажми на иконку, чтобы увидеть сундуки. */
public class ChestTrackerScreen extends Screen {
    private static final int CELL = 26, SIDE_W = 176;

    private record Cell(int x, int y, String id) { }

    private final List<Cell> cells = new ArrayList<>();
    private final Map<String, ItemStack> stacks = new HashMap<>();
    private String search = "", selected = "";
    private boolean focus;
    private float scroll;
    private int gx, gy, gw, gh;
    private int sfx, sfy, sfw;
    private int btnX, btnHy, btnCy, btnW;

    public ChestTrackerScreen() { super(Component.literal("Трекер сундуков")); }

    @Override public boolean isPauseScreen() { return false; }

    private ItemStack stack(String id) {
        return stacks.computeIfAbsent(id, k -> {
            Item it = BuiltInRegistries.ITEM.getValue(Identifier.parse(k));
            return new ItemStack(it);
        });
    }

    private String nameOf(String id) { return stack(id).getHoverName().getString(); }

    private List<Map.Entry<String, Integer>> items() {
        ChestTracker t = VClient.modules.chestTracker;
        Map<String, Integer> tot = new HashMap<>();
        for (ChestTracker.Rec r : t.records) for (var e : r.items.entrySet()) tot.merge(e.getKey(), e.getValue(), Integer::sum);
        String q = search.toLowerCase();
        List<Map.Entry<String, Integer>> out = new ArrayList<>();
        for (var e : tot.entrySet()) {
            if (q.isEmpty() || e.getKey().contains(q) || nameOf(e.getKey()).toLowerCase().contains(q)) out.add(e);
        }
        out.sort((a, b) -> b.getValue() - a.getValue());
        return out;
    }

    private static String fmt(int n) {
        if (n >= 1_000_000) return String.format("%.1fM", n / 1e6);
        if (n >= 10_000) return (n / 1000) + "k";
        if (n >= 1000) return String.format("%.1fk", n / 1000.0);
        return String.valueOf(n);
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        cells.clear();
        int pw = Math.min(width - 30, 600), ph = Math.min(height - 30, 340);
        int x0 = (width - pw) / 2, y0 = (height - ph) / 2;
        g.fill(0, 0, width, height, 0x66000000);
        rrect(g, x0, y0, pw, ph, 8, Draw.panelBg());
        Draw.badge(g, x0 + 12, y0 + 10, 14);
        g.text(font, "Трекер сундуков", x0 + 32, y0 + 13, 0xFFFFFFFF);

        sfw = 150; sfx = x0 + pw - sfw - 12; sfy = y0 + 8;
        rrect(g, sfx, sfy, sfw, 18, 5, 0xB0090910);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (search.isEmpty() && !focus) g.text(font, "Поиск предмета", sfx + 6, sfy + 5, 0xFF9A9AAA);
        else g.text(font, font.plainSubstrByWidth(search, sfw - 14, true) + (focus && blink ? "_" : ""), sfx + 6, sfy + 5, 0xFFFFFFFF);

        gx = x0 + 12; gy = y0 + 36; gw = pw - SIDE_W - 34; gh = ph - 48;
        rrect(g, gx - 4, gy - 4, gw + 8, gh + 8, 6, 0x40000000);
        List<Map.Entry<String, Integer>> list = items();
        int cols = Math.max(1, gw / CELL), rows = (list.size() + cols - 1) / cols;
        int maxScroll = Math.max(0, rows * CELL - gh);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        Map.Entry<String, Integer> hoverE = null;
        g.enableScissor(gx, gy, gx + gw, gy + gh);
        for (int i = 0; i < list.size(); i++) {
            var e = list.get(i);
            int cx = gx + (i % cols) * CELL, cy = gy + (i / cols) * CELL - (int) scroll;
            if (cy + CELL < gy || cy > gy + gh) continue;
            boolean sel = e.getKey().equals(selected);
            boolean hov = mx >= cx && mx < cx + CELL && my >= cy && my < cy + CELL && mx >= gx && mx < gx + gw && my >= gy && my < gy + gh;
            rrect(g, cx + 1, cy + 1, CELL - 2, CELL - 2, 4, sel ? Draw.ACCENT : (hov ? 0x50FFFFFF : 0x30FFFFFF));
            g.item(stack(e.getKey()), cx + 5, cy + 5);
            String c = fmt(e.getValue());
            g.text(font, c, cx + CELL - 2 - font.width(c), cy + CELL - 10, 0xFFFFFFFF);
            cells.add(new Cell(cx, cy, e.getKey()));
            if (hov) hoverE = e;
        }
        g.disableScissor();
        if (list.isEmpty()) g.text(font, "Пока пусто: открой несколько сундуков", gx + 6, gy + 8, 0xFF9A9AAA);

        drawSide(g, gx + gw + 14, gy, pw - (gx + gw + 14 - x0) - 12, gh);

        if (hoverE != null) {
            String t = nameOf(hoverE.getKey()) + "  x" + hoverE.getValue();
            int tw = font.width(t) + 10;
            int tx = Math.min(mx + 10, width - tw - 4), ty = my - 16;
            rrect(g, tx, ty, tw, 14, 5, 0xE0101015);
            g.text(font, t, tx + 5, ty + 3, 0xFFFFFFFF);
        }

        VClient.modules.cucumberCursor.render(g, mx, my);
    }

    private void drawSide(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        ChestTracker t = VClient.modules.chestTracker;
        rrect(g, x, y - 4, w, h + 8, 6, 0x40000000);
        btnX = x + 8; btnW = w - 16; btnHy = y + h - 46; btnCy = y + h - 24;
        if (selected.isEmpty()) {
            g.text(font, "Выбери предмет слева", x + 8, y + 6, 0xFF9A9AAA);
        } else {
            g.item(stack(selected), x + 8, y + 2);
            g.text(font, font.plainSubstrByWidth(nameOf(selected), w - 34), x + 28, y + 6, 0xFFFFFFFF);
            Minecraft mc = Minecraft.getInstance();
            List<ChestTracker.Rec> rs = t.chestsWith(selected);
            if (mc.player != null) {
                Vec3 me = mc.player.position();
                rs.sort((a, b) -> Double.compare(me.distanceTo(Vec3.atCenterOf(a.pos())), me.distanceTo(Vec3.atCenterOf(b.pos()))));
            }
            int ly = y + 26, shown = 0;
            for (ChestTracker.Rec r : rs) {
                if (ly > btnHy - 24) break;
                String d = mc.player == null ? "" : "  " + Math.round(mc.player.position().distanceTo(Vec3.atCenterOf(r.pos()))) + "m";
                String line = r.x + " " + r.y + " " + r.z + "  x" + r.items.get(selected) + d;
                g.text(font, font.plainSubstrByWidth(line, w - 16), x + 8, ly, 0xFFC8C8D0);
                ly += 12; shown++;
            }
            if (rs.size() > shown) g.text(font, "и ещё " + (rs.size() - shown), x + 8, ly, 0xFF9A9AAA);
        }
        boolean on = !selected.isEmpty() && selected.equals(t.highlightId);
        String b1 = on ? "Выключить подсветку" : "Подсветить в мире";
        rrect(g, btnX, btnHy, btnW, 16, 5, Draw.ACCENT_DIM);
        g.text(font, b1, btnX + (btnW - font.width(b1)) / 2, btnHy + 4, 0xFFFFFFFF);
        String b2 = "Забыть все сундуки";
        rrect(g, btnX, btnCy, btnW, 16, 5, 0xFF3A3A46);
        g.text(font, b2, btnX + (btnW - font.width(b2)) / 2, btnCy + 4, 0xFFFFFFFF);
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        ChestTracker t = VClient.modules.chestTracker;
        focus = false;
        if (in(mx, my, sfx, sfy, sfw, 18)) { focus = true; return true; }
        if (btnW > 0 && in(mx, my, btnX, btnHy, btnW, 16)) {
            t.highlightId = (!selected.isEmpty() && !selected.equals(t.highlightId)) ? selected : "";
            return true;
        }
        if (btnW > 0 && in(mx, my, btnX, btnCy, btnW, 16)) { t.clearAll(); selected = ""; return true; }
        if (in(mx, my, gx, gy, gw, gh)) {
            for (int i = cells.size() - 1; i >= 0; i--) {
                Cell c = cells.get(i);
                if (in(mx, my, c.x(), c.y(), CELL, CELL)) { selected = c.id().equals(selected) ? "" : c.id(); return true; }
            }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) (sy * CELL);
        return true;
    }

    @Override public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (focus) {
            if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); scroll = 0; }
            else if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_KP_ENTER) focus = false;
            return true;
        }
        return super.keyPressed(e);
    }

    @Override public boolean charTyped(CharacterEvent e) {
        int cp = e.codepoint();
        if (!focus || cp < 32 || cp == 127) return false;
        search += new String(Character.toChars(cp));
        scroll = 0;
        return true;
    }

    @Override public void onClose() {
        Minecraft.getInstance().gui.setScreen(new RvScreen());
    }
}
