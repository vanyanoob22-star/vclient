package dev.vclient.gui;

import dev.vclient.ConfigManager;
import dev.vclient.VClient;
import dev.vclient.module.HudModule;
import dev.vclient.module.Module;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import static dev.vclient.gui.Draw.rrect;

/** Чистый экран для расстановки HUD-блоков: тяни мышью, колёсико меняет размер, ПКМ включает и выключает. */
public class HudEditorScreen extends Screen {
    private record Box(HudModule m, int x, int y, int w, int h) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Box> boxes = new ArrayList<>();
    private HudModule drag;
    private int offX, offY;
    private int doneX, doneY, resetX, resetY;
    private static final int BW = 90, BH = 18;

    public HudEditorScreen() { super(Component.literal("Редактор HUD")); }

    @Override public boolean isPauseScreen() { return false; }

    private static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int c) {
        g.fill(x - 1, y - 1, x + w + 1, y, c);
        g.fill(x - 1, y + h, x + w + 1, y + h + 1, c);
        g.fill(x - 1, y, x, y + h, c);
        g.fill(x + w, y, x + w + 1, y + h, c);
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        boxes.clear();
        g.fill(0, 0, width, height, 0x77000000);
        for (Module m : VClient.modules.modules) {
            if (!(m instanceof HudModule h)) continue;
            int[] b = h.draw(g, true);
            if (b == null) continue;
            boxes.add(new Box(h, b[0], b[1], b[2], b[3]));
            boolean hover = mx >= b[0] && mx < b[0] + b[2] && my >= b[1] && my < b[1] + b[3];
            outline(g, b[0], b[1], b[2], b[3], (h == drag || hover) ? 0xFFA64DFF : 0x66FFFFFF);
            if (!h.enabled) {
                g.fill(b[0], b[1], b[0] + b[2], b[1] + b[3], 0xAA000000);
                g.text(font, "выкл", b[0] + 4, b[1] + b[3] / 2 - 4, 0xFFFF7777);
            }
            g.text(font, h.name + "  x" + String.format("%.1f", h.scale.f()), b[0], Math.max(0, b[1] - 11), 0xFFFFFFFF);
        }
        String hint = "Тяни блоки мышью  ·  колёсико: размер  ·  ПКМ: вкл/выкл  ·  Esc: назад";
        g.text(font, hint, (width - font.width(hint)) / 2, 8, 0xFFE0E0E8);

        doneX = width / 2 - BW - 6; doneY = height - 30;
        resetX = width / 2 + 6; resetY = height - 30;
        rrect(g, doneX, doneY, BW, BH, 5, 0xFF6F2FB5);
        g.text(font, "Готово", doneX + (BW - font.width("Готово")) / 2, doneY + 5, 0xFFFFFFFF);
        rrect(g, resetX, resetY, BW, BH, 5, 0xFF3A3A46);
        g.text(font, "Сбросить", resetX + (BW - font.width("Сбросить")) / 2, resetY + 5, 0xFFFFFFFF);

        VClient.modules.cucumberCursor.render(g, mx, my);
    }

    private static boolean inRect(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        if (inRect(mx, my, doneX, doneY, BW, BH)) { onClose(); return true; }
        if (inRect(mx, my, resetX, resetY, BW, BH)) {
            for (Module m : VClient.modules.modules) if (m instanceof HudModule h) h.resetPlacement();
            return true;
        }
        for (int i = boxes.size() - 1; i >= 0; i--) {
            Box b = boxes.get(i);
            if (!b.in(mx, my)) continue;
            if (e.button() == 1) b.m().toggle();
            else { drag = b.m(); offX = (int) mx - b.x(); offY = (int) my - b.y(); }
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (drag == null) return super.mouseDragged(e, dx, dy);
        for (Box b : boxes) {
            if (b.m() != drag) continue;
            int nx = (int) e.x() - offX, ny = (int) e.y() - offY;
            int availX = Math.max(1, width - b.w()), availY = Math.max(1, height - b.h());
            drag.posX.set(Math.max(0.0, Math.min(100.0, Math.round(nx * 100.0 / availX))));
            drag.posY.set(Math.max(0.0, Math.min(100.0, Math.round(ny * 100.0 / availY))));
            return true;
        }
        return true;
    }

    @Override public boolean mouseReleased(MouseButtonEvent e) {
        drag = null;
        return super.mouseReleased(e);
    }

    @Override public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        for (int i = boxes.size() - 1; i >= 0; i--) {
            Box b = boxes.get(i);
            if (!b.in(mx, my)) continue;
            double v = b.m().scale.get() + Math.signum(sy) * 0.1;
            b.m().scale.set(Math.max(0.5, Math.min(2.5, Math.round(v * 10) / 10.0)));
            return true;
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override public void onClose() {
        ConfigManager.save("default");
        Minecraft.getInstance().gui.setScreen(new RvScreen());
    }
}
