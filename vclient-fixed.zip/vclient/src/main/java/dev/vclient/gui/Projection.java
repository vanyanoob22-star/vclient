package dev.vclient.gui;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Проекция мировых координат на экран (рисуем поверх HUD). Точно в первом лице, приблизительно в третьем.
 * Линии рисуются сплошными полосками (по одной на строку или столбец), а не точками.
 */
public final class Projection {
    private static double ex, ey, ez, fx, fy, fz, rx, ry, rz, ux, uy, uz, tanHalf, aspect;
    public static int sw, sh, vx, vy;
    public static boolean ready;
    private static final double NEAR = 0.05, NEAR_CLIP = 0.06;

    // временные буферы, чтобы не создавать мусор каждый кадр
    private static final double[] T1 = new double[2], T2 = new double[2], LB = new double[2];
    private static final double[] QX = new double[4], QY = new double[4];
    private static final double[] CX = new double[8], CY = new double[8], CZ = new double[8];

    private Projection() {}

    private static void orient(float yaw, float pitch) {
        double y = Math.toRadians(yaw), pt = Math.toRadians(pitch);
        fx = -Math.sin(y) * Math.cos(pt);
        fy = -Math.sin(pt);
        fz = Math.cos(y) * Math.cos(pt);
        rx = -Math.cos(y); ry = 0; rz = -Math.sin(y);
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
    }

    /** Направление взгляда по углам. */
    public static Vec3 look(float yaw, float pitch) {
        double y = Math.toRadians(yaw), pt = Math.toRadians(pitch);
        return new Vec3(-Math.sin(y) * Math.cos(pt), -Math.sin(pt), Math.cos(y) * Math.cos(pt));
    }

    public static void update(float partial) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        ready = false;
        if (p == null) return;
        Vec3 eye = p.getEyePosition(partial);
        float yaw = p.getViewYRot(partial), pitch = p.getViewXRot(partial);
        CameraType ct = mc.options.getCameraType();
        boolean first = ct.isFirstPerson();
        if (ct == CameraType.THIRD_PERSON_FRONT) { yaw += 180f; pitch = -pitch; }
        orient(yaw, pitch);
        double dist = first ? 0 : 4.0;
        ex = eye.x - fx * dist; ey = eye.y - fy * dist; ez = eye.z - fz * dist;
        vx = 0; vy = 0;
        sw = mc.getWindow().getGuiScaledWidth();
        sh = mc.getWindow().getGuiScaledHeight();
        aspect = (double) sw / Math.max(1, sh);
        tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        ready = true;
    }

    /** Виртуальная камера для окна предпросмотра в меню: прямоугольник (ox, oy, w, h) на экране. */
    public static void setCamera(Vec3 eye, float yaw, float pitch, double fovDeg, int w, int h, int ox, int oy) {
        orient(yaw, pitch);
        ex = eye.x; ey = eye.y; ez = eye.z;
        sw = w; sh = h; vx = ox; vy = oy;
        aspect = (double) w / Math.max(1, h);
        tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
        ready = true;
    }

    public static double depth(double x, double y, double z) {
        return (x - ex) * fx + (y - ey) * fy + (z - ez) * fz;
    }

    /** true, если точка перед камерой. Экранные координаты кладёт в out[0], out[1]. */
    private static boolean toScreen(double x, double y, double z, double[] out) {
        double dx = x - ex, dy = y - ey, dz = z - ez;
        double cz = dx * fx + dy * fy + dz * fz;
        if (cz < NEAR) return false;
        double cx = dx * rx + dy * ry + dz * rz;
        double cy = dx * ux + dy * uy + dz * uz;
        out[0] = sw / 2.0 * (1 + cx / (cz * tanHalf * aspect)) + vx;
        out[1] = sh / 2.0 * (1 - cy / (cz * tanHalf)) + vy;
        return true;
    }

    /** {экранX, экранY, глубина} или null, если точка за камерой. */
    public static double[] project(double x, double y, double z) {
        double dx = x - ex, dy = y - ey, dz = z - ez;
        double cz = dx * fx + dy * fy + dz * fz;
        if (cz < NEAR) return null;
        double cx = dx * rx + dy * ry + dz * rz;
        double cy = dx * ux + dy * uy + dz * uz;
        double sx = sw / 2.0 * (1 + cx / (cz * tanHalf * aspect)) + vx;
        double sy = sh / 2.0 * (1 - cy / (cz * tanHalf)) + vy;
        return new double[]{sx, sy, cz};
    }

    public static double[] project(Vec3 v) { return project(v.x, v.y, v.z); }

    /** Сколько пикселей занимает 1 блок на данной глубине. */
    public static double pxPerBlock(double depth) { return (sh / 2.0) / (tanHalf * depth); }

    // ---------------- линии ----------------

    public static void line(GuiGraphicsExtractor g, Vec3 a, Vec3 b, int th, int argb) {
        line(g, a.x, a.y, a.z, b.x, b.y, b.z, th, argb);
    }

    public static void line(GuiGraphicsExtractor g, double ax, double ay, double az, double bx, double by, double bz, int th, int argb) {
        double da = depth(ax, ay, az), db = depth(bx, by, bz);
        if (da < NEAR && db < NEAR) return;
        if (da < NEAR) {
            double t = (NEAR_CLIP - da) / (db - da);
            ax += (bx - ax) * t; ay += (by - ay) * t; az += (bz - az) * t;
        } else if (db < NEAR) {
            double t = (NEAR_CLIP - db) / (da - db);
            bx += (ax - bx) * t; by += (ay - by) * t; bz += (az - bz) * t;
        }
        if (!toScreen(ax, ay, az, T1) || !toScreen(bx, by, bz, T2)) return;
        strip(g, T1[0], T1[1], T2[0], T2[1], th, argb);
    }

    private static boolean clipT(double p, double q) {
        if (p == 0) return q >= 0;
        double r = q / p;
        if (p < 0) { if (r > LB[1]) return false; if (r > LB[0]) LB[0] = r; }
        else { if (r < LB[0]) return false; if (r < LB[1]) LB[1] = r; }
        return true;
    }

    /** Толстая линия как сплошной четырёхугольник, залитый горизонтальными (или вертикальными) полосками. */
    private static void strip(GuiGraphicsExtractor g, double x1, double y1, double x2, double y2, int th, int c) {
        double minX = vx - th, minY = vy - th, maxX = vx + sw + th, maxY = vy + sh + th;
        double dx = x2 - x1, dy = y2 - y1;
        LB[0] = 0; LB[1] = 1;
        if (!clipT(-dx, x1 - minX) || !clipT(dx, maxX - x1) || !clipT(-dy, y1 - minY) || !clipT(dy, maxY - y1)) return;
        double nx1 = x1 + dx * LB[0], ny1 = y1 + dy * LB[0], nx2 = x1 + dx * LB[1], ny2 = y1 + dy * LB[1];
        double ddx = nx2 - nx1, ddy = ny2 - ny1, len = Math.sqrt(ddx * ddx + ddy * ddy);
        if (len < 0.75) {
            int ix = (int) Math.round(nx1) - th / 2, iy = (int) Math.round(ny1) - th / 2;
            g.fill(ix, iy, ix + th, iy + th, c);
            return;
        }
        double hx = -ddy / len * th * 0.5, hy = ddx / len * th * 0.5;
        QX[0] = nx1 + hx; QY[0] = ny1 + hy;
        QX[1] = nx2 + hx; QY[1] = ny2 + hy;
        QX[2] = nx2 - hx; QY[2] = ny2 - hy;
        QX[3] = nx1 - hx; QY[3] = ny1 - hy;
        boolean shallow = Math.abs(ddx) >= Math.abs(ddy);
        double[] A = shallow ? QY : QX;   // ось, по которой идём
        double[] B = shallow ? QX : QY;   // ось, по которой берём длину полоски
        double lo = Math.min(Math.min(A[0], A[1]), Math.min(A[2], A[3]));
        double hi = Math.max(Math.max(A[0], A[1]), Math.max(A[2], A[3]));
        int from = (int) Math.floor(lo), to = (int) Math.ceil(hi);
        for (int s = from; s < to; s++) {
            double mid = s + 0.5, l = 1e18, r = -1e18;
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) & 3;
                double a0 = A[i], a1 = A[j];
                if ((a0 <= mid && a1 > mid) || (a1 <= mid && a0 > mid)) {
                    double v = B[i] + (mid - a0) / (a1 - a0) * (B[j] - B[i]);
                    if (v < l) l = v;
                    if (v > r) r = v;
                }
            }
            if (r >= l) {
                int p = (int) Math.round(l), q = (int) Math.round(r);
                if (q <= p) q = p + 1;
                if (shallow) g.fill(p, s, q, s + 1, c);
                else g.fill(s, p, s + 1, q, c);
            }
        }
    }

    // ---------------- фигуры ----------------

    /** Кольцо на плоскости XZ. Число сегментов подбирается по размеру на экране. */
    public static void ring(GuiGraphicsExtractor g, Vec3 center, double radius, int segs, int th, int argb) {
        double d = Math.max(0.5, depth(center.x, center.y, center.z));
        double pxR = radius * pxPerBlock(d);
        int n = (int) Math.max(10, Math.min(Math.min(segs, Quality.ringSegs), Math.round(2 * Math.PI * pxR / 9.0)));
        double px = center.x + radius, pz = center.z;
        for (int i = 1; i <= n; i++) {
            double a = i * 2 * Math.PI / n;
            double cx = center.x + Math.cos(a) * radius, cz = center.z + Math.sin(a) * radius;
            line(g, px, center.y, pz, cx, center.y, cz, th, argb);
            px = cx; pz = cz;
        }
    }

    /** Каркас бокса. Невидимые и крошечные боксы не рисуются или рисуются точкой. */
    public static void box(GuiGraphicsExtractor g, AABB b, int th, int argb) {
        int front = 0;
        double minSx = 1e18, maxSx = -1e18, minSy = 1e18, maxSy = -1e18;
        for (int i = 0; i < 8; i++) {
            CX[i] = (i & 1) == 0 ? b.minX : b.maxX;
            CY[i] = (i & 2) == 0 ? b.minY : b.maxY;
            CZ[i] = (i & 4) == 0 ? b.minZ : b.maxZ;
            if (toScreen(CX[i], CY[i], CZ[i], T1)) {
                front++;
                minSx = Math.min(minSx, T1[0]); maxSx = Math.max(maxSx, T1[0]);
                minSy = Math.min(minSy, T1[1]); maxSy = Math.max(maxSy, T1[1]);
            }
        }
        if (front == 0) return;
        if (front == 8) {
            if (maxSx < vx || minSx > vx + sw || maxSy < vy || minSy > vy + sh) return;
            if (maxSx - minSx < 4 && maxSy - minSy < 4) {
                g.fill((int) minSx, (int) minSy, (int) maxSx + 1, (int) maxSy + 1, argb);
                return;
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit < 8; bit <<= 1) {
                if ((i & bit) != 0) continue;
                int j = i | bit;
                line(g, CX[i], CY[i], CZ[i], CX[j], CY[j], CZ[j], th, argb);
            }
        }
    }
}
