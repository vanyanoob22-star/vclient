package dev.vclient.gui;

/** Глобальные параметры качества: их читают все эффекты, поэтому пресеты реально меняют нагрузку. */
public final class Quality {
    /** Множитель числа частиц и огоньков. */
    public static float particles = 1f;
    /** Множитель яркости свечения. */
    public static float glow = 1f;
    /** Максимум сегментов у колец. */
    public static int ringSegs = 40;
    /** Дальность отрисовки эффектов у других игроков. */
    public static double distance = 32;
    /** Детализация косметики (число перьев и т.п.). */
    public static float detail = 1f;
    /** Длина следов в точках. */
    public static int trailPoints = 100;

    private Quality() {}

    public static void apply(int level) {
        switch (level) {
            case 0 -> set(0.35f, 0.5f, 16, 16, 0.5f, 40);
            case 1 -> set(0.7f, 0.8f, 28, 24, 0.8f, 70);
            case 2 -> set(1.0f, 1.0f, 40, 32, 1.0f, 100);
            default -> set(1.6f, 1.2f, 64, 48, 1.3f, 160);
        }
    }

    private static void set(float p, float g, int r, double d, float det, int tp) {
        particles = p; glow = g; ringSegs = r; distance = d; detail = det; trailPoints = tp;
    }
}
