package dev.vclient.gui;

import dev.vclient.ConfigManager;
import dev.vclient.VClient;
import dev.vclient.module.Module;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Меню в стиле Really Visuals для Огурца (26.2): анимации, поиск, карточки, конфиги. */
public class RvScreen extends Screen {

    // ---- типы кликабельных областей ----
    static final int TAB = 0, SEARCH = 1, HEADER = 2, ARROW = 3, BOOL = 4, NUM = 5, MODE = 6, MULTI = 7,
            HUE = 8, PRESET = 9, ACTION = 10, STR = 11, BIND = 12, CFG_LOAD = 13, CFG_SAVE = 14, CFG_NAME = 15, HUDEDIT = 16, STAR = 17;

    static final class Row {
        int kind, x, y, w, h, idx;
        Module m; Setting s; String str;
    }

    static final class St { float exp, tog, hov; }

    private static final int[] PRESETS = {
        0xFF4D4D, 0xFF9F43, 0xFFE14D, 0x4DFF88, 0x4DE0FF, 0x4D7CFF, 0xB04DFF, 0xFFFFFF
    };

    private final Minecraft mc = Minecraft.getInstance();
    private final Module.Category[] cats = Module.Category.values();
    private final HashMap<Object, St> anims = new HashMap<>();
    private final Set<Module> expanded = Collections.newSetFromMap(new IdentityHashMap<>());
    private final List<Row> rows = new ArrayList<>();

    private int tab = 0;
    private float tabY = -1, scroll = 0, scrollT = 0, openT = 0, maxScroll = 0;
    private long last = System.nanoTime();
    private String search = "", cfgName = "default", cfgMsg = "";
    private boolean focusSearch, focusCfg;
    private Setting.Str focusStr;
    private Module binding;
    private Row dragging;
    private int winX, winY, winW, winH, cx, cy, cw, ch;

    public RvScreen() {
        super(Component.literal("RV"));
        snd(SoundEvents.PLAYER_LEVELUP, 2.0f);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        try { ConfigManager.save("default"); } catch (Throwable ignored) { }
        super.onClose();
    }

    // ================= утилиты =================
    static int a(int c, float al) {
        int ca = c >>> 24;
        if (ca == 0) ca = 255;
        int na = Math.max(0, Math.min(255, (int) (ca * al)));
        return (na << 24) | (c & 0xFFFFFF);
    }

    static int lerpC(int c1, int c2, float t) {
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (r << 16) | (g << 8) | b;
    }

    static int hsv(float h, float s, float v) {
        float r = 0, g = 0, b = 0;
        int i = (int) Math.floor(h * 6);
        float f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        switch (((i % 6) + 6) % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    static void rr(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0) return;
        r = UiStyle.r(r);
        r = Math.min(r, Math.min(w, h) / 2);
        g.fill(x, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, c);
        }
    }

    private int accent() { return Draw.ACCENT | 0xFF000000; }

    private String fit(String t, int maxW) {
        if (mc.font.width(t) <= maxW) return t;
        int n = t.length();
        while (n > 0 && mc.font.width(t.substring(0, n) + "..") > maxW) n--;
        return t.substring(0, n) + "..";
    }

    private St an(Object o) { return anims.computeIfAbsent(o, k -> new St()); }

    private void snd(SoundEvent e, float pitch) {
        if (!UiStyle.sounds) return;
        try { mc.getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, 0.35f)); } catch (Throwable ignored) { }
    }

    private static String catName(Module.Category c) {
        switch (c.name()) {
            case "VISUALS": return "Визуалы";
            case "HUD": return "HUD";
            case "COMBAT": return "Бой";
            case "UTILITIES": return "Утилиты";
            case "SERVER": return "Сервер";
            case "MARKERS": return "Метки";
            case "SETTINGS": return "Тема";
            case "COSMETICS": return "Косметика";
            case "MEMES": return "Мемы";
            default: return c.name();
        }
    }

    private static String keyName(int k) {
        if (k <= 0) return "—";
        String n = null;
        try { n = GLFW.glfwGetKeyName(k, 0); } catch (Throwable ignored) { }
        return n != null ? n.toUpperCase() : "K" + k;
    }

    private List<Module> visibleModules() {
        List<Module> out = new ArrayList<>();
        String q = search.toLowerCase().trim();
        for (Object o : VClient.modules.modules) {
            Module m = (Module) o;
            if (!q.isEmpty()) {
                String d = m.description == null ? "" : m.description.toLowerCase();
                if (m.name.toLowerCase().contains(q) || d.contains(q)) out.add(m);
            } else if (tab < cats.length && m.category == cats[tab]) out.add(m);
            else if (tab == cats.length && UiStyle.isFav(m.name)) out.add(m);
        }
        return out;
    }

    private int settingHeight(Setting s) {
        if (s instanceof Setting.Num) return 22;
        if (s instanceof Setting.Multi) return 14 + 13 * ((Setting.Multi) s).options.size();
        if (s instanceof Setting.Color) return 44;
        return 16;
    }

    private int bodyHeight(Module m) {
        int h = 16; // бинд
        for (Object o : m.settings) h += settingHeight((Setting) o);
        int ph = m.previewHeight();
        return h + 6 + (ph > 0 ? ph + 6 : 0);
    }

    private Row row(int kind, int x, int y, int w, int h) {
        Row r = new Row();
        r.kind = kind; r.x = x; r.y = y; r.w = w; r.h = h;
        rows.add(r);
        return r;
    }

    // ================= рендер =================
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        dt *= UiStyle.anim;
        last = now;
        openT += (1 - openT) * Math.min(1f, dt * 11f);
        if (!UiStyle.openAnim) openT = 1f;
        float ease = 1 - (float) Math.pow(1 - Math.min(1f, openT), 3);

        winW = Math.min(width - 16, Math.max(300, Math.round(width * UiStyle.menuW)));
        winH = Math.min(height - 16, Math.max(220, Math.round(height * UiStyle.menuH)));
        winX = (width - winW) / 2;
        winY = (height - winH) / 2;
        int side = UiStyle.side;
        cx = winX + side + 10;
        cy = winY + 40;
        cw = winW - side - 20;
        ch = winH - 50;
        rows.clear();

        g.fill(0, 0, width, height, a(0x000000, 0.45f * ease));

        float sc = 0.92f + 0.08f * ease;
        float pcx = width / 2f, pcy = height / 2f;
        g.pose().pushMatrix();
        g.pose().translate(pcx, pcy);
        g.pose().scale(sc, sc);
        g.pose().translate(-pcx, -pcy);

        int acc = accent();
        // окно
        rr(g, winX, winY, winW, winH, 8, a(0x0F1117, 0.96f * ease));
        rr(g, winX, winY, side, winH, 8, a(0x161922, 0.98f * ease));
        g.fill(winX + side - 8, winY, winX + side, winY + winH, a(0x161922, 0.98f * ease));

        // логотип
        rr(g, winX + 12, winY + 12, 20, 20, 6, a(acc, ease));
        g.text(mc.font, "RV", winX + 16, winY + 18, a(0xFFFFFF, ease));
        g.text(mc.font, "Огурец", winX + 38, winY + 14, a(0xFFFFFF, ease));
        g.text(mc.font, "RV Edition", winX + 38, winY + 24, a(0x8A90A0, ease));

        // вкладки
        int ty = winY + 46;
        int tabCount = cats.length + 2;
        int step = Math.max(15, Math.min(22, (winH - 96) / tabCount));
        if (tabY < 0) tabY = ty;
        float targetY = ty + tab * step;
        tabY += (targetY - tabY) * Math.min(1f, dt * 14f);
        rr(g, winX + 8, (int) tabY, side - 16, step - 2, 5, a(acc, 0.18f * ease));
        rr(g, winX + 8, (int) tabY + 3, 2, step - 8, 1, a(acc, ease));
        for (int i = 0; i < tabCount; i++) {
            int y = ty + i * step;
            String n = i < cats.length ? catName(cats[i]) : i == cats.length ? "Избранное" : "Конфиги";
            Row r = row(TAB, winX + 8, y, side - 16, step - 2);
            r.idx = i;
            boolean hov = mx >= r.x && mx < r.x + r.w && my >= r.y && my < r.y + r.h;
            St ta = an(r.idx + "tab");
            ta.hov += ((hov ? 1 : 0) - ta.hov) * Math.min(1f, dt * 14f);
            int col = lerpC(0x8A90A0, 0xFFFFFF, (i == tab ? 1f : ta.hov));
            g.text(mc.font, n, winX + 18 + (int) (ta.hov * 2), y + (step - 10) / 2, a(col, ease));
        }

        // кнопка редактора HUD
        {
            int bx = winX + 8, by = winY + winH - 28, bw = side - 16;
            boolean hv = mx >= bx && mx < bx + bw && my >= by && my < by + 20;
            St ha = an("hudedit");
            ha.hov += ((hv ? 1 : 0) - ha.hov) * Math.min(1f, dt * 14f);
            rr(g, bx, by, bw, 20, 5, a(acc, (0.18f + 0.22f * ha.hov) * ease));
            String bt = "Редактор HUD";
            g.text(mc.font, bt, bx + (bw - mc.font.width(bt)) / 2, by + 6, a(0xFFFFFF, ease));
            row(HUDEDIT, bx, by, bw, 20);
        }

        // поиск
        int sx = cx, sy = winY + 10, sw = cw, sh = 22;
        rr(g, sx, sy, sw, sh, 6, a(focusSearch ? 0x232838 : 0x1A1E29, ease));
        if (focusSearch) rr(g, sx, sy + sh - 2, sw, 2, 1, a(acc, ease));
        Row sr = row(SEARCH, sx, sy, sw, sh);
        boolean caret = focusSearch && (System.currentTimeMillis() / 500) % 2 == 0;
        String st = search.isEmpty() && !focusSearch ? "Поиск модулей..." : search + (caret ? "_" : "");
        g.text(mc.font, st, sx + 8, sy + 7, a(search.isEmpty() ? 0x6C7283 : 0xFFFFFF, ease));
        g.text(mc.font, VClient.modules.modules.size() + " модулей", sx + sw - 6 - mc.font.width(VClient.modules.modules.size() + " модулей"), sy + 7, a(0x6C7283, ease));

        // контент
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        int y = cy - (int) scroll;
        int total;
        if (tab > cats.length && search.trim().isEmpty()) {
            y = drawConfigs(g, mx, my, dt, ease, y);
        } else {
            for (Module m : visibleModules()) y = drawCard(g, m, mx, my, dt, ease, y);
            if (visibleModules().isEmpty()) {
                g.text(mc.font, (tab == cats.length && search.trim().isEmpty() ? "Нажми ★ у модуля, чтобы добавить его сюда" : "Ничего не найдено"), cx + 8, cy + 8, a(0x6C7283, ease));
            }
        }
        total = y + (int) scroll - cy;
        g.disableScissor();
        maxScroll = Math.max(0, total - ch + 4);
        scrollT = Math.max(0, Math.min(maxScroll, scrollT));
        scroll += (scrollT - scroll) * Math.min(1f, dt * 16f);

        // скроллбар
        if (maxScroll > 0) {
            int bh = Math.max(16, (int) (ch * (ch / (float) total)));
            int by = cy + (int) ((ch - bh) * (scroll / maxScroll));
            rr(g, winX + winW - 6, by, 3, bh, 1, a(acc, 0.6f * ease));
        }
        g.pose().popMatrix();
    }

    private int drawCard(GuiGraphicsExtractor g, Module m, int mx, int my, float dt, float ease, int y) {
        St an = an(m);
        boolean open = expanded.contains(m);
        int body = bodyHeight(m);
        an.exp += ((open ? 1 : 0) - an.exp) * Math.min(1f, dt * 14f);
        an.tog += ((m.enabled ? 1 : 0) - an.tog) * Math.min(1f, dt * 16f);
        int hh = UiStyle.compact ? 22 : 26;
        int bodyVis = (int) (body * an.exp);
        int cardH = hh + bodyVis;
        int acc = accent();
        boolean inView = y + cardH >= cy && y <= cy + ch;

        if (inView) {
            boolean hov = mx >= cx && mx < cx + cw && my >= y && my < y + hh && my >= cy && my < cy + ch;
            an.hov += ((hov ? 1 : 0) - an.hov) * Math.min(1f, dt * 14f);
            rr(g, cx, y, cw, cardH, 6, a(lerpC(0x171B26, 0x1D2230, an.hov), ease));
            if (an.tog > 0.01f) rr(g, cx, y + 5, 2, hh - 10, 1, a(acc, an.tog * ease));
            g.text(mc.font, m.name, cx + 10, y + (UiStyle.compact ? 7 : 5), a(lerpC(0xC8CCD6, 0xFFFFFF, an.tog), ease));
            String d = m.description == null ? "" : m.description;
            if (!d.isEmpty() && !UiStyle.compact) g.text(mc.font, fit(d, cw - 100), cx + 10, y + 15, a(0x6C7283, ease));
            // тумблер
            int tx = cx + cw - 56, tY = y + (hh - 11) / 2;
            rr(g, tx, tY, 24, 11, 5, a(lerpC(0x363B49, acc & 0xFFFFFF, an.tog), ease));
            rr(g, tx + 2 + (int) (13 * an.tog), tY + 2, 7, 7, 3, a(0xFFFFFF, ease));
            // стрелка
            g.text(mc.font, open ? "v" : ">", cx + cw - 18, y + (hh - 8) / 2, a(0x8A90A0, ease));
            row(HEADER, cx, y, cw - 26, hh).m = m;
            row(ARROW, cx + cw - 26, y, 26, hh).m = m;
            boolean fav = UiStyle.isFav(m.name);
            g.text(mc.font, fav ? "★" : "☆", cx + cw - 76, y + (hh - 8) / 2, a(fav ? 0xFFD54D : 0x6C7283, ease));
            row(STAR, cx + cw - 82, y, 22, hh).m = m;
        }

        if (an.exp > 0.02f && inView) {
            g.enableScissor(cx, Math.max(cy, y + hh), cx + cw, Math.min(cy + ch, y + hh + bodyVis));
            drawBody(g, m, mx, my, ease * an.exp, y + hh);
            g.disableScissor();
        } else if (open) {
            // всё равно регистрируем высоту (строки вне экрана не нужны)
        }
        return y + cardH + 4;
    }

    private void drawBody(GuiGraphicsExtractor g, Module m, int mx, int my, float al, int y0) {
        int x = cx + 10, w = cw - 20, y = y0 + 2, acc = accent();
        // бинд
        {
            boolean b = binding == m;
            g.text(mc.font, "Бинд", x, y + 4, a(0xC8CCD6, al));
            String t = b ? "нажми клавишу..." : "[" + keyName(m.key) + "]";
            int tw = mc.font.width(t);
            rr(g, x + w - tw - 10, y, tw + 10, 14, 4, a(b ? acc : 0x252A38, al * (b ? 0.35f : 1f)));
            g.text(mc.font, t, x + w - tw - 5, y + 3, a(0xFFFFFF, al));
            row(BIND, x + w - tw - 10, y, tw + 10, 14).m = m;
            y += 16;
        }
        for (Object o : m.settings) {
            Setting s = (Setting) o;
            int h = settingHeight(s);
            if (s instanceof Setting.Bool) {
                Setting.Bool b = (Setting.Bool) s;
                boolean on = (Boolean) b.get();
                St sa = an(s);
                sa.tog += ((on ? 1 : 0) - sa.tog) * 0.25f;
                g.text(mc.font, s.name, x, y + 4, a(0xC8CCD6, al));
                int tx = x + w - 22;
                rr(g, tx, y + 2, 20, 10, 5, a(lerpC(0x363B49, acc & 0xFFFFFF, sa.tog), al));
                rr(g, tx + 2 + (int) (10 * sa.tog), y + 4, 6, 6, 3, a(0xFFFFFF, al));
                Row r = row(BOOL, x, y, w, h); r.s = s;
            } else if (s instanceof Setting.Num) {
                Setting.Num n = (Setting.Num) s;
                g.text(mc.font, s.name, x, y + 1, a(0xC8CCD6, al));
                String v = s.display();
                g.text(mc.font, v, x + w - mc.font.width(v), y + 1, a(0x9AA0AE, al));
                int bw = w, by = y + 14;
                rr(g, x, by, bw, 4, 2, a(0x2A2F3E, al));
                int fw = (int) (bw * Math.max(0, Math.min(1, n.frac())));
                if (fw > 0) rr(g, x, by, Math.max(4, fw), 4, 2, a(acc, al));
                rr(g, x + Math.max(0, fw - 3), by - 2, 6, 8, 3, a(0xFFFFFF, al));
                Row r = row(NUM, x, y + 8, w, 14); r.s = s;
            } else if (s instanceof Setting.Mode) {
                g.text(mc.font, s.name, x, y + 4, a(0xC8CCD6, al));
                String v = ((Setting.Mode) s).current();
                int tw = mc.font.width(v);
                rr(g, x + w - tw - 12, y + 1, tw + 12, 13, 4, a(0x252A38, al));
                g.text(mc.font, v, x + w - tw - 6, y + 4, a(acc, al));
                Row r = row(MODE, x, y, w, h); r.s = s;
            } else if (s instanceof Setting.Multi) {
                Setting.Multi mu = (Setting.Multi) s;
                g.text(mc.font, s.name, x, y + 2, a(0xC8CCD6, al));
                int yy = y + 14;
                for (int i = 0; i < mu.options.size(); i++) {
                    String opt = String.valueOf(mu.options.get(i));
                    boolean on = mu.has(opt);
                    rr(g, x + 4, yy + 1, 9, 9, 3, a(on ? acc : 0x2A2F3E, al));
                    g.text(mc.font, opt, x + 18, yy + 2, a(on ? 0xFFFFFF : 0x8A90A0, al));
                    Row r = row(MULTI, x, yy, w, 13); r.s = s; r.str = opt;
                    yy += 13;
                }
            } else if (s instanceof Setting.Color) {
                Setting.Color c = (Setting.Color) s;
                g.text(mc.font, s.name, x, y + 2, a(0xC8CCD6, al));
                rr(g, x + w - 24, y, 24, 12, 4, a(c.argb() | 0xFF000000, al));
                int hy = y + 16, hw = w;
                for (int i = 0; i < hw; i += 2) g.fill(x + i, hy, x + Math.min(hw, i + 2), hy + 8, a(hsv(i / (float) hw, 0.85f, 1f), al));
                Row hr = row(HUE, x, hy - 2, w, 12); hr.s = s;
                int py = y + 28, pw = (w - 7 * 4) / 8;
                for (int i = 0; i < 8; i++) {
                    int px = x + i * (pw + 4);
                    rr(g, px, py, pw, 11, 3, a(PRESETS[i], al));
                    Row pr = row(PRESET, px, py, pw, 11); pr.s = s; pr.idx = i;
                }
            } else if (s instanceof Setting.Action) {
                rr(g, x, y, w, 14, 4, a(acc, 0.25f * al));
                int tw = mc.font.width(s.name);
                g.text(mc.font, s.name, x + (w - tw) / 2, y + 3, a(0xFFFFFF, al));
                Row r = row(ACTION, x, y, w, 14); r.s = s;
            } else if (s instanceof Setting.Str) {
                Setting.Str st = (Setting.Str) s;
                g.text(mc.font, s.name, x, y + 4, a(0xC8CCD6, al));
                boolean f = focusStr == st;
                String v = String.valueOf(st.get()) + (f && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                int bw = Math.min(w - 60, Math.max(50, mc.font.width(v) + 10));
                rr(g, x + w - bw, y, bw, 14, 4, a(f ? 0x2A3040 : 0x252A38, al));
                g.text(mc.font, fit(v, bw - 8), x + w - bw + 4, y + 3, a(0xFFFFFF, al));
                Row r = row(STR, x + w - bw, y, bw, 14); r.s = s;
            } else {
                g.text(mc.font, s.name, x, y + 4, a(0xC8CCD6, al));
            }
            y += h;
        }
        int pvh = m.previewHeight();
        if (pvh > 0) m.drawPreview(g, x, y + 2, w, pvh);
    }

    private int drawConfigs(GuiGraphicsExtractor g, int mx, int my, float dt, float ease, int y) {
        int acc = accent();
        rr(g, cx, y, cw, 28, 6, a(0x171B26, ease));
        g.text(mc.font, "Имя:", cx + 10, y + 10, a(0xC8CCD6, ease));
        String nm = cfgName + (focusCfg && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        rr(g, cx + 40, y + 6, cw - 140, 16, 4, a(focusCfg ? 0x2A3040 : 0x252A38, ease));
        g.text(mc.font, nm, cx + 46, y + 10, a(0xFFFFFF, ease));
        row(CFG_NAME, cx + 40, y + 6, cw - 140, 16);
        rr(g, cx + cw - 92, y + 6, 84, 16, 4, a(acc, 0.3f * ease));
        g.text(mc.font, "Сохранить", cx + cw - 92 + (84 - mc.font.width("Сохранить")) / 2, y + 10, a(0xFFFFFF, ease));
        row(CFG_SAVE, cx + cw - 92, y + 6, 84, 16);
        y += 32;
        if (!cfgMsg.isEmpty()) {
            g.text(mc.font, cfgMsg, cx + 4, y, a(0x9AA0AE, ease));
            y += 12;
        }
        List<?> list;
        try { list = ConfigManager.list(); } catch (Throwable t) { list = new ArrayList<>(); }
        for (Object o : list) {
            String n = String.valueOf(o);
            boolean hov = mx >= cx && mx < cx + cw && my >= y && my < y + 22;
            St ca = an("cfg" + n);
            ca.hov += ((hov ? 1 : 0) - ca.hov) * Math.min(1f, dt * 14f);
            rr(g, cx, y, cw, 22, 6, a(lerpC(0x171B26, 0x1D2230, ca.hov), ease));
            g.text(mc.font, n, cx + 10, y + 7, a(0xFFFFFF, ease));
            g.text(mc.font, "загрузить", cx + cw - 10 - mc.font.width("загрузить"), y + 7, a(acc, ease));
            row(CFG_LOAD, cx, y, cw, 22).str = n;
            y += 26;
        }
        if (list.isEmpty()) g.text(mc.font, "Сохранённых конфигов нет", cx + 4, y + 2, a(0x6C7283, ease));
        return y + 4;
    }

    // ================= ввод =================
    private void unfocus() { focusSearch = false; focusCfg = false; focusStr = null; binding = null; }

    private void setHue(Setting.Color c, int rgb) {
        String cur = c.hex();
        boolean hash = cur.startsWith("#");
        String body = cur.replace("#", "");
        String out = String.format("%06X", rgb & 0xFFFFFF);
        if (body.length() == 8) out = body.substring(0, 2) + out;
        c.setHex((hash ? "#" : "") + out);
    }

    private void applySlider(Row r, double mx) {
        Setting.Num n = (Setting.Num) r.s;
        double f = Math.max(0, Math.min(1, (mx - r.x) / (double) r.w));
        double v = n.min + f * (n.max - n.min);
        if (n.step > 0) v = Math.round(v / n.step) * n.step;
        v = Math.max(n.min, Math.min(n.max, v));
        n.set(Double.valueOf(v));
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        int btn = e.button();
        boolean inContent = mx >= cx && mx < cx + cw && my >= cy && my < cy + ch;
        for (int i = rows.size() - 1; i >= 0; i--) {
            Row r = rows.get(i);
            if (mx < r.x || mx >= r.x + r.w || my < r.y || my >= r.y + r.h) continue;
            if (r.kind != TAB && r.kind != SEARCH && !inContent) continue;
            boolean wasBinding = binding != null;
            unfocus();
            switch (r.kind) {
                case TAB:
                    if (tab != r.idx) { tab = r.idx; scroll = scrollT = 0; search = ""; snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.6f); }
                    break;
                case SEARCH: focusSearch = true; break;
                case HUDEDIT: mc.gui.setScreen(new HudEditorScreen()); break;
                case HEADER:
                    if (btn == 1) { toggleExpand(r.m); }
                    else if (btn == 0) { r.m.toggle(); snd(r.m.enabled ? SoundEvents.EXPERIENCE_ORB_PICKUP : SoundEvents.CROP_BREAK, r.m.enabled ? 1.9f : 1.2f); }
                    break;
                case ARROW: toggleExpand(r.m); break;
                case STAR: UiStyle.toggleFav(r.m.name); snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.8f); break;
                case BOOL: ((Setting.Bool) r.s).toggle(); snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.7f); break;
                case NUM: dragging = r; applySlider(r, mx); break;
                case MODE: {
                    Setting.Mode md = (Setting.Mode) r.s;
                    int n = md.options.size();
                    int cur = (Integer) md.get();
                    md.setIndex(((cur + (btn == 1 ? -1 : 1)) % n + n) % n);
                    snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.4f);
                    break;
                }
                case MULTI: ((Setting.Multi) r.s).toggle(r.str); snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.7f); break;
                case HUE: dragging = r; setHue((Setting.Color) r.s, hsv((float) Math.max(0, Math.min(0.999, (mx - r.x) / r.w)), 0.85f, 1f)); break;
                case PRESET: setHue((Setting.Color) r.s, PRESETS[r.idx]); snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.8f); break;
                case ACTION: ((Setting.Action) r.s).run(); snd(SoundEvents.PLAYER_LEVELUP, 2.0f); break;
                case STR: focusStr = (Setting.Str) r.s; break;
                case BIND: binding = wasBinding && binding == r.m ? null : r.m; if (binding == null) binding = r.m; break;
                case CFG_NAME: focusCfg = true; break;
                case CFG_SAVE:
                    try { ConfigManager.save(cfgName); cfgMsg = "Сохранено: " + cfgName; } catch (Throwable t) { cfgMsg = "Ошибка сохранения"; }
                    snd(SoundEvents.PLAYER_LEVELUP, 2.0f);
                    break;
                case CFG_LOAD:
                    try { cfgMsg = ConfigManager.load(r.str) ? "Загружено: " + r.str : "Не удалось загрузить"; } catch (Throwable t) { cfgMsg = "Ошибка загрузки"; }
                    snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5f);
                    break;
                default: break;
            }
            return true;
        }
        unfocus();
        return super.mouseClicked(e, dbl);
    }

    private void toggleExpand(Module m) {
        if (!expanded.remove(m)) expanded.add(m);
        snd(SoundEvents.EXPERIENCE_ORB_PICKUP, expanded.contains(m) ? 1.5f : 1.1f);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging != null) {
            if (dragging.kind == NUM) applySlider(dragging, e.x());
            else if (dragging.kind == HUE)
                setHue((Setting.Color) dragging.s, hsv((float) Math.max(0, Math.min(0.999, (e.x() - dragging.x) / dragging.w)), 0.85f, 1f));
            return true;
        }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        scrollT = Math.max(0, Math.min(maxScroll, scrollT - (float) sy * 28f));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (binding != null) {
            binding.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_BACKSPACE) ? 0 : k;
            binding = null;
            return true;
        }
        boolean typing = focusSearch || focusCfg || focusStr != null;
        if (typing) {
            if (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_ENTER) { unfocus(); return true; }
            if (k == GLFW.GLFW_KEY_BACKSPACE) {
                if (focusSearch && !search.isEmpty()) { search = search.substring(0, search.length() - 1); scrollT = 0; }
                else if (focusCfg && !cfgName.isEmpty()) cfgName = cfgName.substring(0, cfgName.length() - 1);
                else if (focusStr != null) {
                    String v = String.valueOf(focusStr.get());
                    if (!v.isEmpty()) focusStr.set(v.substring(0, v.length() - 1));
                }
                return true;
            }
            return true;
        }
        if (k == VClient.MENU_KEY) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        int cp = e.codepoint();
        if (cp < 32 || cp == 127) return false;
        String c = new String(Character.toChars(cp));
        if (focusSearch) { if (search.length() < 32) { search += c; scrollT = 0; } return true; }
        if (focusCfg) { if (cfgName.length() < 24) cfgName += c; return true; }
        if (focusStr != null) { focusStr.set(String.valueOf(focusStr.get()) + c); return true; }
        return false;
    }
}
