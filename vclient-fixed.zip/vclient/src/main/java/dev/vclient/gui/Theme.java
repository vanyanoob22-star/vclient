package dev.vclient.gui;

/** Общие цвета интерфейса: меню и HUD. Меняются в разделе «Тема». */
public final class Theme {
    private static int accent = 0xA64DFF, panel = 0x101015, alpha = 200;

    private Theme() {}

    /** Основной цвет (RGB) для модулей с «Цвет клиента». */
    public static int rgb() { return accent; }

    public static int panelArgb() { return (alpha << 24) | panel; }

    public static void apply(int a, int p, int al) {
        accent = a & 0xFFFFFF;
        panel = p & 0xFFFFFF;
        alpha = Math.max(0, Math.min(255, al));
        Draw.ACCENT = 0xFF000000 | accent;
        Draw.ACCENT_DIM = 0xFF000000 | dim(accent);
    }

    private static int dim(int rgb) {
        int r = (int) (((rgb >> 16) & 255) * 0.65), g = (int) (((rgb >> 8) & 255) * 0.65), b = (int) ((rgb & 255) * 0.65);
        return (r << 16) | (g << 8) | b;
    }
}
