package dev.vclient.gui;

import java.util.HashSet;
import java.util.Set;

/** Глобальные параметры внешнего вида интерфейса. Значения обновляет модуль «Стиль интерфейса». */
public final class UiStyle {
    public static float roundness = 1f;   // множитель скругления углов
    public static float anim = 1f;        // множитель скорости анимаций
    public static float menuW = 0.56f;    // ширина меню, доля экрана
    public static float menuH = 0.62f;    // высота меню, доля экрана
    public static int side = 112;         // ширина сайдбара
    public static float hud = 1f;         // общий размер HUD
    public static boolean openAnim = true;
    public static boolean sounds = true;
    public static boolean compact = false;

    private static final Set<String> FAVS = new HashSet<>();
    private static java.util.function.Consumer<String> favSink;

    private UiStyle() { }

    public static int r(int base) { return Math.max(0, Math.round(base * roundness)); }

    public static boolean isFav(String name) { return FAVS.contains(name); }

    public static void setFavs(String csv) {
        FAVS.clear();
        for (String s : csv.split(";")) if (!s.isBlank()) FAVS.add(s.trim());
    }

    public static void bindFavSink(java.util.function.Consumer<String> sink) { favSink = sink; }

    public static void toggleFav(String name) {
        if (!FAVS.remove(name)) FAVS.add(name);
        if (favSink != null) favSink.accept(String.join(";", FAVS));
    }
}
