package dev.vclient.gui;

import dev.vclient.module.WebHub;
import dev.vclient.web.RinkuBridge;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Браузер на Rinku (Chromium) в стиле Really Visuals: вкладки, адресная строка, сайты с музыкой, PiP. */
public class WebScreen extends Screen {
    private static final String[][] SITES = {
        {"YouTube Music", "https://music.youtube.com"},
        {"YouTube", "https://www.youtube.com"},
        {"SoundCloud", "https://soundcloud.com"},
        {"VK Музыка", "https://vk.com/audio"},
        {"Яндекс Музыка", "https://music.yandex.ru"},
        {"Spotify", "https://open.spotify.com"},
        {"Twitch", "https://www.twitch.tv"},
        {"Google", "https://www.google.com"},
    };

    private static final class Hit {
        int x, y, w, h;
        Runnable run;
    }

    private final Minecraft mc = Minecraft.getInstance();
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, Float> hov = new HashMap<>();
    private String addr = "";
    private boolean addrFocus, contentFocus, initTried, homeTried;
    private float openT;
    private long last = System.nanoTime();
    private int cx, cy, cw, ch, lastMx = -1, lastMy = -1;
    private double f = 1.0;
    private int heldButton = -1;

    public WebScreen() {
        super(Component.literal("Браузер"));
        WebHub.Tab t = WebHub.current();
        if (t != null) addr = t.url;
    }

    @Override public boolean isPauseScreen() { return false; }

    private int accent() { return dev.vclient.gui.Draw.ACCENT | 0xFF000000; }

    private float hv(String key, boolean over, float dt) {
        float v = hov.getOrDefault(key, 0f);
        v += ((over ? 1f : 0f) - v) * Math.min(1f, dt * 14f);
        hov.put(key, v);
        return v;
    }

    private void button(GuiGraphicsExtractor g, String key, String label, int x, int y, int w, int h,
                        boolean active, float ease, float dt, int mx, int my, Runnable run) {
        boolean over = mx >= x && mx < x + w && my >= y && my < y + h;
        float v = hv(key, over, dt);
        int base = active ? accent() & 0xFFFFFF : 0x252A38;
        int col = RvScreen.lerpC(base, 0x3A4156, v * (active ? 0.3f : 1f));
        RvScreen.rr(g, x, y, w, h, 5, RvScreen.a(col, ease));
        int tw = mc.font.width(label);
        g.text(mc.font, label, x + (w - tw) / 2, y + (h - 8) / 2, RvScreen.a(0xFFFFFF, ease));
        Hit hit = new Hit();
        hit.x = x; hit.y = y; hit.w = w; hit.h = h; hit.run = run;
        hits.add(hit);
    }

    private static String shortHost(String url) {
        if (url == null || url.isEmpty()) return "Новая вкладка";
        String s = url.replaceFirst("^[a-zA-Z]+://", "");
        int i = s.indexOf('/');
        if (i > 0) s = s.substring(0, i);
        return s.startsWith("www.") ? s.substring(4) : s;
    }

    private String fit(String t, int maxW) {
        if (mc.font.width(t) <= maxW) return t;
        int n = t.length();
        while (n > 0 && mc.font.width(t.substring(0, n) + "..") > maxW) n--;
        return t.substring(0, n) + "..";
    }

    private void navigate(String text) {
        String s = text.trim();
        if (s.isEmpty()) return;
        String url;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = s;
        else if (s.contains(".") && !s.contains(" ")) url = "https://" + s;
        else url = "https://www.google.com/search?q=" + URLEncoder.encode(s, StandardCharsets.UTF_8);
        open(url);
    }

    private void open(String url) {
        WebHub.Tab t = WebHub.current();
        if (t == null) t = WebHub.openTab(url);
        else { RinkuBridge.load(t.browser, url); t.url = url; }
        if (t != null) addr = url;
    }

    private void message(GuiGraphicsExtractor g, String l1, String l2, float ease) {
        int ty = cy + ch / 2 - 14;
        g.text(mc.font, l1, cx + (cw - mc.font.width(l1)) / 2, ty, RvScreen.a(0xFFFFFF, ease));
        if (l2 != null) g.text(mc.font, l2, cx + (cw - mc.font.width(l2)) / 2, ty + 14, RvScreen.a(0x8A90A0, ease));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        dt *= UiStyle.anim;
        last = now;
        openT += (1 - openT) * Math.min(1f, dt * 12f);
        if (!UiStyle.openAnim) openT = 1f;
        float ease = 1 - (float) Math.pow(1 - Math.min(1f, openT), 3);
        hits.clear();
        int acc = accent();

        g.fill(0, 0, width, height, RvScreen.a(0x000000, 0.5f * ease));
        int x0 = 8, y0 = 8, ww = width - 16, hh = height - 16;
        RvScreen.rr(g, x0, y0, ww, hh, 8, RvScreen.a(0x0F1117, 0.97f * ease));

        // ---- сайдбар ----
        int side = Math.min(UiStyle.side + 8, ww / 4);
        RvScreen.rr(g, x0, y0, side, hh, 8, RvScreen.a(0x161922, 0.98f * ease));
        g.fill(x0 + side - 8, y0, x0 + side, y0 + hh, RvScreen.a(0x161922, 0.98f * ease));
        g.text(mc.font, "Музыка и сайты", x0 + 12, y0 + 12, RvScreen.a(0xFFFFFF, ease));
        g.text(mc.font, "Shift+Tab — закрыть", x0 + 12, y0 + 24, RvScreen.a(0x6C7283, ease));
        int sy = y0 + 42;
        for (String[] site : SITES) {
            final String url = site[1];
            button(g, "site" + site[0], fit(site[0], side - 28), x0 + 8, sy, side - 16, 22, false, ease, dt, mx, my, () -> open(url));
            sy += 26;
            if (sy > y0 + hh - 60) break;
        }
        button(g, "newtab", "+ Новая вкладка", x0 + 8, y0 + hh - 52, side - 16, 20, true, ease, dt, mx, my, () -> {
            WebHub.Tab nt = WebHub.openTab("https://www.google.com");
            if (nt != null) addr = nt.url;
        });
        g.text(mc.font, "PiP: Shift+P", x0 + 12, y0 + hh - 24, RvScreen.a(0x6C7283, ease));

        // ---- правая часть ----
        int rx = x0 + side + 8, rw = ww - side - 16;
        cx = rx;
        cw = rw;

        if (!RinkuBridge.available()) {
            cy = y0 + 40; ch = hh - 50;
            message(g, "Библиотека Rinku не найдена", "Положи rinku.jar в папку mods", ease);
            return;
        }
        if (!RinkuBridge.initialized()) {
            cy = y0 + 40; ch = hh - 50;
            if (!initTried && RinkuBridge.initAllowed()) { initTried = true; RinkuBridge.init(); }
            if (!RinkuBridge.initAllowed()) message(g, "Загрузка Chromium запрещена", "Разреши её в настройках Rinku (Mod Menu)", ease);
            else message(g, "Chromium загружается...", "При первом запуске это может занять несколько минут", ease);
            return;
        }
        if (WebHub.tabs.isEmpty() && !homeTried) {
            homeTried = true;
            WebHub.Tab nt = WebHub.openTab(String.valueOf(dev.vclient.VClient.modules.modules.stream()
                .filter(m -> m instanceof WebHub).map(m -> ((WebHub) m).home.get()).findFirst().orElse("https://music.youtube.com")));
            if (nt != null) addr = nt.url;
        }

        // вкладки
        int ty = y0 + 8, tx = rx;
        int tabW = Math.max(70, Math.min(130, (rw - 30) / Math.max(1, WebHub.tabs.size())));
        for (int i = 0; i < WebHub.tabs.size(); i++) {
            final int idx = i;
            WebHub.Tab t = WebHub.tabs.get(i);
            boolean sel = i == WebHub.cur;
            boolean over = mx >= tx && mx < tx + tabW && my >= ty && my < ty + 20;
            float v = hv("tab" + i, over, dt);
            RvScreen.rr(g, tx, ty, tabW - 2, 20, 5, RvScreen.a(sel ? RvScreen.lerpC(0x232838, acc & 0xFFFFFF, 0.25f) : RvScreen.lerpC(0x171B26, 0x1F2433, v), ease));
            if (sel) RvScreen.rr(g, tx + 6, ty + 18, tabW - 14, 2, 1, RvScreen.a(acc, ease));
            g.text(mc.font, fit(shortHost(t.url), tabW - 26), tx + 6, ty + 6, RvScreen.a(sel ? 0xFFFFFF : 0x9AA0AE, ease));
            g.text(mc.font, "x", tx + tabW - 14, ty + 6, RvScreen.a(0x8A90A0, ease));
            Hit sel1 = new Hit(); sel1.x = tx; sel1.y = ty; sel1.w = tabW - 18; sel1.h = 20;
            sel1.run = () -> { WebHub.cur = idx; addr = WebHub.tabs.get(idx).url; };
            Hit cl = new Hit(); cl.x = tx + tabW - 18; cl.y = ty; cl.w = 16; cl.h = 20;
            cl.run = () -> { WebHub.closeTab(idx); WebHub.Tab c = WebHub.current(); addr = c == null ? "" : c.url; };
            hits.add(sel1);
            hits.add(cl);
            tx += tabW;
        }

        // панель навигации
        int ny = ty + 26, nx = rx;
        WebHub.Tab cur = WebHub.current();
        Object br = cur == null ? null : cur.browser;
        button(g, "back", "<", nx, ny, 22, 22, false, ease, dt, mx, my, () -> RinkuBridge.back(br)); nx += 26;
        button(g, "fwd", ">", nx, ny, 22, 22, false, ease, dt, mx, my, () -> RinkuBridge.forward(br)); nx += 26;
        button(g, "rel", "Обновить", nx, ny, 62, 22, false, ease, dt, mx, my, () -> RinkuBridge.reload(br)); nx += 66;
        int rightW = 80 + 46 + 46 + 40 + 62 + 5 * 4;
        int aw = Math.max(60, rx + rw - nx - rightW - 4);
        RvScreen.rr(g, nx, ny, aw, 22, 5, RvScreen.a(addrFocus ? 0x232838 : 0x1A1E29, ease));
        if (addrFocus) RvScreen.rr(g, nx, ny + 20, aw, 2, 1, RvScreen.a(acc, ease));
        boolean caret = addrFocus && (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = addr + (caret ? "_" : "");
        int tw = mc.font.width(shown);
        String vis = tw > aw - 12 ? fit(shown, aw - 12) : shown;
        if (tw > aw - 12 && addrFocus) {
            int n = shown.length();
            while (n > 0 && mc.font.width(shown.substring(shown.length() - n)) > aw - 12) n--;
            vis = shown.substring(shown.length() - n);
        }
        g.text(mc.font, vis, nx + 6, ny + 7, RvScreen.a(0xFFFFFF, ease));
        Hit ah = new Hit(); ah.x = nx; ah.y = ny; ah.w = aw; ah.h = 22;
        ah.run = () -> { addrFocus = true; contentFocus = false; if (br != null) RinkuBridge.focus(br, false); };
        hits.add(ah);
        nx += aw + 4;
        button(g, "play", "Плей/Пауза", nx, ny, 80, 22, false, ease, dt, mx, my, WebHub::toggleMedia); nx += 84;
        button(g, "vdn", "Звук -", nx, ny, 46, 22, false, ease, dt, mx, my, () -> WebHub.changeVolume(-0.1)); nx += 50;
        button(g, "vup", "Звук +", nx, ny, 46, 22, false, ease, dt, mx, my, () -> WebHub.changeVolume(0.1)); nx += 50;
        button(g, "pip", "PiP", nx, ny, 40, 22, WebHub.pip, ease, dt, mx, my, () -> {
            if (WebHub.current() != null) WebHub.pip = !WebHub.pip;
        }); nx += 44;
        button(g, "close", "Закрыть", nx, ny, 62, 22, false, ease, dt, mx, my, () -> mc.gui.setScreen(null));

        // область страницы
        cy = ny + 28;
        ch = y0 + hh - 8 - cy;
        RvScreen.rr(g, cx, cy, cw, ch, 6, RvScreen.a(0x000000, ease));
        if (cur == null) { message(g, "Нет открытых вкладок", "Выбери сайт слева", ease); return; }

        double scaleNow = mc.getWindow().getWidth() / (double) Math.max(1, mc.getWindow().getGuiScaledWidth());
        f = Math.max(1.0, Math.min(2.0, scaleNow));
        int bw = Math.max(200, (int) (cw * f)), bh = Math.max(120, (int) (ch * f));
        if (Math.abs(bw - cur.bw) > 6 || Math.abs(bh - cur.bh) > 6) {
            cur.bw = bw; cur.bh = bh;
            RinkuBridge.resize(cur.browser, bw, bh);
        }
        Identifier tex = RinkuBridge.texture(cur.browser);
        if (tex != null && RinkuBridge.ready(cur.browser)) {
            g.blit(RenderPipelines.GUI_TEXTURED, tex, cx, cy, 0f, 0f, cw, ch, cur.bw, cur.bh, cur.bw, cur.bh);
        } else {
            message(g, "Загрузка страницы...", null, ease);
        }
        if (!addrFocus && !contentFocus) { /* адрес обновляется опросом в WebHub */ addr = cur.url; }

        // мышь над страницей
        if (mx >= cx && mx < cx + cw && my >= cy && my < cy + ch && (mx != lastMx || my != lastMy)) {
            RinkuBridge.mouseMove(cur.browser, (int) ((mx - cx) * f), (int) ((my - cy) * f));
        }
        lastMx = mx;
        lastMy = my;
    }

    private boolean inContent(double x, double y) { return x >= cx && x < cx + cw && y >= cy && y < cy + ch; }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        WebHub.Tab cur = WebHub.current();
        if (cur != null && inContent(mx, my)) {
            addrFocus = false;
            contentFocus = true;
            RinkuBridge.focus(cur.browser, true);
            heldButton = e.button();
            RinkuBridge.mousePress(cur.browser, (int) ((mx - cx) * f), (int) ((my - cy) * f), heldButton);
            return true;
        }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) {
                if (h.run != null) {
                    if (e.button() != 0) continue;
                    addrFocus = false;
                    h.run.run();
                }
                return true;
            }
        }
        addrFocus = false;
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        WebHub.Tab cur = WebHub.current();
        if (cur != null && heldButton >= 0) {
            RinkuBridge.mouseRelease(cur.browser, (int) ((e.x() - cx) * f), (int) ((e.y() - cy) * f), heldButton);
            heldButton = -1;
            return true;
        }
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        WebHub.Tab cur = WebHub.current();
        if (cur != null && inContent(x, y)) {
            RinkuBridge.wheel(cur.browser, (int) ((x - cx) * f), (int) ((y - cy) * f), sy);
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        boolean shift = GLFW.glfwGetKey(mc.getWindow().handle(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS;
        if (shift && k == GLFW.GLFW_KEY_TAB) return true; // закрытие обрабатывает WebHub
        if (k == GLFW.GLFW_KEY_ESCAPE) {
            if (addrFocus || contentFocus) {
                addrFocus = false;
                contentFocus = false;
                WebHub.Tab c = WebHub.current();
                if (c != null) RinkuBridge.focus(c.browser, false);
            } else mc.gui.setScreen(null);
            return true;
        }
        if (addrFocus) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) { navigate(addr); addrFocus = false; }
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !addr.isEmpty()) addr = addr.substring(0, addr.length() - 1);
            else if (k == GLFW.GLFW_KEY_V && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = GLFW.glfwGetClipboardString(mc.getWindow().handle());
                if (clip != null) addr += clip.replace("\n", "").replace("\r", "");
            }
            return true;
        }
        WebHub.Tab cur = WebHub.current();
        if (cur != null && contentFocus) {
            RinkuBridge.keyPress(cur.browser, k, e.modifiers());
            return true;
        }
        return super.keyPressed(e);
    }

    public boolean keyReleased(KeyEvent e) {
        WebHub.Tab cur = WebHub.current();
        if (cur != null && contentFocus && !addrFocus) {
            RinkuBridge.keyRelease(cur.browser, e.key(), e.modifiers());
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        int cp = e.codepoint();
        if (cp < 32 || cp == 127) return false;
        if (addrFocus) { if (addr.length() < 400) addr += new String(Character.toChars(cp)); return true; }
        WebHub.Tab cur = WebHub.current();
        if (cur != null && contentFocus && cp < 0x10000) {
            RinkuBridge.typed(cur.browser, (char) cp);
            return true;
        }
        return false;
    }
}
