package dev.vclient.mixin;

import dev.vclient.module.Freelook;
import dev.vclient.module.NoFluid;
import net.minecraft.client.Camera;
import net.minecraft.world.level.material.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Углы камеры для Freelook и «жидкость в камере» для No Fluid. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float vclient$yaw(float yaw) { return Freelook.active ? Freelook.yaw : yaw; }

    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private float vclient$pitch(float pitch) { return Freelook.active ? Freelook.pitch : pitch; }

    @Inject(method = "getFluidInCamera", at = @At("RETURN"), cancellable = true)
    private void vclient$fluid(CallbackInfoReturnable<FogType> cir) {
        if (NoFluid.on()) cir.setReturnValue(FogType.NONE);
    }
}
