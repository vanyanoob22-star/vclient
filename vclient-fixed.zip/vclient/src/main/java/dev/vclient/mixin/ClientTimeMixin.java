package dev.vclient.mixin;

import dev.vclient.module.TimeChanger;
import net.minecraft.client.multiplayer.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Запасной путь для Time Changer: подменяет время, приходящее с сервера. */
@Mixin(ClientLevel.class)
public abstract class ClientTimeMixin {
    @ModifyVariable(method = {"setTimeFromServer", "setDayTime"}, at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private long vclient$serverTime(long dayTime) { return TimeChanger.on() ? TimeChanger.time() : dayTime; }
}
