package dev.vclient.mixin;

import dev.vclient.module.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Пока включён Freelook, мышь крутит камеру, а не игрока. */
@Mixin(Entity.class)
public abstract class EntityTurnMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void vclient$turn(double yRot, double xRot, CallbackInfo ci) {
        if (!Freelook.active || (Object) this != Minecraft.getInstance().player) return;
        Freelook.yaw += (float) (yRot * 0.15);
        Freelook.pitch = Mth.clamp(Freelook.pitch + (float) (xRot * 0.15), -90f, 90f);
        ci.cancel();
    }
}
