package dev.vclient.mixin;

import dev.vclient.module.RenderTweaks;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Тряска камеры при уроне. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = {"bobHurt", "applyHurtBob"}, at = @At("HEAD"), cancellable = true)
    private void vclient$hurt(CallbackInfo ci) {
        if (RenderTweaks.has(RenderTweaks.HURT)) ci.cancel();
    }
}
