package dev.vclient.mixin;

import dev.vclient.module.RenderTweaks;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Погода на клиенте: дождь и гроза не рисуются. Сервер при этом ничего не знает. */
@Mixin(Level.class)
public abstract class LevelMixin {
    @Inject(method = {"getRainLevel", "getThunderLevel"}, at = @At("RETURN"), cancellable = true)
    private void vclient$weather(float partial, CallbackInfoReturnable<Float> cir) {
        if ((Object) this == Minecraft.getInstance().level && RenderTweaks.has(RenderTweaks.WEATHER)) cir.setReturnValue(0f);
    }
}
