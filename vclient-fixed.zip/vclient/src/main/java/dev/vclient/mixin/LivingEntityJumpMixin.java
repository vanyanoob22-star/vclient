package dev.vclient.mixin;

import dev.vclient.module.NoJumpDelay;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Отдельный класс, чтобы сбой @Shadow не ломал остальные миксины LivingEntity. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityJumpMixin {
    @Shadow protected int noJumpDelay;

    @Inject(method = "aiStep", at = @At("HEAD"))
    private void vclient$noJumpDelay(CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && (Object) this == mc.player && NoJumpDelay.on()) noJumpDelay = 0;
    }
}
