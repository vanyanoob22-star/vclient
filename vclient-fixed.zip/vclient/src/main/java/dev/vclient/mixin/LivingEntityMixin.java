package dev.vclient.mixin;

import dev.vclient.VClient;
import dev.vclient.module.CustomHand;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    /** Длительность взмаха руки нашего игрока. */
    @Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true)
    private void vclient$swing(CallbackInfoReturnable<Integer> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || (Object) this != mc.player || VClient.modules == null) return;
        CustomHand h = VClient.modules.customHand;
        if (!h.enabled) return;
        int v = cir.getReturnValue();
        v = h.noSwing.get() ? 1 : Math.max(1, v + h.swingDelta.i());
        cir.setReturnValue(v);
    }
}
