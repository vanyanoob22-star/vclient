package dev.vclient.mixin;

import dev.vclient.module.RenderTweaks;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Свечение игроков (эффект подсветки) можно отключить. */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void vclient$glow(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (RenderTweaks.has(RenderTweaks.GLOW)) cir.setReturnValue(false);
    }
}
