package dev.vclient.mixin;

import dev.vclient.VClient;
import dev.vclient.module.Zoom;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Колёсико мыши меняет зум, пока он включён. */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void vclient$scroll(long window, double x, double y, CallbackInfo ci) {
        Zoom z = VClient.modules == null ? null : VClient.modules.zoom;
        if (z != null && z.enabled && Minecraft.getInstance().gui.screen() == null) {
            z.scroll(y);
            ci.cancel();
        }
    }
}
