package dev.vclient.mixin;

import dev.vclient.module.NoFluid;
import dev.vclient.module.RenderTweaks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Огонь и вода на экране. Класс называется OverlayRenderer (новое название). */
@Mixin(targets = "net.minecraft.client.renderer.OverlayRenderer")
public abstract class OverlayRendererMixin {
    @Inject(method = {"renderFire", "renderFireOverlay"}, at = @At("HEAD"), cancellable = true)
    private void vclient$fire(CallbackInfo ci) {
        if (RenderTweaks.has(RenderTweaks.FIRE)) ci.cancel();
    }

    @Inject(method = {"renderWater", "renderUnderwaterOverlay"}, at = @At("HEAD"), cancellable = true)
    private void vclient$water(CallbackInfo ci) {
        if (NoFluid.on()) ci.cancel();
    }
}
