package dev.vclient.mixin;

import dev.vclient.module.ClearInventory;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Убирает затемнение фона у окон с предметами. */
@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {
    @Inject(method = {"extractBackground", "renderBackground", "extractTransparentBackground", "renderTransparentBackground"},
            at = @At("HEAD"), cancellable = true)
    private void vclient$bg(CallbackInfo ci) {
        if (ClearInventory.on() && (Object) this instanceof AbstractContainerScreen<?>) ci.cancel();
    }
}
