package dev.vclient.mixin;

import dev.vclient.module.TimeChanger;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Подмена времени суток только на клиенте (Time Changer). */
@Mixin(Level.class)
public abstract class TimeMixin {
    @Inject(method = {"getDayTime"}, at = @At("RETURN"), cancellable = true)
    private void vclient$time(CallbackInfoReturnable<Long> cir) {
        if (TimeChanger.on() && (Object) this == net.minecraft.client.Minecraft.getInstance().level) cir.setReturnValue(TimeChanger.time());
    }
}
