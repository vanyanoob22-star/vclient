package dev.vclient.mixin;

import dev.vclient.module.TotemPop;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Событие 35 = сработал тотем бессмертия. */
@Mixin(ClientPacketListener.class)
public abstract class TotemMixin {
    @Inject(method = {"handleEntityEvent"}, at = @At("HEAD"))
    private void vclient$totem(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        if (packet.getEventId() != 35) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = packet.getEntity(mc.level);
        if (e != null) TotemPop.popped(e);
    }
}
