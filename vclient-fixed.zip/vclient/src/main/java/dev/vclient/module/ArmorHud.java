package dev.vclient.module;

import dev.vclient.gui.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Прочность надетой брони в процентах. */
public class ArmorHud extends HudModule {
    public ArmorHud() { super("Armor", "Прочность брони", 1, 75); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        List<String[]> rows = new ArrayList<>();
        if (sample) {
            rows.add(new String[]{"Шлем", "92%"});
            rows.add(new String[]{"Нагрудник", "64%"});
            rows.add(new String[]{"Поножи", "71%"});
            rows.add(new String[]{"Ботинки", "38%"});
        } else {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return null;
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot s : slots) {
                ItemStack st = mc.player.getItemBySlot(s);
                if (st.isEmpty() || !st.isDamageableItem()) continue;
                long pct = Math.round(100.0 * (st.getMaxDamage() - st.getDamageValue()) / st.getMaxDamage());
                rows.add(new String[]{st.getHoverName().getString(), pct + "%"});
            }
        }
        if (rows.isEmpty()) return null;
        return Draw.panel(g, "Armor", rows, posX.get(), posY.get(), scale.f());
    }
}
