package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class ArmorNotifier extends Module {
    public final Setting.Num percent = add(new Setting.Num("Порог прочности, %", 15, 1, 50, 1));
    private int cooldown;
    private String warn = "";
    private long warnAt;

    public ArmorNotifier() {
        super("Armor Notifier", Category.COMBAT);
        description = "Предупреждение о ломающейся броне";
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (cooldown > 0) { cooldown--; return; }
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot s : slots) {
            ItemStack st = mc.player.getItemBySlot(s);
            if (st.isEmpty() || !st.isDamageableItem()) continue;
            double left = 100.0 * (st.getMaxDamage() - st.getDamageValue()) / st.getMaxDamage();
            if (left <= percent.get()) {
                warn = "Броня ломается: " + st.getHoverName().getString() + " (" + Math.round(left) + "%)";
                warnAt = System.currentTimeMillis();
                cooldown = 60;
                return;
            }
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (warn.isEmpty() || System.currentTimeMillis() - warnAt > 3000) return;
        Minecraft mc = Minecraft.getInstance();
        Font f = mc.font;
        int w = f.width(warn) + 16;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        int x = (sw - w) / 2, y = sh / 2 - 50;
        Draw.rrect(g, x, y, w, 18, 6, dev.vclient.gui.Draw.panelBg());
        g.text(f, warn, x + 8, y + 5, 0xFFFF5555);
    }
}
