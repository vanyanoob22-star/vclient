package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.setting.Setting;

/** Растягивает картинку мира под своё соотношение сторон (интерфейс не трогает). */
public class AspectRatio extends Module {
    public final Setting.Num ratio = add(new Setting.Num("Соотношение", 1.78, 0.5, 3.0, 0.02));
    public final Setting.Mode preset = add(new Setting.Mode("Пресет", 0, "Своё", "4:3", "5:4", "16:9", "21:9"));

    public AspectRatio() {
        super("Aspect Ratio", Category.VISUALS);
        description = "Растянутый экран как на киберспорте";
    }

    public float value() {
        return switch (preset.get()) {
            case 1 -> 4f / 3f;
            case 2 -> 5f / 4f;
            case 3 -> 16f / 9f;
            case 4 -> 21f / 9f;
            default -> ratio.f();
        };
    }

    public static boolean on() { return VClient.modules != null && VClient.modules.aspectRatio.enabled; }
}
