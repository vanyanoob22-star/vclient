package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;

/**
 * Отправляет команду продажи (например /sellfarm), ждёт окно скупщика
 * и shift-кликом перекладывает в него вещи из инвентаря.
 */
public class AutoSell extends Module {
    public final Setting.Str command;
    public final Setting.Num perTick = add(new Setting.Num("Кликов за тик", 3, 1, 10, 1));
    public final Setting.Bool skipHotbar = add(new Setting.Bool("Не трогать хотбар", true));
    public final Setting.Bool closeAfter = add(new Setting.Bool("Закрыть окно после", true));

    private int wait;       // сколько тиков ждём окно
    private int index;      // с какого слота продолжаем
    private boolean active;

    public AutoSell(String name, String cmd) {
        super(name, Category.SERVER);
        oneShot = true;
        tickAlways = true;
        description = "Продаёт вещи из инвентаря скупщику";
        command = new Setting.Str("Команда", cmd);
        settings.add(0, command);
    }

    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) return;
        String c = command.get().trim();
        if (c.startsWith("/")) c = c.substring(1);
        if (c.isEmpty()) return;
        mc.player.connection.sendCommand(c);
        active = true;
        wait = 60;
        index = 0;
    }

    @Override public void onTick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) { active = false; return; }
        var scr = mc.gui.screen();
        if (!(scr instanceof AbstractContainerScreen<?>) || scr instanceof InventoryScreen) {
            if (--wait <= 0) active = false;
            return;
        }
        AbstractContainerMenu menu = mc.player.containerMenu;
        int clicks = 0;
        while (index < menu.slots.size() && clicks < perTick.i()) {
            Slot s = menu.slots.get(index++);
            if (s.container != mc.player.getInventory()) continue;
            if (!s.hasItem()) continue;
            if (skipHotbar.get() && s.getContainerSlot() < 9) continue;
            mc.gameMode.handleContainerInput(menu.containerId, s.index, 0, ContainerInput.QUICK_MOVE, mc.player);
            clicks++;
        }
        if (index >= menu.slots.size()) {
            active = false;
            if (closeAfter.get()) mc.player.closeContainer();
        }
    }
}
