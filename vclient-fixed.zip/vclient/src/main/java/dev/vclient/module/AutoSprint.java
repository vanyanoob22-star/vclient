package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Автоспринт: бежим сами, пока зажато движение вперёд (из Really Visuals). */
public class AutoSprint extends Module {
    public final Setting.Bool hunger = add(new Setting.Bool("Учитывать голод", true));

    public AutoSprint() {
        super("Auto Sprint", Category.UTILITIES);
        description = "Бежит автоматически при движении вперёд";
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options == null) return;
        if (!mc.options.keyUp.isDown() || p.isShiftKeyDown() || p.isUsingItem() || p.horizontalCollision || p.isSprinting()) return;
        if (hunger.get() && p.getFoodData().getFoodLevel() <= 6) return;
        p.setSprinting(true);
    }
}
