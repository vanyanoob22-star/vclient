package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;

/** Игроки рядом: ник, расстояние и стрелка направления. */
public class BetterNear extends HudModule {
    public final Setting.Num radius = add(new Setting.Num("Радиус, блоки", 100, 10, 300, 5));
    public final Setting.Num count = add(new Setting.Num("Максимум игроков", 5, 1, 10, 1));
    public final Setting.Bool onlyTab = add(new Setting.Bool("Только игроки из таб-листа (без NPC)", true));

    public BetterNear() { super("Better Near", "Игроки рядом с расстоянием", 1, 5); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        List<String[]> rows = new ArrayList<>();
        if (sample) {
            rows.add(new String[]{"Player", "23m", "90"});
            rows.add(new String[]{"Friend", "61m", "-135"});
        } else {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return null;
            var conn = mc.getConnection();
            List<Player> list = new ArrayList<>();
            for (Player p : mc.level.players()) {
                if (p == mc.player) continue;
                // NPC и боты античита обычно не числятся в таб-листе, настоящие игроки числятся
                if (onlyTab.get() && (conn == null || conn.getPlayerInfo(p.getUUID()) == null)) continue;
                if (mc.player.distanceTo(p) <= radius.get()) list.add(p);
            }
            if (list.isEmpty()) return null;
            list.sort(Comparator.comparingDouble(p -> mc.player.distanceTo(p)));
            for (int i = 0; i < Math.min(list.size(), count.i()); i++) {
                Player p = list.get(i);
                double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
                double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
                double diff = ((yaw - mc.player.getYRot()) % 360.0 + 540.0) % 360.0 - 180.0;
                rows.add(new String[]{p.getName().getString(), Math.round(mc.player.distanceTo(p)) + "m", String.valueOf(Math.round(diff))});
            }
        }
        return Draw.panel(g, "Better Near", rows, posX.get(), posY.get(), scale.f());
    }
}
