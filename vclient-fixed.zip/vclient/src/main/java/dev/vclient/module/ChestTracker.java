package dev.vclient.module;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import dev.vclient.VClient;
import dev.vclient.gui.ChestTrackerScreen;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.gui.Theme;
import dev.vclient.setting.Setting;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Запоминает содержимое сундуков, которые ты открывал. Поиск по иконке предмета: меню «Открыть трекер». */
public class ChestTracker extends Module {
    public static class Rec {
        public int x, y, z;
        public long time;
        public Map<String, Integer> items = new LinkedHashMap<>();
        public BlockPos pos() { return new BlockPos(x, y, z); }
    }

    public final List<Rec> records = new ArrayList<>();
    /** id предмета, сундуки с которым подсвечиваются в мире. */
    public String highlightId = "";

    private static final Gson GSON = new Gson();
    private BlockPos lastUse;
    private boolean wasOpen;
    private int tick;
    private String loadedKey = "";

    public final Setting.Num range = add(new Setting.Num("Дальность подсветки", 128, 16, 512, 16));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));
    public final Setting.Action open = add(new Setting.Action("Открыть трекер",
            () -> Minecraft.getInstance().gui.setScreen(new ChestTrackerScreen())));

    public ChestTracker() {
        super("Трекер сундуков", Category.UTILITIES);
        description = "Поиск предмета по иконке во всех сундуках";
        enabled = true;
        tickAlways = true;
    }

    public void noteUse(BlockPos p) { lastUse = p; }

    public List<Rec> chestsWith(String id) {
        List<Rec> out = new ArrayList<>();
        for (Rec r : records) if (r.items.containsKey(id)) out.add(r);
        return out;
    }

    public void clearAll() {
        records.clear();
        highlightId = "";
        save();
    }

    private static String worldKey(Minecraft mc) {
        var s = mc.getCurrentServer();
        String k = s != null ? s.ip : "singleplayer";
        return k.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private Path file(String key) {
        return FabricLoader.getInstance().getConfigDir().resolve("vclient").resolve("chests_" + key + ".json");
    }

    private void loadIfNeeded(Minecraft mc) {
        String key = worldKey(mc);
        if (key.equals(loadedKey)) return;
        loadedKey = key;
        records.clear();
        highlightId = "";
        try {
            Path f = file(key);
            if (Files.exists(f)) {
                List<Rec> list = GSON.fromJson(Files.readString(f), new TypeToken<List<Rec>>() { }.getType());
                if (list != null) records.addAll(list);
            }
        } catch (Exception e) {
            VClient.LOG.warn("Не удалось прочитать список сундуков", e);
        }
    }

    public void save() {
        try {
            Path f = file(loadedKey.isEmpty() ? "singleplayer" : loadedKey);
            Files.createDirectories(f.getParent());
            Files.writeString(f, GSON.toJson(records));
        } catch (Exception e) {
            VClient.LOG.warn("Не удалось сохранить список сундуков", e);
        }
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        loadIfNeeded(mc);
        if (!enabled) return;
        var menu = mc.player.containerMenu;
        boolean open = menu instanceof ChestMenu && menu != mc.player.inventoryMenu;
        if (open && lastUse != null) {
            wasOpen = true;
            if (mc.level.getBlockState(lastUse).is(Blocks.ENDER_CHEST)) return;
            if (tick++ % 5 == 0) snapshot((ChestMenu) menu);
        } else {
            if (wasOpen) save();
            wasOpen = false;
            tick = 0;
        }
    }

    private void snapshot(ChestMenu menu) {
        Rec r = null;
        for (Rec x : records) if (x.x == lastUse.getX() && x.y == lastUse.getY() && x.z == lastUse.getZ()) r = x;
        if (r == null) {
            r = new Rec();
            r.x = lastUse.getX(); r.y = lastUse.getY(); r.z = lastUse.getZ();
            records.add(r);
        }
        r.time = System.currentTimeMillis();
        r.items.clear();
        var c = menu.getContainer();
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack st = c.getItem(i);
            if (st.isEmpty()) continue;
            r.items.merge(BuiltInRegistries.ITEM.getKey(st.getItem()).toString(), st.getCount(), Integer::sum);
        }
        if (r.items.isEmpty()) records.remove(r);
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (highlightId.isEmpty() || mc.player == null || !Projection.ready) return;
        Font f = mc.font;
        int rgb = clientColor.get() ? Theme.rgb() : color.get();
        for (Rec r : records) {
            Integer n = r.items.get(highlightId);
            if (n == null) continue;
            Vec3 c = Vec3.atCenterOf(r.pos());
            double d = mc.player.position().distanceTo(c);
            if (d > range.get()) continue;
            Projection.box(g, new AABB(r.pos()), 2, Draw.alpha(rgb, 0xF0));
            double[] s = Projection.project(c.x, c.y + 0.9, c.z);
            if (s == null) continue;
            String t = "x" + n + "  " + Math.round(d) + "m";
            int w = f.width(t) + 10;
            Draw.rrect(g, (int) s[0] - w / 2, (int) s[1] - 7, w, 13, 5, Draw.panelBg());
            g.text(f, t, (int) s[0] - w / 2 + 5, (int) s[1] - 4, 0xFFFFFFFF);
        }
    }
}
