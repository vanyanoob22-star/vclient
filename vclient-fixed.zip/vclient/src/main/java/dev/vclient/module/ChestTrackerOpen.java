package dev.vclient.module;

import dev.vclient.gui.ChestTrackerScreen;
import net.minecraft.client.Minecraft;

/** Кнопка, которую можно повесить на клавишу: открывает меню трекера сундуков. */
public class ChestTrackerOpen extends Module {
    public ChestTrackerOpen() {
        super("Меню трекера сундуков", Category.UTILITIES);
        oneShot = true;
        description = "Открыть поиск предметов по иконке";
    }

    @Override public void onEnable() {
        Minecraft.getInstance().gui.setScreen(new ChestTrackerScreen());
    }
}
