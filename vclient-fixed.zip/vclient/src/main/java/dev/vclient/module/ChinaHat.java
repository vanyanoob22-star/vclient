package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class ChinaHat extends Module {
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Num radius = add(new Setting.Num("Радиус", 0.55, 0.3, 1.0, 0.05));
    public final Setting.Num height = add(new Setting.Num("Высота", 0.35, 0.15, 0.8, 0.05));
    public final Setting.Num segs = add(new Setting.Num("Сегменты", 24, 8, 40, 2));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    public ChinaHat() {
        super("China Hat", Category.VISUALS);
        description = "Китайская шляпа над головой";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        if (self.get() && !mc.options.getCameraType().isFirstPerson()) hat(g, mc.player, rgb);
        if (others.get()) {
            for (Player p : mc.level.players()) {
                if (p == mc.player) continue;
                if (mc.player.distanceTo(p) > 48) continue;
                hat(g, p, rgb);
            }
        }
    }

    private void hat(GuiGraphicsExtractor g, Player p, int rgb) {
        float pt = VClient.partial;
        Vec3 pos = p.getPosition(pt);
        Vec3 base = pos.add(0, p.getBbHeight() + 0.02, 0);
        Vec3 apex = base.add(0, height.get(), 0);
        int n = segs.i();
        int c = Draw.alpha(rgb, 0xD0);
        Projection.ring(g, base, radius.get(), n, 2, c);
        for (int i = 0; i < n; i += 3) {
            double a = i * 2 * Math.PI / n;
            Vec3 edge = base.add(Math.cos(a) * radius.get(), 0, Math.sin(a) * radius.get());
            Projection.line(g, edge, apex, 1, Draw.alpha(rgb, 0x90));
        }
    }
}
