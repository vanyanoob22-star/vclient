package dev.vclient.module;

import dev.vclient.VClient;

/** Прозрачный фон у инвентаря и других окон с предметами (без затемнения). */
public class ClearInventory extends Module {
    public ClearInventory() {
        super("Прозрачный инвентарь", Category.VISUALS);
        description = "Инвентарь без затемнения фона";
    }

    public static boolean on() { return VClient.modules != null && VClient.modules.clearInventory.enabled; }
}
