package dev.vclient.module;

import dev.vclient.gui.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;

/** CPS (удары в секунду) и комбо по одной цели. Появляется после удара. */
public class CombatStats extends HudModule {
    private final List<Long> hits = new ArrayList<>();
    private Entity lastTarget;
    private long lastTime;
    private int combo;

    public CombatStats() { super("Combat Stats", "CPS и комбо", 85, 5); }

    @Override public void onAttack(Entity e) {
        long now = System.currentTimeMillis();
        hits.add(now);
        if (e == lastTarget && now - lastTime < 3000) combo++;
        else combo = 1;
        lastTarget = e;
        lastTime = now;
    }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        List<String[]> rows = new ArrayList<>();
        long now = System.currentTimeMillis();
        if (sample) {
            rows.add(new String[]{"CPS", "7"});
            rows.add(new String[]{"Комбо", "4"});
        } else {
            hits.removeIf(t -> now - t > 1000);
            if (now - lastTime > 5000) return null;
            rows.add(new String[]{"CPS", String.valueOf(hits.size())});
            rows.add(new String[]{"Комбо", String.valueOf(now - lastTime < 3000 ? combo : 0)});
        }
        return Draw.panel(g, "Combat", rows, posX.get(), posY.get(), scale.f());
    }
}
