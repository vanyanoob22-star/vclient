package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;

/** Кнопка на серверную команду. Команду можно менять в настройках/конфиге. */
public class CommandBind extends Module {
    public final Setting.Str command;

    public CommandBind(String name, String cmd) {
        super(name, Category.SERVER);
        this.oneShot = true;
        this.description = "Команда на сервер, можно изменить";
        this.command = add(new Setting.Str("Команда", cmd));
    }

    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) return;
        String c = command.get().trim();
        if (c.startsWith("/")) c = c.substring(1);
        if (!c.isEmpty()) mc.player.connection.sendCommand(c);
    }
}
