package dev.vclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Общие мелочи для косметики. */
final class Cos {
    private Cos() {}

    static int mix(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static int hsv(float h, float s, float v) {
        float c = v * s, hh = (h % 360f) / 60f, x = c * (1 - Math.abs(hh % 2 - 1)), m = v - c;
        float r = 0, g = 0, b = 0;
        if (hh < 1) { r = c; g = x; }
        else if (hh < 2) { r = x; g = c; }
        else if (hh < 3) { g = c; b = x; }
        else if (hh < 4) { g = x; b = c; }
        else if (hh < 5) { r = x; b = c; }
        else { r = c; b = x; }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    /** Угол корпуса игрока в радианах (с плавной интерполяцией). */
    static double bodyYaw(Player p, float pt) {
        return Math.toRadians(p.yBodyRotO + (p.yBodyRot - p.yBodyRotO) * pt);
    }

    /** Точка в системе игрока: вправо, вверх, вперёд (в блоках) от основания base. */
    static Vec3 local(Vec3 base, double yaw, double right, double up, double fwd) {
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        return new Vec3(base.x + rx * right + fx * fwd, base.y + up, base.z + rz * right + fz * fwd);
    }

    /** Показывать ли косметику на этом игроке. Себя не рисуем в первом лице. */
    static boolean shows(Minecraft mc, Player p, boolean self, boolean others, double maxDist) {
        if (p == mc.player) return self && !mc.options.getCameraType().isFirstPerson();
        return others && mc.player.distanceTo(p) <= Math.min(maxDist, dev.vclient.gui.Quality.distance);
    }
}
