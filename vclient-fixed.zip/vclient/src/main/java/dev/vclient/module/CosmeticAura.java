package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Аура: светящиеся огоньки поднимаются по спирали вокруг игрока, у ног светится кольцо. */
public class CosmeticAura extends Module {
    static final String[] NAMES = {"Ангельская", "Демоническая", "Галактическая", "Пустота", "Огненная", "Ледяная",
            "Святая", "Теневая", "Природа", "Тайная", "Космическая", "Своя"};
    static final int[][] COL = {{0xFFE680, 0xFFFFFF}, {0xFF2A2A, 0x7A0000}, {0x7A5CFF, 0x4DC3FF}, {0x9B30FF, 0x3A0066},
            {0xFF7A1A, 0xFFD54D}, {0x7DE3FF, 0xFFFFFF}, {0xFFF3B0, 0xFFD54D}, {0x6A4AA8, 0xB08AFF},
            {0x55D26B, 0xB6F08A}, {0xC45CFF, 0x5CFFE1}, {0xFF5CC8, 0x5CA8FF}, {0xA64DFF, 0x55D26B}};

    public final Setting.Mode type = add(new Setting.Mode("Тип", 0, NAMES));
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Num count = add(new Setting.Num("Количество огоньков", 14, 4, 40, 1));
    public final Setting.Num radius = add(new Setting.Num("Радиус", 0.8, 0.3, 2.0, 0.05));
    public final Setting.Num speed = add(new Setting.Num("Скорость", 1.0, 0.2, 4.0, 0.1));
    public final Setting.Num size = add(new Setting.Num("Размер", 0.06, 0.02, 0.2, 0.01));
    public final Setting.Bool ring = add(new Setting.Bool("Кольцо у ног", true));
    public final Setting.Color c1 = add(new Setting.Color("Цвет 1 (для «Своя»)", 0xA64DFF));
    public final Setting.Color c2 = add(new Setting.Color("Цвет 2 (для «Своя»)", 0x55D26B));

    public CosmeticAura() {
        super("Аура", Category.COSMETICS);
        description = "Светящиеся огоньки вокруг игрока";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        for (Player p : mc.level.players()) {
            if (Cos.shows(mc, p, self.get(), others.get(), 32)) aura(g, p);
        }
    }

    private void aura(GuiGraphicsExtractor g, Player p) {
        int idx = type.get();
        int a1 = idx == 11 ? c1.get() : COL[idx][0], a2 = idx == 11 ? c2.get() : COL[idx][1];
        double t = System.currentTimeMillis() / 1000.0 * speed.get();
        Vec3 base = p.getPosition(VClient.partial);
        double h = p.getBbHeight(), r = radius.get();
        if (ring.get()) Projection.ring(g, base.add(0, 0.05, 0), r * (1 + 0.08 * Math.sin(t * 2)), 28, 2, Draw.alpha(a1, 0x90));
        int n = Math.max(2, Math.round(count.i() * dev.vclient.gui.Quality.particles));
        for (int i = 0; i < n; i++) {
            double ph = (t * 0.35 + (double) i / n) % 1.0;
            double ang = t * 1.2 + i * 2.399963;
            double rr = r * (0.8 + 0.2 * Math.sin(ph * Math.PI));
            double[] s = Projection.project(base.x + Math.cos(ang) * rr, base.y + ph * h, base.z + Math.sin(ang) * rr);
            if (s == null) continue;
            int al = (int) (230 * Math.sin(Math.PI * ph));
            if (al < 10) continue;
            int sz = Math.max(2, (int) Math.round(size.get() * Projection.pxPerBlock(s[2]) * 2));
            int col = Cos.mix(a1, a2, ph);
            int sx = (int) s[0], sy = (int) s[1];
            Draw.rrect(g, sx - sz, sy - sz, sz * 2, sz * 2, Math.max(1, sz), Draw.alpha(col, (int) Math.min(255, al / 4 * dev.vclient.gui.Quality.glow)));
            Draw.rrect(g, sx - sz / 2, sy - sz / 2, sz, sz, Math.max(1, sz / 2), Draw.alpha(col, al));
        }
    }
}
