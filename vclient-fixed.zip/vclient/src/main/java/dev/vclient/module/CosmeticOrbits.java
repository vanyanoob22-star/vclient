package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Предметы, которые кружат вокруг игрока. */
public class CosmeticOrbits extends Module {
    public final Setting.Mode type = add(new Setting.Mode("Вид", 0, "Шары", "Кристаллы", "Крестики"));
    public final Setting.Num count = add(new Setting.Num("Количество", 5, 1, 12, 1));
    public final Setting.Num radius = add(new Setting.Num("Радиус", 1.0, 0.4, 2.0, 0.1));
    public final Setting.Num speed = add(new Setting.Num("Скорость", 1.0, 0.2, 4.0, 0.1));
    public final Setting.Num size = add(new Setting.Num("Размер", 0.12, 0.04, 0.4, 0.01));
    public final Setting.Num height = add(new Setting.Num("Высота (доля роста)", 0.55, 0.0, 1.0, 0.05));
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    public CosmeticOrbits() {
        super("Орбиты", Category.COSMETICS);
        description = "Предметы кружат вокруг игрока";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        for (Player p : mc.level.players()) {
            if (Cos.shows(mc, p, self.get(), others.get(), 32)) orbit(g, p, rgb);
        }
    }

    private void orbit(GuiGraphicsExtractor g, Player p, int rgb) {
        Vec3 base = p.getPosition(VClient.partial);
        double t = System.currentTimeMillis() / 1000.0 * speed.get();
        int n = Math.max(1, Math.round(count.i() * dev.vclient.gui.Quality.particles));
        for (int i = 0; i < n; i++) {
            double a = t + i * 2 * Math.PI / n;
            double y = p.getBbHeight() * height.get() + 0.15 * Math.sin(t * 2 + i);
            double[] s = Projection.project(base.x + Math.cos(a) * radius.get(), base.y + y, base.z + Math.sin(a) * radius.get());
            if (s == null) continue;
            int px = Math.max(3, (int) Math.round(size.get() * Projection.pxPerBlock(s[2]) * 2));
            int sx = (int) s[0], sy = (int) s[1], h = px / 2;
            switch (type.get()) {
                case 0 -> {
                    Draw.rrect(g, sx - px, sy - px, px * 2, px * 2, px, Draw.alpha(rgb, 0x40));
                    Draw.rrect(g, sx - h, sy - h, px, px, h, Draw.alpha(rgb, 0xFF));
                }
                case 1 -> {
                    Draw.arrow(g, sx, sy - h / 2, h + 1, 0, Draw.alpha(rgb, 0xE0));
                    Draw.arrow(g, sx, sy + h / 2, h + 1, 180, Draw.alpha(rgb, 0xE0));
                }
                default -> {
                    g.fill(sx - h, sy, sx + h + 1, sy + 1, Draw.alpha(rgb, 0xE0));
                    g.fill(sx, sy - h, sx + 1, sy + h + 1, Draw.alpha(rgb, 0xE0));
                }
            }
        }
    }
}
