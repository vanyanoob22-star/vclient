package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;

/** Гаснущий след за игроком. */
public class CosmeticTrail extends Module {
    static final String[] NAMES = {"Огонь", "Лёд", "Магия", "Радуга", "Свой цвет"};

    public final Setting.Mode type = add(new Setting.Mode("Тип", 2, NAMES));
    public final Setting.Num length = add(new Setting.Num("Длина следа, сек", 1.2, 0.3, 4.0, 0.1));
    public final Setting.Num thick = add(new Setting.Num("Толщина", 2, 1, 4, 1));
    public final Setting.Bool self = add(new Setting.Bool("Для себя", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    private final Map<UUID, ArrayDeque<double[]>> map = new HashMap<>();

    public CosmeticTrail() {
        super("Следы", Category.COSMETICS);
        description = "Гаснущий след за игроком";
    }

    @Override public void onDisable() { map.clear(); }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) { map.clear(); return; }
        long now = System.currentTimeMillis();
        Set<UUID> seen = new HashSet<>();
        for (Player p : mc.level.players()) {
            boolean ok = p == mc.player ? self.get() : (others.get() && mc.player.distanceTo(p) <= 32);
            if (!ok) continue;
            seen.add(p.getUUID());
            ArrayDeque<double[]> q = map.computeIfAbsent(p.getUUID(), k -> new ArrayDeque<>());
            q.addLast(new double[]{p.getX(), p.getY() + 0.08, p.getZ(), now});
        }
        map.keySet().retainAll(seen);
        long life = (long) (length.get() * 1000);
        for (ArrayDeque<double[]> q : map.values()) {
            while (!q.isEmpty() && now - q.peekFirst()[3] > life) q.removeFirst();
            while (q.size() > dev.vclient.gui.Quality.trailPoints) q.removeFirst();
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!Projection.ready) return;
        long now = System.currentTimeMillis();
        double life = length.get() * 1000;
        int th = thick.i(), ty = type.get();
        for (ArrayDeque<double[]> q : map.values()) {
            List<double[]> pts = new ArrayList<>(q);
            for (int i = 1; i < pts.size(); i++) {
                double[] a = pts.get(i - 1), b = pts.get(i);
                double age = Math.min(1, (now - b[3]) / life);
                int al = (int) (0xE0 * (1 - age));
                if (al < 8) continue;
                int rgb = switch (ty) {
                    case 0 -> Cos.mix(0xFFD54D, 0xFF3A00, age);
                    case 1 -> Cos.mix(0xFFFFFF, 0x4DC3FF, age);
                    case 2 -> Cos.mix(color.get(), 0xFF7AD9, age);
                    case 3 -> Cos.hsv((float) ((i * 9 + now / 12.0) % 360), 0.7f, 1f);
                    default -> color.get();
                };
                Projection.line(g, a[0], a[1], a[2], b[0], b[1], b[2], th, Draw.alpha(rgb, al));
            }
        }
    }
}
