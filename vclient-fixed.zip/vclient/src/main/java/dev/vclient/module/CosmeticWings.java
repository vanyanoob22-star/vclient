package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Крылья из перьев-линий за спиной, машут. Видны над другими игроками и у тебя в третьем лице. */
public class CosmeticWings extends Module {
    static final String[] NAMES = {"Ангельские", "Демонические", "Дракона", "Бабочки", "Феникса", "Кристальные", "Энергии", "Пустоты"};
    static final int[][] COL = {{0xFFFFFF, 0xFFE680}, {0xFF2A2A, 0x4A0000}, {0x55D26B, 0x0F3A1A}, {0xFF7AD9, 0x4DC3FF},
            {0xFFD54D, 0xFF4A1A}, {0x7DE3FF, 0xFFFFFF}, {0xA64DFF, 0x4DC3FF}, {0x7A00D8, 0x1A0030}};
    static final int[] FEATHERS = {9, 6, 6, 4, 10, 6, 8, 7};

    public final Setting.Mode type = add(new Setting.Mode("Тип", 0, NAMES));
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Num size = add(new Setting.Num("Размер", 1.0, 0.5, 2.0, 0.05));
    public final Setting.Num spread = add(new Setting.Num("Раскрытие", 1.0, 0.5, 1.5, 0.05));
    public final Setting.Num flap = add(new Setting.Num("Взмахи", 1.0, 0.0, 3.0, 0.1));
    public final Setting.Num alpha = add(new Setting.Num("Прозрачность", 220, 60, 255, 5));
    public final Setting.Bool custom = add(new Setting.Bool("Свой цвет", false));
    public final Setting.Color color = add(new Setting.Color("Цвет", 0xA64DFF));

    public CosmeticWings() {
        super("Крылья", Category.COSMETICS);
        description = "Крылья за спиной";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        for (Player p : mc.level.players()) {
            if (Cos.shows(mc, p, self.get(), others.get(), 32)) wing(g, p);
        }
    }

    private void wing(GuiGraphicsExtractor g, Player p) {
        float pt = VClient.partial;
        int ti = type.get();
        int c1 = custom.get() ? color.get() : COL[ti][0];
        int c2 = custom.get() ? Cos.mix(color.get(), 0x000000, 0.55) : COL[ti][1];
        Vec3 pos = p.getPosition(pt);
        double yaw = Cos.bodyYaw(p, pt);
        Vec3 sh = Cos.local(pos, yaw, 0, p.getBbHeight() * 0.72, -0.18);
        double t = System.currentTimeMillis() / 1000.0;
        double fl = flap.get();
        double flapA = Math.sin(t * 4 * Math.max(0.1, fl)) * 0.30 * Math.min(1, fl);
        int n = Math.max(3, Math.round(FEATHERS[ti] * dev.vclient.gui.Quality.detail));
        double sz = size.get(), sp = spread.get();
        int al = alpha.i();
        for (int side = -1; side <= 1; side += 2) {
            Vec3 prev = null;
            for (int k = 0; k < n; k++) {
                double u = n == 1 ? 0 : (double) k / (n - 1);
                double ang = Math.toRadians(30 + u * 100 * sp) + flapA;
                double len = sz * (0.55 + 0.8 * Math.sin(Math.PI * (0.12 + 0.78 * u)));
                Vec3 tip = Cos.local(sh, yaw, side * Math.sin(ang) * len, Math.cos(ang) * len * 0.95 - 0.1 * len, -len * 0.3);
                int col = Cos.mix(c1, c2, u);
                Projection.line(g, sh, tip, 2, Draw.alpha(col, al));
                if (prev != null && dev.vclient.gui.Quality.detail >= 0.8f) Projection.line(g, prev, tip, 1, Draw.alpha(c2, al * 7 / 10));
                prev = tip;
            }
        }
    }
}
