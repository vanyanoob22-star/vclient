package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Зелёная корона с зубцами над головой. */
public class CucumberCrown extends Module {
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Num radius = add(new Setting.Num("Радиус", 0.38, 0.2, 0.8, 0.02));
    public final Setting.Num height = add(new Setting.Num("Высота зубцов", 0.3, 0.1, 0.8, 0.02));
    public final Setting.Num teeth = add(new Setting.Num("Зубцов", 7, 4, 12, 1));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", false));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0x55D26B));

    public CucumberCrown() {
        super("Огуречная корона", Category.MEMES);
        description = "Корона над головой";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        if (self.get() && !mc.options.getCameraType().isFirstPerson()) crown(g, mc.player, rgb);
        if (others.get()) {
            for (Player p : mc.level.players()) {
                if (p == mc.player || mc.player.distanceTo(p) > 48) continue;
                crown(g, p, rgb);
            }
        }
    }

    private void crown(GuiGraphicsExtractor g, Player p, int rgb) {
        Vec3 base = p.getPosition(VClient.partial).add(0, p.getBbHeight() + 0.02, 0);
        int n = teeth.i() * 2;
        double r = radius.get(), h = height.get();
        int c = Draw.alpha(rgb, 0xE0);
        double px = base.x + r, py = base.y, pz = base.z;
        for (int i = 1; i <= n; i++) {
            double a = i * 2 * Math.PI / n;
            double x = base.x + Math.cos(a) * r, z = base.z + Math.sin(a) * r;
            double y = base.y + ((i & 1) == 0 ? 0 : h);
            Projection.line(g, px, py, pz, x, y, z, 2, c);
            px = x; py = y; pz = z;
        }
        Projection.ring(g, base, r, 24, 2, c);
    }
}
