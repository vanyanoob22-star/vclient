package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.lwjgl.glfw.GLFW;

/** Курсор мыши в виде огурца в окнах клиента (меню, редактор HUD, трекер сундуков). */
public class CucumberCursor extends Module {
    public final Setting.Num size = add(new Setting.Num("Размер", 16, 8, 40, 1));
    public final Setting.Bool bounce = add(new Setting.Bool("Сжимается при клике", true));
    public final Setting.Bool hideOs = add(new Setting.Bool("Скрыть обычный курсор", true));
    private long lastClick;
    private boolean wasDown, hidden;

    public CucumberCursor() {
        super("Огуречный курсор", Category.MEMES);
        description = "Курсор мыши в виде огурца";
        enabled = true;
    }

    /** Вызывается в конце отрисовки каждого окна клиента. mx и my это позиция мыши в координатах интерфейса. */
    public void render(GuiGraphicsExtractor g, int mx, int my) {
        Minecraft mc = Minecraft.getInstance();
        long win = mc.getWindow().handle();
        boolean wantHidden = enabled && hideOs.get();
        if (wantHidden) {
            GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_HIDDEN);
            hidden = true;
        } else if (hidden) {
            GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
            hidden = false;
        }
        if (!enabled) return;

        long now = System.currentTimeMillis();
        boolean down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown) lastClick = now;
        wasDown = down;

        double s = size.get();
        long dt = now - lastClick;
        if (bounce.get() && dt < 200) s *= 0.75 + 0.25 * (dt / 200.0);
        int sz = Math.max(4, (int) Math.round(s));
        Draw.badge(g, mx - sz / 2, my - sz / 2, sz);
    }
}
