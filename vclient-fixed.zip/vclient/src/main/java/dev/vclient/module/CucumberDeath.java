package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Когда цель умирает, из неё разлетаются огурцы. Предпросмотр есть в меню. */
public class CucumberDeath extends Module {
    private static class Fx { Vec3 pos; long t0; double seed; }

    private final List<Fx> list = new ArrayList<>();
    private long previewT0 = System.currentTimeMillis();
    private LivingEntity handled;

    public final Setting.Num count = add(new Setting.Num("Количество", 10, 4, 24, 1));
    public final Setting.Num power = add(new Setting.Num("Сила разлёта", 3.0, 1.0, 6.0, 0.5));
    public final Setting.Num size = add(new Setting.Num("Размер, блоки", 0.45, 0.2, 1.2, 0.05));
    public final Setting.Num duration = add(new Setting.Num("Длительность, сек", 1.4, 0.5, 3.0, 0.1));
    public final Setting.Bool playersOnly = add(new Setting.Bool("Только игроки", false));
    public final Setting.Action restart = add(new Setting.Action("Перезапустить превью", () -> this.previewT0 = System.currentTimeMillis()));
    public final Setting.Action inWorld = add(new Setting.Action("Показать в мире (модуль должен быть включён)", this::spawnInFront));

    public CucumberDeath() {
        super("Огуречная смерть", Category.MEMES);
        description = "Огурцы разлетаются при убийстве";
    }

    private void spawnInFront() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Vec3 look = mc.player.getViewVector(1f);
        add(mc.player.position().add(look.x * 4, 0, look.z * 4));
    }

    private void add(Vec3 pos) {
        Fx f = new Fx();
        f.pos = pos;
        f.t0 = System.currentTimeMillis();
        f.seed = Math.random() * Math.PI * 2;
        list.add(f);
        while (list.size() > 5) list.remove(0);
    }

    @Override public void onTick() {
        LivingEntity t = VClient.lastTarget;
        if (t == null || t == handled) return;
        if (System.currentTimeMillis() - VClient.lastTargetTime > 8000) return;
        if (t.isDeadOrDying() || t.getHealth() <= 0f) {
            handled = t;
            if (!playersOnly.get() || t instanceof Player) add(t.position());
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!Projection.ready) return;
        long now = System.currentTimeMillis();
        list.removeIf(f -> (now - f.t0) / 1000.0 > duration.get());
        for (Fx f : list) render(g, f.pos, (now - f.t0) / 1000.0 / duration.get(), f.seed);
    }

    private void render(GuiGraphicsExtractor g, Vec3 pos, double age, double seed) {
        int n = count.i();
        double t = age * duration.get();
        for (int i = 0; i < n; i++) {
            double ang = seed + i * 2 * Math.PI / n;
            double sp = power.get() * (0.6 + 0.4 * ((i * 7919) % 10) / 10.0);
            double x = pos.x + Math.cos(ang) * sp * t * 0.6;
            double z = pos.z + Math.sin(ang) * sp * t * 0.6;
            double y = pos.y + 0.8 + 3.5 * t - 4.9 * t * t;
            double[] s = Projection.project(x, y, z);
            if (s == null) continue;
            int px = (int) Math.round(size.get() * Projection.pxPerBlock(s[2]));
            if (px < 3) continue;
            Draw.badge(g, (int) s[0] - px / 2, (int) s[1] - px / 2, px);
        }
    }

    // ---------- предпросмотр в меню ----------
    @Override public int previewHeight() { return 100; }

    @Override public void drawPreview(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        long now = System.currentTimeMillis();
        double d = duration.get();
        double tt = ((now - previewT0) / 1000.0) % (d + 0.8);
        double age = tt / d;
        float yaw = (float) ((now / 1000.0 * 18) % 360);
        float pitch = 15f;
        Vec3 target = new Vec3(0, 1.4, 0);
        Vec3 eye = target.subtract(Projection.look(yaw, pitch).scale(7));
        Projection.setCamera(eye, yaw, pitch, 60, w, h, x, y);
        g.enableScissor(x, y, x + w, y + h);
        Projection.ring(g, new Vec3(0, 0.02, 0), 2.0, 24, 1, 0x30FFFFFF);
        Projection.line(g, new Vec3(0, 0, 0), new Vec3(0, 1.8, 0), 2, 0x55FFFFFF);
        if (age < 1) render(g, Vec3.ZERO, age, 0);
        g.disableScissor();
        Projection.update(VClient.partial);
    }
}
