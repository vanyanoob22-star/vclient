package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Метка с огуречным значком и префиксом над ником. Видна только тебе (другие клиенты её не получают). */
public class CucumberNick extends Module {
    public final Setting.Str prefix = add(new Setting.Str("Префикс", "Огурец"));
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Str names = add(new Setting.Str("Ещё ники (через запятую)", ""));
    public final Setting.Num radius = add(new Setting.Num("Дальность", 48, 8, 128, 4));
    public final Setting.Color color = add(new Setting.Color("Цвет", 0x55D26B));

    private String cached = "";
    private Set<String> set = new HashSet<>();

    public CucumberNick() {
        super("Огуречный префикс", Category.MEMES);
        description = "Значок и префикс над ником";
    }

    private boolean listed(String name) {
        if (!names.get().equals(cached)) {
            cached = names.get();
            set = new HashSet<>();
            for (String p : cached.split("[,;\\s]+")) if (!p.isBlank()) set.add(p.toLowerCase(Locale.ROOT));
        }
        return set.contains(name.toLowerCase(Locale.ROOT));
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        if (self.get() && !mc.options.getCameraType().isFirstPerson()) plate(g, mc, mc.player);
        for (Player p : mc.level.players()) {
            if (p == mc.player || mc.player.distanceTo(p) > radius.get()) continue;
            if (listed(p.getName().getString())) plate(g, mc, p);
        }
    }

    private void plate(GuiGraphicsExtractor g, Minecraft mc, Player p) {
        Font f = mc.font;
        Vec3 head = p.getPosition(VClient.partial).add(0, p.getBbHeight() + 0.65, 0);
        double[] s = Projection.project(head);
        if (s == null) return;
        String text = (prefix.get().isEmpty() ? "" : "[" + prefix.get() + "] ") + p.getName().getString();
        int bw = f.width(text) + 22;
        int x = (int) s[0] - bw / 2, y = (int) s[1] - 14;
        Draw.rrect(g, x, y, bw, 13, 5, Draw.panelBg());
        Draw.badge(g, x + 3, y + 1, 11);
        g.text(f, text, x + 17, y + 3, Draw.alpha(color.get(), 0xFF));
    }
}
