package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Хруст и зелёные брызги при ударе мечом. */
public class CucumberSword extends Module {
    private static class P { Vec3 pos, vel; long t0; }

    public final Setting.Bool sound = add(new Setting.Bool("Звук хруста", true));
    public final Setting.Bool particles = add(new Setting.Bool("Брызги", true));
    public final Setting.Num count = add(new Setting.Num("Количество брызг", 10, 2, 24, 1));
    public final Setting.Color color = add(new Setting.Color("Цвет брызг", 0x55D26B));
    private final List<P> list = new ArrayList<>();

    public CucumberSword() {
        super("Огуречный меч", Category.MEMES);
        description = "Хруст и брызги при ударе мечом";
    }

    @Override public void onAttack(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !mc.player.getMainHandItem().is(ItemTags.SWORDS)) return;
        if (sound.get()) {
            float pitch = 0.9f + (float) Math.random() * 0.3f;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.CROP_BREAK, pitch, 0.8f));
        }
        if (particles.get()) {
            Vec3 c = e.getPosition(VClient.partial).add(0, e.getBbHeight() * 0.6, 0);
            long now = System.currentTimeMillis();
            for (int i = 0; i < count.i(); i++) {
                double a = Math.random() * Math.PI * 2, up = 1.0 + Math.random() * 2.0, sp = 1.0 + Math.random() * 2.0;
                P p = new P();
                p.pos = c;
                p.vel = new Vec3(Math.cos(a) * sp, up, Math.sin(a) * sp);
                p.t0 = now;
                list.add(p);
            }
            while (list.size() > 80) list.remove(0);
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!Projection.ready) return;
        long now = System.currentTimeMillis();
        list.removeIf(p -> now - p.t0 > 600);
        for (P p : list) {
            double t = (now - p.t0) / 1000.0, age = (now - p.t0) / 600.0;
            double[] s = Projection.project(p.pos.x + p.vel.x * t, p.pos.y + p.vel.y * t - 4.9 * t * t, p.pos.z + p.vel.z * t);
            if (s == null) continue;
            int sz = Math.max(2, (int) Math.round(0.07 * Projection.pxPerBlock(s[2])));
            int a = (int) (255 * (1 - age));
            if (a < 8) continue;
            g.fill((int) s[0], (int) s[1], (int) s[0] + sz, (int) s[1] + sz, Draw.alpha(color.get(), a));
        }
    }
}
