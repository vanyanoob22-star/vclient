package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.EntityHitResult;

public class CustomCrosshair extends Module {
    public final Setting.Mode type = add(new Setting.Mode("Тип", 0, "Крест", "Точка"));
    public final Setting.Num sizeS = add(new Setting.Num("Размер", 6, 1, 20, 1));
    public final Setting.Num thickS = add(new Setting.Num("Толщина", 1, 1, 5, 1));
    public final Setting.Num gapS = add(new Setting.Num("Отступ", 2, 0, 10, 1));
    public final Setting.Bool outline = add(new Setting.Bool("Обводка", true));
    public final Setting.Bool dot = add(new Setting.Bool("Точка", false));
    public final Setting.Bool hover = add(new Setting.Bool("Менять цвет при наводке", true));
    public final Setting.Color color = add(new Setting.Color("Цвет", 0xFFFFFF));

    public CustomCrosshair() {
        super("Crosshair", Category.VISUALS);
        description = "Настраиваемый прицел";
    }

    public void draw(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        int cx = mc.getWindow().getGuiScaledWidth() / 2, cy = mc.getWindow().getGuiScaledHeight() / 2;
        int size = sizeS.i(), th = thickS.i(), gap = gapS.i();
        int rgb = color.get();
        if (hover.get() && mc.hitResult instanceof EntityHitResult) rgb = 0xFF3232;
        int col = 0xFF000000 | rgb;
        int h1 = th / 2, h2 = th - h1;
        if (type.get() == 0) {
            int[][] r = {
                {cx - h1, cy - gap - size, cx + h2, cy - gap},
                {cx - h1, cy + gap, cx + h2, cy + gap + size},
                {cx - gap - size, cy - h1, cx - gap, cy + h2},
                {cx + gap, cy - h1, cx + gap + size, cy + h2}
            };
            if (outline.get()) for (int[] a : r) g.fill(a[0] - 1, a[1] - 1, a[2] + 1, a[3] + 1, 0xFF000000);
            for (int[] a : r) g.fill(a[0], a[1], a[2], a[3], col);
        }
        if (dot.get() || type.get() == 1) {
            int d = th + 1, a = d / 2;
            if (outline.get()) g.fill(cx - a - 1, cy - a - 1, cx - a + d + 1, cy - a + d + 1, 0xFF000000);
            g.fill(cx - a, cy - a, cx - a + d, cy - a + d, col);
        }
    }
}
