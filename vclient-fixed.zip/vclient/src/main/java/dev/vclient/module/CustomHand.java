package dev.vclient.module;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.vclient.setting.Setting;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;

/** Положение, поворот и размер рук и предметов от первого лица. Настройки задаются для правой руки, левая отражается. */
public class CustomHand extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Что менять", 0, "Всё", "Только руки", "Только предметы"));
    public final Setting.Num posX = add(new Setting.Num("Положение X", 0, -1.5, 1.5, 0.05));
    public final Setting.Num posY = add(new Setting.Num("Положение Y", 0, -1.5, 1.5, 0.05));
    public final Setting.Num posZ = add(new Setting.Num("Положение Z", 0, -1.5, 1.5, 0.05));
    public final Setting.Num rotX = add(new Setting.Num("Поворот X", 0, -180, 180, 5));
    public final Setting.Num rotY = add(new Setting.Num("Поворот Y", 0, -180, 180, 5));
    public final Setting.Num rotZ = add(new Setting.Num("Поворот Z", 0, -180, 180, 5));
    public final Setting.Num scale = add(new Setting.Num("Размер", 1.0, 0.2, 2.0, 0.05));
    public final Setting.Bool hide = add(new Setting.Bool("Скрыть руки", false));
    public final Setting.Bool noSwing = add(new Setting.Bool("Без взмаха", false));
    public final Setting.Num swingDelta = add(new Setting.Num("Скорость взмаха (тики)", 0, -5, 10, 1));
    public final Setting.Bool skipSwap = add(new Setting.Bool("Без анимации смены предмета", false));

    public CustomHand() {
        super("Custom Hand", Category.VISUALS);
        description = "Положение и анимации рук";
    }

    /** Применяет преобразование к матрице перед отрисовкой руки или предмета. */
    public void apply(PoseStack ps, InteractionHand hand, AbstractClientPlayer p) {
        HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
        float s = arm == HumanoidArm.RIGHT ? 1f : -1f;
        ps.mulPose(Axis.XP.rotationDegrees(rotX.f()));
        ps.mulPose(Axis.YP.rotationDegrees(rotY.f() * s));
        ps.mulPose(Axis.ZP.rotationDegrees(rotZ.f() * s));
        ps.translate(posX.f() * s, posY.f(), posZ.f());
        float sc = scale.f();
        ps.scale(sc, sc, sc);
    }
}
