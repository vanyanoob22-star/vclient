package dev.vclient.module;

import dev.vclient.gui.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Запоминает координаты последней смерти (из Really Visuals). */
public class DeathPoint extends HudModule {
    private String last;
    private boolean wasDead;

    public DeathPoint() {
        super("Death Point", "Координаты последней смерти", 1, 35);
        tickAlways = true;
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        boolean dead = mc.player.isDeadOrDying();
        if (dead && !wasDead) {
            last = Math.round(mc.player.getX()) + " " + Math.round(mc.player.getY()) + " " + Math.round(mc.player.getZ());
        }
        wasDead = dead;
    }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        List<String[]> rows = new ArrayList<>();
        if (sample) rows.add(new String[]{"XYZ", "120 64 -35"});
        else if (last != null) rows.add(new String[]{"XYZ", last});
        else return null;
        return Draw.panel(g, "Последняя смерть", rows, posX.get(), posY.get(), scale.f());
    }
}
