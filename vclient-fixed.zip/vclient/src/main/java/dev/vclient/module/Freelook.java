package dev.vclient.module;

import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Свободная камера на 360°: пока зажата клавиша, камера вращается отдельно от взгляда игрока. */
public class Freelook extends Module {
    public static boolean active;
    public static float yaw, pitch;

    public Freelook() {
        super("Freelook", Category.VISUALS);
        description = "Свободная камера 360°, пока зажата клавиша";
        key = GLFW.GLFW_KEY_LEFT_ALT;
        hold = true;
    }

    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
        active = true;
    }

    @Override public void onDisable() { active = false; }
}
