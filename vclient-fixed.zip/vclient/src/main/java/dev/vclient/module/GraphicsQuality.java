package dev.vclient.module;

import dev.vclient.gui.Quality;
import dev.vclient.setting.Setting;

/** Пресеты качества эффектов. Значения можно переопределить вручную. */
public class GraphicsQuality extends Module {
    public final Setting.Mode preset = add(new Setting.Mode("Пресет", 2,
            "Производительность", "Сбалансированный", "Высокое качество", "Ультра"));
    public final Setting.Bool custom = add(new Setting.Bool("Свои значения", false));
    public final Setting.Num density = add(new Setting.Num("Плотность частиц", 1.0, 0.2, 2.0, 0.1));
    public final Setting.Num glow = add(new Setting.Num("Яркость свечения", 1.0, 0.0, 1.5, 0.1));
    public final Setting.Num distance = add(new Setting.Num("Дальность эффектов", 32, 8, 64, 4));

    public GraphicsQuality() {
        super("Качество графики", Category.SETTINGS);
        description = "Нагрузка эффектов: от экономии до максимума";
        enabled = true;
        tickAlways = true;
    }

    @Override public void onTick() {
        Quality.apply(preset.get());
        if (custom.get()) {
            Quality.particles = density.f();
            Quality.glow = glow.f();
            Quality.distance = distance.get();
        }
    }
}
