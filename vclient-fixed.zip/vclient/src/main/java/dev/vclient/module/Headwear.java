package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Ореол, рога, кошачьи уши, шляпа мага и парящая корона. */
public class Headwear extends Module {
    public final Setting.Mode type = add(new Setting.Mode("Вид", 0, "Ореол", "Рога", "Кошачьи уши", "Шляпа мага", "Парящая корона"));
    public final Setting.Num size = add(new Setting.Num("Размер", 1.0, 0.5, 2.0, 0.05));
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", false));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xFFE680));

    public Headwear() {
        super("Головные уборы", Category.COSMETICS);
        description = "Ореол, рога, уши, шляпа, корона";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        for (Player p : mc.level.players()) {
            if (Cos.shows(mc, p, self.get(), others.get(), 32)) draw(g, p);
        }
    }

    private void draw(GuiGraphicsExtractor g, Player p) {
        float pt = VClient.partial;
        Vec3 pos = p.getPosition(pt);
        double yaw = Cos.bodyYaw(p, pt), top = p.getBbHeight(), sz = size.get();
        double t = System.currentTimeMillis() / 1000.0;
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        int c = Draw.alpha(rgb, 0xE0);
        switch (type.get()) {
            case 0 -> {
                Vec3 c0 = pos.add(0, top + 0.28 * sz + 0.03 * Math.sin(t * 2), 0);
                Projection.ring(g, c0, 0.26 * sz, 24, 2, c);
                Projection.ring(g, c0, 0.32 * sz, 24, 1, Draw.alpha(rgb, 0x60));
            }
            case 1 -> {
                for (int side = -1; side <= 1; side += 2) {
                    Vec3 a = Cos.local(pos, yaw, side * 0.2, top - 0.02, 0.02);
                    Vec3 b = Cos.local(pos, yaw, side * 0.3 * sz, top + 0.14 * sz, 0.02);
                    Vec3 d = Cos.local(pos, yaw, side * 0.27 * sz, top + 0.32 * sz, 0.02);
                    Vec3 e = Cos.local(pos, yaw, side * 0.2 * sz, top + 0.4 * sz, 0.02);
                    Projection.line(g, a, b, 3, c);
                    Projection.line(g, b, d, 2, c);
                    Projection.line(g, d, e, 2, c);
                }
            }
            case 2 -> {
                for (int side = -1; side <= 1; side += 2) {
                    Vec3 a = Cos.local(pos, yaw, side * 0.08, top, 0.02);
                    Vec3 b = Cos.local(pos, yaw, side * 0.24, top, 0.02);
                    Vec3 d = Cos.local(pos, yaw, side * 0.18, top + 0.2 * sz, 0.02);
                    Projection.line(g, a, b, 2, c);
                    Projection.line(g, b, d, 2, c);
                    Projection.line(g, d, a, 2, c);
                }
            }
            case 3 -> {
                Vec3 base = pos.add(0, top + 0.02, 0);
                double r = 0.3 * sz;
                Vec3 apex = Cos.local(pos, yaw, 0, top + 0.6 * sz, -0.12 * sz);
                Projection.ring(g, base, r * 1.5, 24, 2, c);
                Projection.ring(g, base.add(0, 0.05, 0), r, 20, 2, c);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    Projection.line(g, base.x + Math.cos(a) * r, base.y + 0.05, base.z + Math.sin(a) * r, apex.x, apex.y, apex.z, 1, Draw.alpha(rgb, 0x90));
                }
            }
            default -> {
                Vec3 b = pos.add(0, top + 0.3 * sz + 0.03 * Math.sin(t * 2), 0);
                int n = 10;
                double r = 0.32 * sz, h = 0.2 * sz, px = b.x + Math.cos(t) * r, py = b.y, pz = b.z + Math.sin(t) * r;
                for (int i = 1; i <= n; i++) {
                    double a = t + i * 2 * Math.PI / n;
                    double x = b.x + Math.cos(a) * r, z = b.z + Math.sin(a) * r, y = b.y + ((i & 1) == 0 ? 0 : h);
                    Projection.line(g, px, py, pz, x, y, z, 2, c);
                    px = x; py = y; pz = z;
                }
                Projection.ring(g, b, r, 20, 2, c);
            }
        }
    }
}
