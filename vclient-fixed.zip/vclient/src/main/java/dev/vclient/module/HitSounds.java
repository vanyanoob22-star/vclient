package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;

public class HitSounds extends Module {
    public final Setting.Mode sound = add(new Setting.Mode("Звук", 0, "Опыт", "Уровень", "Стрела"));
    public final Setting.Num volume = add(new Setting.Num("Громкость", 0.8, 0.1, 1.0, 0.1));
    public final Setting.Num pitch = add(new Setting.Num("Высота", 1.0, 0.5, 2.0, 0.1));

    public HitSounds() {
        super("Hit Sounds", Category.COMBAT);
        description = "Кастомные звуки попаданий";
    }

    @Override public void onAttack(Entity e) {
        SoundEvent ev = switch (sound.get()) {
            case 1 -> SoundEvents.PLAYER_LEVELUP;
            case 2 -> SoundEvents.ARROW_HIT_PLAYER;
            default -> SoundEvents.EXPERIENCE_ORB_PICKUP;
        };
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ev, pitch.f(), volume.f()));
    }
}
