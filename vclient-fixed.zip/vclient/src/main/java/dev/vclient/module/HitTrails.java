package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Линия от тебя к цели в момент удара, которая плавно гаснет. */
public class HitTrails extends Module {
    private static class T { Vec3 a, b; long t0; }

    public final Setting.Num duration = add(new Setting.Num("Длительность, сек", 1.0, 0.3, 3.0, 0.1));
    public final Setting.Num thick = add(new Setting.Num("Толщина", 2, 1, 4, 1));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));
    private final List<T> list = new ArrayList<>();

    public HitTrails() {
        super("Hit Trails", Category.COMBAT);
        description = "Трейсеры ударов";
    }

    @Override public void onAttack(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        T t = new T();
        t.a = mc.player.getEyePosition(VClient.partial).add(0, -0.3, 0);
        t.b = e.getPosition(VClient.partial).add(0, e.getBbHeight() * 0.5, 0);
        t.t0 = System.currentTimeMillis();
        list.add(t);
        while (list.size() > 10) list.remove(0);
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!Projection.ready) return;
        long now = System.currentTimeMillis();
        list.removeIf(t -> (now - t.t0) / 1000.0 > duration.get());
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        for (T t : list) {
            double age = (now - t.t0) / 1000.0 / duration.get();
            int a = (int) (0xE0 * (1 - age));
            if (a < 8) continue;
            Projection.line(g, t.a, t.b, thick.i(), Draw.alpha(rgb, a));
        }
    }
}
