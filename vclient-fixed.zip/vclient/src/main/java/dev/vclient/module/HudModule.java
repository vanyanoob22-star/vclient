package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Блок HUD: позицию и размер можно менять в редакторе HUD. */
public abstract class HudModule extends Module {
    public final Setting.Num posX, posY, scale;
    public final double defX, defY;

    protected HudModule(String name, String desc, double x, double y) {
        super(name, Category.HUD);
        this.description = desc;
        this.defX = x;
        this.defY = y;
        posX = add(new Setting.Num("Позиция X, %", x, 0, 100, 1));
        posY = add(new Setting.Num("Позиция Y, %", y, 0, 100, 1));
        scale = add(new Setting.Num("Размер", 1.0, 0.5, 2.5, 0.1));
    }

    /** Рисует блок и возвращает рамку {x, y, w, h}. sample = true в редакторе: рисуем пример. null, если рисовать нечего. */
    public abstract int[] draw(GuiGraphicsExtractor g, boolean sample);

    @Override public void onHud(GuiGraphicsExtractor g) { draw(g, false); }

    public void resetPlacement() {
        posX.set(defX);
        posY.set(defY);
        scale.set(1.0);
    }
}
