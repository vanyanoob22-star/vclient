package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.Vec3;

/** FPS, пинг, координаты и скорость. */
public class InfoHud extends HudModule {
    public final Setting.Bool fps = add(new Setting.Bool("FPS", true));
    public final Setting.Bool ping = add(new Setting.Bool("Пинг", true));
    public final Setting.Bool coords = add(new Setting.Bool("Координаты", true));
    public final Setting.Bool speed = add(new Setting.Bool("Скорость", true));

    public InfoHud() { super("Info", "FPS, пинг, координаты, скорость", 1, 55); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        List<String[]> rows = new ArrayList<>();
        Minecraft mc = Minecraft.getInstance();
        if (sample) {
            if (fps.get()) rows.add(new String[]{"FPS", "144"});
            if (ping.get()) rows.add(new String[]{"Пинг", "52 ms"});
            if (coords.get()) rows.add(new String[]{"XYZ", "120 64 -35"});
            if (speed.get()) rows.add(new String[]{"Скорость", "5.6 b/s"});
        } else {
            if (mc.player == null) return null;
            if (fps.get()) rows.add(new String[]{"FPS", String.valueOf(mc.getFps())});
            if (ping.get()) {
                var conn = mc.getConnection();
                var info = conn == null ? null : conn.getPlayerInfo(mc.player.getUUID());
                if (info != null) rows.add(new String[]{"Пинг", info.getLatency() + " ms"});
            }
            if (coords.get()) rows.add(new String[]{"XYZ", Math.round(mc.player.getX()) + " " + Math.round(mc.player.getY()) + " " + Math.round(mc.player.getZ())});
            if (speed.get()) {
                Vec3 d = mc.player.getDeltaMovement();
                rows.add(new String[]{"Скорость", String.format("%.1f b/s", Math.sqrt(d.x * d.x + d.z * d.z) * 20)});
            }
        }
        if (rows.isEmpty()) return null;
        return Draw.panel(g, "Info", rows, posX.get(), posY.get(), scale.f());
    }
}
