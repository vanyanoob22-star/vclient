package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.UiStyle;
import dev.vclient.setting.Setting;

/** Гибкая настройка внешнего вида: пресеты, скругление, скорость анимаций, размеры меню и HUD, избранное. */
public class InterfaceStyle extends Module {
    private static final String[] NAMES = {"Космос", "Океан", "Лайм", "Закат", "Минимализм", "Стекло"};
    //                                акцент    фон       прозр.  скругл.
    private static final int[][] PRESETS = {
        {0xA64DFF, 0x101015, 200, 100},
        {0x2EA8FF, 0x0B1620, 205, 120},
        {0x7CFF4D, 0x0F1510, 200, 100},
        {0xFF6A4D, 0x1A1012, 205, 130},
        {0xFFFFFF, 0x0A0A0A, 235, 20},
        {0x7FD6FF, 0x16202A, 130, 160},
    };

    public final Setting.Mode preset = add(new Setting.Mode("Пресет", 0, NAMES));
    public final Setting.Action applyPreset = add(new Setting.Action("Применить пресет", this::applyPreset));
    public final Setting.Num round = add(new Setting.Num("Скругление, %", 100, 0, 200, 10));
    public final Setting.Num animSpeed = add(new Setting.Num("Скорость анимаций, %", 100, 30, 300, 10));
    public final Setting.Num menuW = add(new Setting.Num("Ширина меню, %", 56, 40, 95, 1));
    public final Setting.Num menuH = add(new Setting.Num("Высота меню, %", 62, 40, 95, 1));
    public final Setting.Num side = add(new Setting.Num("Ширина сайдбара", 112, 80, 180, 2));
    public final Setting.Num hud = add(new Setting.Num("Размер всего HUD, %", 100, 50, 200, 5));
    public final Setting.Bool openAnim = add(new Setting.Bool("Анимация открытия меню", true));
    public final Setting.Bool sounds = add(new Setting.Bool("Звуки интерфейса", true));
    public final Setting.Bool compact = add(new Setting.Bool("Компактные карточки", false));
    public final Setting.Str favorites = add(new Setting.Str("Избранные модули (список)", ""));
    public final Setting.Action reset = add(new Setting.Action("Сбросить стиль", this::resetStyle));

    private String lastFavs = null;

    public InterfaceStyle() {
        super("Стиль интерфейса", Category.SETTINGS);
        description = "Пресеты, скругление, анимации, размеры меню и HUD";
        enabled = true;
        tickAlways = true;
        UiStyle.bindFavSink(csv -> { favorites.set(csv); lastFavs = csv; });
    }

    private static void setRgb(Setting.Color c, int rgb) {
        String cur = c.hex();
        boolean hash = cur.startsWith("#");
        String body = cur.replace("#", "");
        String out = String.format("%06X", rgb & 0xFFFFFF);
        if (body.length() == 8) out = body.substring(0, 2) + out;
        c.setHex((hash ? "#" : "") + out);
    }

    private void applyPreset() {
        int[] p = PRESETS[Math.max(0, Math.min(PRESETS.length - 1, preset.get()))];
        for (Object o : VClient.modules.modules) {
            if (o instanceof ThemeSettings t) {
                setRgb(t.accent, p[0]);
                setRgb(t.panel, p[1]);
                t.alpha.set(Double.valueOf(p[2]));
            }
        }
        round.set(Double.valueOf(p[3]));
    }

    private void resetStyle() {
        round.set(Double.valueOf(100));
        animSpeed.set(Double.valueOf(100));
        menuW.set(Double.valueOf(56));
        menuH.set(Double.valueOf(62));
        side.set(Double.valueOf(112));
        hud.set(Double.valueOf(100));
        openAnim.set(Boolean.TRUE);
        sounds.set(Boolean.TRUE);
        compact.set(Boolean.FALSE);
    }

    @Override public void onTick() {
        UiStyle.roundness = round.f() / 100f;
        UiStyle.anim = animSpeed.f() / 100f;
        UiStyle.menuW = menuW.f() / 100f;
        UiStyle.menuH = menuH.f() / 100f;
        UiStyle.side = side.i();
        UiStyle.hud = hud.f() / 100f;
        UiStyle.openAnim = openAnim.get();
        UiStyle.sounds = sounds.get();
        UiStyle.compact = compact.get();
        String f = favorites.get();
        if (!f.equals(lastFavs)) { lastFavs = f; UiStyle.setFavs(f); }
    }
}
