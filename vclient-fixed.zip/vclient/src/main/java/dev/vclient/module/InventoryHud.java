package dev.vclient.module;

import dev.vclient.gui.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Содержимое инвентаря (3 ряда) на экране (из Really Visuals). */
public class InventoryHud extends HudModule {
    public InventoryHud() { super("Inventory", "Предметы из инвентаря на экране", 60, 90); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        Minecraft mc = Minecraft.getInstance();
        if (!sample && mc.player == null) return null;
        int w = 9 * 18 + 8, h = 3 * 18 + 8;
        int[] r = Draw.place(posX.get(), posY.get(), w, h, scale.f());
        Draw.begin(g, r[0], r[1], scale.f());
        Draw.rrect(g, 0, 0, w, h, 6, Draw.panelBg());
        if (sample) {
            g.text(mc.font, "Инвентарь", (w - mc.font.width("Инвентарь")) / 2, h / 2 - 4, 0xFF9A9AAA);
        } else {
            Inventory inv = mc.player.getInventory();
            for (int i = 0; i < 27; i++) {
                ItemStack st = inv.getItem(9 + i);
                if (st.isEmpty()) continue;
                g.item(st, 4 + (i % 9) * 18 + 1, 4 + (i / 9) * 18 + 1);
            }
        }
        Draw.end(g);
        return r;
    }
}
