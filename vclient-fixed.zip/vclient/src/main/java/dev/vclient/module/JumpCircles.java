package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.Vec3;

public class JumpCircles extends Module {
    private static class Circle { Vec3 pos; long t0; double k = 1; }

    public final Setting.Num duration = add(new Setting.Num("Длительность, сек", 1.0, 0.3, 3.0, 0.1));
    public final Setting.Num maxRadius = add(new Setting.Num("Радиус", 1.6, 0.5, 4.0, 0.1));
    public final Setting.Num thick = add(new Setting.Num("Толщина", 2, 1, 4, 1));
    public final Setting.Bool landing = add(new Setting.Bool("Круг при приземлении", true));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    private final List<Circle> circles = new ArrayList<>();
    private boolean wasGround = true;
    private int air;

    public JumpCircles() {
        super("Jump Circles", Category.VISUALS);
        description = "Круги при прыжке и приземлении";
        tickAlways = true;
    }

    private void spawn(Minecraft mc, double k) {
        Circle c = new Circle();
        c.pos = mc.player.position();
        c.t0 = System.currentTimeMillis();
        c.k = k;
        circles.add(c);
        while (circles.size() > 8) circles.remove(0);
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        boolean ground = mc.player.onGround();
        if (enabled && wasGround && !ground && mc.player.getDeltaMovement().y > 0.1) spawn(mc, 1.0);
        if (!ground) air++;
        else {
            if (enabled && landing.get() && !wasGround && air >= 6) spawn(mc, 0.6);
            air = 0;
        }
        wasGround = ground;
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!Projection.ready) return;
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        long now = System.currentTimeMillis();
        circles.removeIf(c -> (now - c.t0) / 1000.0 > duration.get());
        for (Circle c : circles) {
            double age = (now - c.t0) / 1000.0 / duration.get();
            double eased = 1 - Math.pow(1 - age, 3);
            int a = (int) (0xD0 * (1 - age));
            if (a < 8) continue;
            Projection.ring(g, c.pos.add(0, 0.03, 0), 0.3 + maxRadius.get() * c.k * eased, 28, thick.i(), Draw.alpha(rgb, a));
        }
    }
}
