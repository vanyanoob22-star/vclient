package dev.vclient.module;

import dev.vclient.gui.Anim;
import dev.vclient.gui.Draw;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Клавиши WASD и пробел с плавной подсветкой (из Really Visuals). */
public class Keystrokes extends HudModule {
    private final float[] t = new float[5];
    private long last = System.nanoTime();

    public Keystrokes() { super("Keystrokes", "Нажатые клавиши движения", 1, 15); }

    private void key(GuiGraphicsExtractor g, Minecraft mc, int x, int y, int w, int h, String label, float v) {
        int base = Draw.panelBg() & 0xFFFFFF;
        int on = Draw.ACCENT & 0xFFFFFF;
        int alpha = 150 + (int) (90 * v);
        Draw.rrect(g, x, y, w, h, 4, (alpha << 24) | (Anim.lerpColor(base, on, v) & 0xFFFFFF));
        g.text(mc.font, label, x + (w - mc.font.width(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        Minecraft mc = Minecraft.getInstance();
        if (!sample && (mc.player == null || mc.options == null)) return null;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        KeyMapping[] keys = sample ? null : new KeyMapping[]{
            mc.options.keyUp, mc.options.keyLeft, mc.options.keyDown, mc.options.keyRight, mc.options.keyJump};
        for (int i = 0; i < 5; i++) {
            float target = keys != null && keys[i].isDown() ? 1f : 0f;
            t[i] = Anim.approach(t[i], target, dt, 22f);
        }
        int w = 64, h = 64;
        int[] r = Draw.place(posX.get(), posY.get(), w, h, scale.f());
        Draw.begin(g, r[0], r[1], scale.f());
        key(g, mc, 22, 0, 20, 20, "W", t[0]);
        key(g, mc, 0, 22, 20, 20, "A", t[1]);
        key(g, mc, 22, 22, 20, 20, "S", t[2]);
        key(g, mc, 44, 22, 20, 20, "D", t[3]);
        key(g, mc, 0, 44, 64, 20, "ПРОБЕЛ", t[4]);
        Draw.end(g);
        return r;
    }
}
