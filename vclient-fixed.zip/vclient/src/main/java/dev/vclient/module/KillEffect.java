package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Эффект после убийства: луч вверх и расходящиеся волны. Предпросмотр есть в меню. */
public class KillEffect extends Module {
    private static class Fx { Vec3 pos; long t0; }

    private final List<Fx> list = new ArrayList<>();
    private long previewT0 = System.currentTimeMillis();
    private LivingEntity handled;

    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));
    public final Setting.Num height = add(new Setting.Num("Высота луча", 8, 2, 20, 1));
    public final Setting.Num width = add(new Setting.Num("Ширина луча", 0.25, 0.05, 0.6, 0.05));
    public final Setting.Num duration = add(new Setting.Num("Длительность, сек", 1.6, 0.5, 4.0, 0.1));
    public final Setting.Num radius = add(new Setting.Num("Радиус волны", 5, 1, 10, 0.5));
    public final Setting.Num waves = add(new Setting.Num("Количество волн", 3, 1, 5, 1));
    public final Setting.Num thick = add(new Setting.Num("Толщина", 2, 1, 4, 1));
    public final Setting.Bool playersOnly = add(new Setting.Bool("Только игроки", false));
    public final Setting.Action restart = add(new Setting.Action("Перезапустить превью", () -> this.previewT0 = System.currentTimeMillis()));
    public final Setting.Action inWorld = add(new Setting.Action("Показать в мире (модуль должен быть включён)", this::spawnInFront));

    public KillEffect() {
        super("KillEffect", Category.VISUALS);
        description = "Луч и волны после убийства";
    }

    private void spawnInFront() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Vec3 look = mc.player.getViewVector(1f);
        add(mc.player.position().add(look.x * 4, 0, look.z * 4));
    }

    private void add(Vec3 pos) {
        Fx f = new Fx();
        f.pos = pos;
        f.t0 = System.currentTimeMillis();
        list.add(f);
        while (list.size() > 6) list.remove(0);
    }

    @Override public void onTick() {
        LivingEntity t = VClient.lastTarget;
        if (t == null || t == handled) return;
        if (System.currentTimeMillis() - VClient.lastTargetTime > 8000) return;
        if (t.isDeadOrDying() || t.getHealth() <= 0f) {
            handled = t;
            if (!playersOnly.get() || t instanceof Player) add(t.position());
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (!Projection.ready) return;
        long now = System.currentTimeMillis();
        list.removeIf(f -> (now - f.t0) / 1000.0 > duration.get());
        for (Fx f : list) renderFx(g, f.pos, (now - f.t0) / 1000.0 / duration.get());
    }

    private static double easeOut(double x) { return 1 - Math.pow(1 - Math.max(0, Math.min(1, x)), 3); }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Рисует эффект в точке pos. age от 0 до 1. */
    private void renderFx(GuiGraphicsExtractor g, Vec3 pos, double age) {
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        int core = mix(rgb, 0xFFFFFF, 0.55);
        double grow = easeOut(age / 0.2);
        double fade = age < 0.6 ? 1.0 : Math.max(0, 1 - (age - 0.6) / 0.4);
        double h = height.get() * grow;
        double w = width.get();
        int n = 8;
        for (int k = 0; k < n; k++) {
            double y0 = h * k / n, y1 = h * (k + 1) / n;
            double a = fade * (1 - (double) k / n * 0.85);
            int al = (int) (0xE0 * a);
            if (al < 6) continue;
            Projection.line(g, pos.add(0, y0, 0), pos.add(0, y1, 0), 3, Draw.alpha(core, al));
            for (int j = 0; j < 4; j++) {
                double ang = j * Math.PI / 2 + age * 2.0;
                Vec3 off = new Vec3(Math.cos(ang) * w, 0, Math.sin(ang) * w);
                Projection.line(g, pos.add(off).add(0, y0, 0), pos.add(off).add(0, y1, 0), 1, Draw.alpha(rgb, (int) (al * 0.7)));
            }
        }
        int wn = waves.i();
        for (int i = 0; i < wn; i++) {
            double wa = (age - i * 0.12) / 0.75;
            if (wa <= 0 || wa >= 1) continue;
            int al = (int) (0xD0 * (1 - wa));
            if (al < 6) continue;
            Projection.ring(g, pos.add(0, 0.05, 0), radius.get() * easeOut(wa), 40, thick.i(), Draw.alpha(rgb, al));
        }
    }

    // ---------- предпросмотр в меню ----------
    @Override public int previewHeight() { return 120; }

    @Override public void drawPreview(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        long now = System.currentTimeMillis();
        double d = duration.get();
        double tt = ((now - previewT0) / 1000.0) % (d + 0.8);
        double age = tt / d;
        double bh = height.get();
        double dist = Math.max(7, Math.max(bh * 1.5, radius.get() * 1.9));
        Vec3 target = new Vec3(0, bh * 0.4, 0);
        float yaw = (float) ((now / 1000.0 * 18) % 360);
        float pitch = 18f;
        Vec3 eye = target.subtract(Projection.look(yaw, pitch).scale(dist));
        Projection.setCamera(eye, yaw, pitch, 60, w, h, x, y);
        g.enableScissor(x, y, x + w, y + h);
        Projection.ring(g, new Vec3(0, 0.02, 0), radius.get(), 40, 1, 0x30FFFFFF);
        Projection.line(g, new Vec3(0, 0, 0), new Vec3(0, 1.8, 0), 2, 0x55FFFFFF);
        if (age < 1) renderFx(g, Vec3.ZERO, age);
        g.disableScissor();
        Projection.update(VClient.partial);
    }
}
