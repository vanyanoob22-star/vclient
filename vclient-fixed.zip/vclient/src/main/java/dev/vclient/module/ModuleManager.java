package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Anim;
import dev.vclient.gui.Projection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import org.lwjgl.glfw.GLFW;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    public final CustomCrosshair crosshair = new CustomCrosshair();
    public final Waypoints waypoints = new Waypoints();
    public final CustomHand customHand = new CustomHand();
    public final Relations relations = new Relations();
    public final Zoom zoom = new Zoom();
    public final RenderTweaks renderTweaks = new RenderTweaks();
    public final NoFluid noFluid = new NoFluid();
    public final NoJumpDelay noJumpDelay = new NoJumpDelay();
    public final ClearInventory clearInventory = new ClearInventory();
    public final CosmeticAura aura = new CosmeticAura();
    public final CosmeticWings wings = new CosmeticWings();
    public final CosmeticTrail trails = new CosmeticTrail();
    public final WorldParticles particles = new WorldParticles();
    public final CosmeticOrbits orbits = new CosmeticOrbits();
    public final Headwear headwear = new Headwear();
    public final CucumberCursor cucumberCursor = new CucumberCursor();
    public final ChestTracker chestTracker = new ChestTracker();
    public final TimeChanger timeChanger = new TimeChanger();
    public final AspectRatio aspectRatio = new AspectRatio();
    public final TotemPop totemPop = new TotemPop();
    private final Map<Module, Boolean> wasDown = new HashMap<>();

    public ModuleManager() {
        // Визуалы
        modules.add(new Fullbright());
        modules.add(zoom);
        modules.add(new Freelook());
        modules.add(renderTweaks);
        modules.add(noFluid);
        modules.add(clearInventory);
        modules.add(crosshair);
        modules.add(customHand);
        modules.add(new TargetEsp());
        modules.add(new ChinaHat());
        modules.add(new JumpCircles());
        modules.add(new EntityBoxes());
        modules.add(new PulseVisuals());
        modules.add(new Predictions());
        modules.add(new KillEffect());
        modules.add(timeChanger);
        modules.add(aspectRatio);

        // HUD
        modules.add(new Cooldowns());
        modules.add(new Potions());
        modules.add(new BetterNear());
        modules.add(new TargetHud());
        modules.add(new InfoHud());
        modules.add(new ArmorHud());
        modules.add(new InventoryHud());
        modules.add(new DeathPoint());
        modules.add(new Keystrokes());
        modules.add(new WebHub());
        modules.add(new CombatStats());

        // Бой
        modules.add(new ArmorNotifier());
        modules.add(new HitSounds());
        modules.add(new HitTrails());
        modules.add(new RadiusPreview());
        modules.add(relations);

        // Утилиты
        modules.add(new AutoClicker());
        modules.add(new AutoCommand());
        modules.add(new ClickPearl());
        modules.add(noJumpDelay);
        modules.add(new AutoSprint());
        modules.add(chestTracker);
        modules.add(new ChestTrackerOpen());

        // Метки
        modules.add(waypoints);
        modules.add(new WaypointActions("Быстрая метка", "Метка там, куда смотришь", false));
        modules.add(new WaypointActions("Очистить метки", "Удалить все метки", true));

        // Сервер
        modules.add(new AutoSell("Автопродажа: рыба", "/sellfish"));
        modules.add(new AutoSell("Автопродажа: ферма", "/sellfarm"));
        modules.add(new AutoSell("Автопродажа: шахта", "/sellmine"));
        modules.add(new CommandBind("Sell All", "/sell all"));
        modules.add(new CommandBind("Sell Hand", "/sell hand"));
        modules.add(new CommandBind("Home", "/home"));
        modules.add(new CommandBind("Set Home", "/sethome"));
        modules.add(new CommandBind("Spawn", "/spawn"));
        modules.add(new CommandBind("RTP", "/rtp"));
        modules.add(new CommandBind("Kit", "/kit"));
        modules.add(new CommandBind("Repair All", "/repair all"));
        modules.add(new CommandBind("Heal", "/heal"));
        modules.add(new CommandBind("Feed", "/feed"));

        // Мемы
        modules.add(cucumberCursor);
        modules.add(new CucumberCrown());
        modules.add(new CucumberDeath());
        modules.add(new CucumberSword());
        modules.add(new CucumberNick());
        modules.add(totemPop);

        // Косметика
        modules.add(aura);
        modules.add(wings);
        modules.add(trails);
        modules.add(particles);
        modules.add(orbits);
        modules.add(headwear);
        modules.add(new Watermark());
        modules.add(new Presets());

        // Тема
        modules.add(new ThemeSettings());
        modules.add(new InterfaceStyle());
        modules.add(new GraphicsQuality());
        modules.add(new Optimizer());
    }

    public Module get(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        boolean canPress = mc.gui.screen() == null && mc.player != null;
        long handle = mc.getWindow().handle();

        for (Module m : modules) {
            if (canPress && m.key > 0) {
                boolean down = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
                boolean was = wasDown.getOrDefault(m, false);
                if (m.hold) {
                    m.setEnabled(down);
                } else if (down && !was) {
                    m.toggle();
                }
                wasDown.put(m, down);
            } else if (m.hold && m.enabled && mc.gui.screen() != null) {
                m.setEnabled(false);
            }
            if (m.enabled || m.tickAlways) m.onTick();
        }
    }

    public void renderHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Anim.tick();
        Projection.update(VClient.partial);
        for (Module m : modules) if (m.enabled) m.onHud(g);
    }

    public void attacked(Entity e) {
        for (Module m : modules) if (m.enabled) m.onAttack(e);
    }
}
