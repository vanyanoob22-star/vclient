package dev.vclient.module;

import dev.vclient.VClient;

/** Убирает туман и наложение экрана в воде и лаве. */
public class NoFluid extends Module {
    public NoFluid() {
        super("No Fluid", Category.VISUALS);
        description = "Убирает туман и наложение в жидкостях";
    }

    public static boolean on() { return VClient.modules != null && VClient.modules.noFluid.enabled; }
}
