package dev.vclient.module;

import dev.vclient.VClient;

/** Убирает задержку между прыжками при зажатом пробеле. */
public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("No Jump Delay", Category.UTILITIES);
        description = "Нет задержки между прыжками";
    }

    public static boolean on() { return VClient.modules != null && VClient.modules.noJumpDelay.enabled; }
}
