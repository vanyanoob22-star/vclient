package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.setting.Setting;
import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;

/**
 * Оптимизация: профили дальности прорисовки, динамическая дальность по FPS и чистка памяти.
 * Параметры игры меняются через OptionInstance (рефлексия), поэтому модуль не ломается при смене имён.
 */
public class Optimizer extends Module {
    public final Setting.Mode profile = add(new Setting.Mode("Профиль", 1,
            "Производительность", "Сбалансированный", "Качество"));
    public final Setting.Action apply = add(new Setting.Action("Применить профиль", this::applyProfile));
    public final Setting.Bool dynamic = add(new Setting.Bool("Динамическая дальность", true));
    public final Setting.Num target = add(new Setting.Num("Целевой FPS", 90, 30, 240, 5));
    public final Setting.Num minDist = add(new Setting.Num("Мин. дальность, чанки", 6, 2, 32, 1));
    public final Setting.Num maxDist = add(new Setting.Num("Макс. дальность, чанки", 16, 4, 32, 1));
    public final Setting.Bool memory = add(new Setting.Bool("Чистка памяти", true));

    private int ticks;
    private long lastGc;
    private boolean warned;

    public Optimizer() {
        super("Оптимизация", Category.SETTINGS);
        description = "Дальность прорисовки по FPS, профили, чистка памяти";
    }

    private static Object opt(String method) {
        try {
            Method m = Minecraft.getInstance().options.getClass().getMethod(method);
            return m.invoke(Minecraft.getInstance().options);
        } catch (Throwable t) { return null; }
    }

    private static Integer getInt(String method) {
        Object o = opt(method);
        if (o == null) return null;
        try { Object v = o.getClass().getMethod("get").invoke(o); return v instanceof Integer i ? i : null; }
        catch (Throwable t) { return null; }
    }

    private static boolean setInt(String method, int v) {
        Object o = opt(method);
        if (o == null) return false;
        try { o.getClass().getMethod("set", Object.class).invoke(o, v); return true; }
        catch (Throwable t) { return false; }
    }

    private void applyProfile() {
        int p = profile.get();
        int rd = p == 0 ? 8 : p == 1 ? 12 : 16;
        int sd = p == 0 ? 6 : p == 1 ? 8 : 12;
        boolean ok = setInt("renderDistance", rd);
        setInt("simulationDistance", sd);
        if (!ok && !warned) { warned = true; VClient.LOG.warn("Optimizer: renderDistance option not found"); }
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options == null) return;
        ticks++;
        if (dynamic.get() && ticks % 100 == 0) {
            Integer cur = getInt("renderDistance");
            if (cur != null) {
                int fps = mc.getFps(), t = target.i();
                int lo = Math.min(minDist.i(), maxDist.i()), hi = Math.max(minDist.i(), maxDist.i());
                if (fps < t * 0.85 && cur > lo) setInt("renderDistance", cur - 1);
                else if (fps > t * 1.3 && cur < hi) setInt("renderDistance", cur + 1);
            }
        }
        if (memory.get() && ticks % 1200 == 0) {
            Runtime rt = Runtime.getRuntime();
            double used = (rt.totalMemory() - rt.freeMemory()) / (double) rt.maxMemory();
            long now = System.currentTimeMillis();
            if (used > 0.88 && now - lastGc > 60_000) { lastGc = now; System.gc(); }
        }
    }
}
