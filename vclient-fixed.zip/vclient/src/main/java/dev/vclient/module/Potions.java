package dev.vclient.module;

import dev.vclient.gui.Draw;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;

public class Potions extends HudModule {
    public Potions() { super("Potions", "Активные эффекты и время", 1, 20); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        List<String[]> rows = new ArrayList<>();
        if (sample) {
            rows.add(new String[]{"Absorption I", "1:54"});
            rows.add(new String[]{"Speed II", "0:42"});
        } else {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return null;
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                String name = e.getEffect().value().getDisplayName().getString();
                int amp = e.getAmplifier();
                if (amp > 0) name += " " + roman(amp + 1);
                String time;
                if (e.isInfiniteDuration()) time = "inf";
                else {
                    int s = e.getDuration() / 20;
                    time = (s / 60) + ":" + String.format("%02d", s % 60);
                }
                rows.add(new String[]{name, time});
            }
        }
        if (rows.isEmpty()) return null;
        return Draw.panel(g, "Potions", rows, posX.get(), posY.get(), scale.f());
    }

    private static String roman(int n) {
        return switch (n) { case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n); };
    }
}
