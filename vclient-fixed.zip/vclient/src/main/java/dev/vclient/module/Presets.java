package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.setting.Setting;

/** Быстрые наборы: одна кнопка включает и выключает нужные модули. */
public class Presets extends Module {
    private static final String[] COSMETIC_OFF = {"Аура", "Крылья", "Следы", "World Particles", "Орбиты", "Головные уборы"};

    public Presets() {
        super("Пресеты", Category.COSMETICS);
        description = "Минимализм, красивый, ангел, PvP, FPS, кино";
        add(new Setting.Action("Минимализм (косметика выключена)", () -> cosmeticsOff()));
        add(new Setting.Action("Красивый (аура, следы, магия)", () -> {
            cosmeticsOff();
            VClient.modules.aura.type.setIndex(10); on("Аура");
            VClient.modules.trails.type.setIndex(2); on("Следы");
            VClient.modules.particles.type.setIndex(7); on("World Particles");
        }));
        add(new Setting.Action("Ангел (аура, крылья, ореол, звёзды)", () -> {
            cosmeticsOff();
            VClient.modules.aura.type.setIndex(0); on("Аура");
            VClient.modules.wings.type.setIndex(0); on("Крылья");
            VClient.modules.headwear.type.setIndex(0); on("Головные уборы");
            VClient.modules.particles.type.setIndex(0); on("World Particles");
        }));
        add(new Setting.Action("PvP (боевые модули)", () -> {
            cosmeticsOff();
            for (String n : new String[]{"Target ESP", "KillEffect", "Predictions", "Hit Trails", "Better Near", "Cooldowns"}) on(n);
        }));
        add(new Setting.Action("FPS (всё тяжёлое выключено)", () -> {
            cosmeticsOff();
            for (String n : new String[]{"Entity Boxes", "Jump Circles", "KillEffect", "Огуречная смерть", "Predictions", "Hit Trails", "Radius Preview"}) off(n);
        }));
        add(new Setting.Action("Кино (HUD выключен, красота включена)", () -> {
            for (Module m : VClient.modules.modules) if (m instanceof HudModule) m.setEnabled(false);
            VClient.modules.aura.type.setIndex(10); on("Аура");
            on("Следы"); on("World Particles");
        }));
    }

    private static void on(String name) { Module m = VClient.modules.get(name); if (m != null) m.setEnabled(true); }

    private static void off(String name) { Module m = VClient.modules.get(name); if (m != null) m.setEnabled(false); }

    private static void cosmeticsOff() { for (String n : COSMETIC_OFF) off(n); }
}
