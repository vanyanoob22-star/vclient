package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Anim;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.gui.Quality;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Пульсирующий контур с бегущим градиентом, волны от ног и искры. Есть предпросмотр в меню. */
public class PulseVisuals extends Module {
    static final String[] STYLES = {"Сердцебиение", "Энергия", "Волна", "Неон", "Мерцание"};
    static final int[][] COL = {{0xFF3A5C, 0xFF9AB0}, {0x4DC3FF, 0xA64DFF}, {0x37E0C0, 0x4D7CFF}, {0xA64DFF, 0x55D26B}, {0xFFF3B0, 0xFFFFFF}};
    static final int[] WAVES = {2, 3, 4, 1, 2};

    public final Setting.Mode style = add(new Setting.Mode("Стиль", 1, STYLES));
    public final Setting.Num speed = add(new Setting.Num("Скорость", 1.0, 0.2, 3.0, 0.1));
    public final Setting.Num intensity = add(new Setting.Num("Интенсивность", 1.0, 0.2, 2.0, 0.1));
    public final Setting.Num radius = add(new Setting.Num("Радиус волн", 1.5, 0.5, 3.0, 0.1));
    public final Setting.Num opacity = add(new Setting.Num("Непрозрачность", 200, 40, 255, 5));
    public final Setting.Bool outline = add(new Setting.Bool("Пульсирующий контур", true));
    public final Setting.Bool rings = add(new Setting.Bool("Волны от ног", true));
    public final Setting.Bool sparks = add(new Setting.Bool("Искры", true));
    public final Setting.Bool self = add(new Setting.Bool("Для себя (3-е лицо)", true));
    public final Setting.Bool others = add(new Setting.Bool("Для других игроков", true));
    public final Setting.Bool custom = add(new Setting.Bool("Свои цвета", false));
    public final Setting.Color c1 = add(new Setting.Color("Цвет 1", 0xA64DFF));
    public final Setting.Color c2 = add(new Setting.Color("Цвет 2", 0x4DC3FF));

    public PulseVisuals() {
        super("Pulse Visuals", Category.VISUALS);
        description = "Пульсирующие контуры и волны вокруг игроков";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        float pt = VClient.partial;
        for (Player p : mc.level.players()) {
            if (!Cos.shows(mc, p, self.get(), others.get(), 32)) continue;
            Vec3 base = p.getPosition(pt);
            AABB bb = p.getBoundingBox().move(base.subtract(p.position()));
            render(g, base, bb, p.getBbHeight());
        }
    }

    private static double beat(int st, double t) {
        double f = t - Math.floor(t);
        return switch (st) {
            case 0 -> Math.min(1, Math.exp(-Math.pow((f - 0.12) / 0.07, 2)) + 0.7 * Math.exp(-Math.pow((f - 0.34) / 0.07, 2)));
            case 4 -> Math.max(0, Math.min(1, 0.5 + 0.25 * Math.sin(2 * Math.PI * t * 3.1) + 0.25 * Math.sin(2 * Math.PI * t * 5.3 + 1)));
            default -> 0.5 + 0.5 * Math.sin(2 * Math.PI * t);
        };
    }

    private void render(GuiGraphicsExtractor g, Vec3 base, AABB bb, double h) {
        int st = style.get();
        int a1 = custom.get() ? c1.get() : COL[st][0], a2 = custom.get() ? c2.get() : COL[st][1];
        double t = Anim.time() * speed.get();
        double b = beat(st, t), inten = intensity.get();
        int op = opacity.i();
        int alpha = (int) Math.min(255, op * (0.45 + 0.55 * b * Math.min(1.5, inten)) * Math.max(0.3, Quality.glow));

        if (outline.get()) {
            AABB e = bb.inflate(0.02 + 0.05 * b * inten);
            int seg = Quality.ringSegs >= 40 ? 4 : 2;
            double phase = t * (st == 1 ? 1.2 : 0.5);
            int th = (b > 0.7 && inten >= 1) ? 2 : 1;
            loop(g, e.minX, e.minY, e.minZ, e.maxX, e.maxZ, seg, phase, a1, a2, alpha, th);
            loop(g, e.minX, e.maxY, e.minZ, e.maxX, e.maxZ, seg, phase, a1, a2, alpha, th);
            double[][] c = {{e.minX, e.minZ}, {e.maxX, e.minZ}, {e.maxX, e.maxZ}, {e.minX, e.maxZ}};
            for (int i = 0; i < 4; i++) {
                int col = Cos.mix(a1, a2, 0.5 + 0.5 * Math.sin(2 * Math.PI * (phase + i * 0.25)));
                Projection.line(g, c[i][0], e.minY, c[i][1], c[i][0], e.maxY, c[i][1], th, Draw.alpha(col, alpha));
            }
        }
        if (rings.get()) {
            int n = WAVES[st];
            for (int k = 0; k < n; k++) {
                double ph = ((t * 0.6 - (double) k / n) % 1.0 + 1.0) % 1.0;
                int al = (int) (op * (1 - ph) * Math.min(1, inten));
                if (al < 8) continue;
                Projection.ring(g, base.add(0, 0.04, 0), 0.2 + radius.get() * Anim.outCubic((float) ph), 36, 2, Draw.alpha(a1, al));
            }
        }
        if (sparks.get()) {
            int n = Math.max(2, Math.round(6 * Quality.particles));
            for (int i = 0; i < n; i++) {
                double ph = (t * 0.7 + (double) i / n) % 1.0, ang = i * 2.399963 + t * 0.8, rr = 0.45 + 0.1 * b;
                double[] s = Projection.project(base.x + Math.cos(ang) * rr, base.y + ph * h, base.z + Math.sin(ang) * rr);
                if (s == null) continue;
                int al = (int) (op * Math.sin(Math.PI * ph));
                if (al < 10) continue;
                int sz = Math.max(2, (int) Math.round(0.04 * Projection.pxPerBlock(s[2]) * 2));
                g.fill((int) s[0] - sz / 2, (int) s[1] - sz / 2, (int) s[0] + sz / 2 + 1, (int) s[1] + sz / 2 + 1, Draw.alpha(a2, al));
            }
        }
    }

    /** Прямоугольный контур с бегущим градиентом. */
    private void loop(GuiGraphicsExtractor g, double x0, double y, double z0, double x1, double z1, int seg,
                      double phase, int a1, int a2, int alpha, int th) {
        double[][] c = {{x0, z0}, {x1, z0}, {x1, z1}, {x0, z1}};
        int total = seg * 4, idx = 0;
        for (int s = 0; s < 4; s++) {
            double[] p = c[s], q = c[(s + 1) & 3];
            for (int k = 0; k < seg; k++) {
                double u0 = (double) k / seg, u1 = (double) (k + 1) / seg;
                double m = 0.5 + 0.5 * Math.sin(2 * Math.PI * (phase - (idx + 0.5) / total));
                Projection.line(g, p[0] + (q[0] - p[0]) * u0, y, p[1] + (q[1] - p[1]) * u0,
                        p[0] + (q[0] - p[0]) * u1, y, p[1] + (q[1] - p[1]) * u1, th, Draw.alpha(Cos.mix(a1, a2, m), alpha));
                idx++;
            }
        }
    }

    // ---------- предпросмотр в меню ----------
    @Override public int previewHeight() { return 110; }

    @Override public void drawPreview(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        double now = Anim.time();
        float yaw = (float) ((now * 18) % 360);
        Vec3 target = new Vec3(0, 1.0, 0);
        Vec3 eye = target.subtract(Projection.look(yaw, 14f).scale(5.5));
        Projection.setCamera(eye, yaw, 14f, 60, w, h, x, y);
        g.enableScissor(x, y, x + w, y + h);
        render(g, Vec3.ZERO, new AABB(-0.3, 0, -0.3, 0.3, 1.8, 0.3), 1.8);
        g.disableScissor();
        Projection.update(VClient.partial);
    }
}
