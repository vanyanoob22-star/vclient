package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.Vec3;

/** Кольцо заданного радиуса вокруг тебя (например, радиус действия донат-предметов). */
public class RadiusPreview extends Module {
    public final Setting.Num radius = add(new Setting.Num("Радиус, блоки", 5, 1, 40, 0.5));
    public final Setting.Num thick = add(new Setting.Num("Толщина", 2, 1, 4, 1));
    public final Setting.Bool clientColor = add(new Setting.Bool("Цвет клиента", true));
    public final Setting.Color color = add(new Setting.Color("Свой цвет", 0xA64DFF));

    public RadiusPreview() {
        super("Radius Preview", Category.COMBAT);
        description = "Кольцо радиуса вокруг игрока";
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !Projection.ready) return;
        int rgb = clientColor.get() ? dev.vclient.gui.Theme.rgb() : color.get();
        Vec3 p = mc.player.getPosition(VClient.partial);
        Projection.ring(g, p.add(0, 0.05, 0), radius.get(), 48, thick.i(), Draw.alpha(rgb, 0xD0));
    }
}
