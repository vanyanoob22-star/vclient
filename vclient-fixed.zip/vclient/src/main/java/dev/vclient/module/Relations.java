package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Списки друзей и врагов по нику: подсветка рядом, ник над головой, защита от удара по друзьям. */
public class Relations extends Module {
    public final Setting.Str friends = add(new Setting.Str("Друзья (ники через запятую)", ""));
    public final Setting.Str enemies = add(new Setting.Str("Враги (ники через запятую)", ""));
    public final Setting.Color friendColor = add(new Setting.Color("Цвет друзей", 0x55D26B));
    public final Setting.Color enemyColor = add(new Setting.Color("Цвет врагов", 0xFF3232));
    public final Setting.Bool protect = add(new Setting.Bool("Не бить друзей", true));
    public final Setting.Bool box = add(new Setting.Bool("Рамка вокруг игрока", true));
    public final Setting.Bool plate = add(new Setting.Bool("Ник над головой", true));
    public final Setting.Bool badge = add(new Setting.Bool("Значок у друзей", true));
    public final Setting.Num radius = add(new Setting.Num("Дальность", 64, 8, 128, 4));

    private String fs = "", es = "";
    private Set<String> fset = new HashSet<>(), eset = new HashSet<>();

    public Relations() {
        super("Друзья и враги", Category.COMBAT);
        description = "Подсветка по никам, защита друзей";
    }

    private static Set<String> parse(String s) {
        Set<String> out = new HashSet<>();
        for (String p : s.split("[,;\\s]+")) {
            p = p.trim().toLowerCase(Locale.ROOT);
            if (!p.isEmpty()) out.add(p);
        }
        return out;
    }

    private void refresh() {
        if (!friends.get().equals(fs)) { fs = friends.get(); fset = parse(fs); }
        if (!enemies.get().equals(es)) { es = enemies.get(); eset = parse(es); }
    }

    public boolean isFriend(String name) { refresh(); return fset.contains(name.toLowerCase(Locale.ROOT)); }

    public boolean isEnemy(String name) { refresh(); return eset.contains(name.toLowerCase(Locale.ROOT)); }

    /** true, если по этой сущности бить нельзя. */
    public boolean isProtected(Entity e) {
        return enabled && protect.get() && e instanceof Player p && isFriend(p.getName().getString());
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Projection.ready) return;
        Font f = mc.font;
        float pt = VClient.partial;
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            String name = p.getName().getString();
            boolean fr = isFriend(name), en = !fr && isEnemy(name);
            if (!fr && !en) continue;
            double dist = mc.player.distanceTo(p);
            if (dist > radius.get()) continue;
            int rgb = fr ? friendColor.get() : enemyColor.get();
            if (box.get()) {
                Vec3 off = p.getPosition(pt).subtract(p.position());
                AABB bb = p.getBoundingBox().move(off);
                Projection.box(g, bb, 1, Draw.alpha(rgb, 0xE0));
            }
            if (plate.get()) {
                Vec3 head = p.getPosition(pt).add(0, p.getBbHeight() + 0.35, 0);
                double[] s = Projection.project(head);
                if (s == null) continue;
                boolean b = fr && badge.get();
                int bw = f.width(name) + 10 + (b ? 12 : 0);
                int x = (int) s[0] - bw / 2, y = (int) s[1] - 14;
                Draw.rrect(g, x, y, bw, 13, 5, Draw.panelBg());
                int tx = x + 5;
                if (b) { Draw.badge(g, x + 3, y + 1, 11); tx = x + 16; }
                g.text(f, name, tx, y + 3, Draw.alpha(rgb, 0xFF));
                String d = Math.round(dist) + "m";
                g.text(f, d, (int) s[0] - f.width(d) / 2, y + 15, 0xFFE0E0E8);
            }
        }
    }
}
