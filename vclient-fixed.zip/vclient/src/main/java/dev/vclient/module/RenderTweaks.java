package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.setting.Setting;

/** Отключение лишних элементов отрисовки. Остальную работу делают миксины и HUD-подмена. */
public class RenderTweaks extends Module {
    public static final String FIRE = "Огонь на экране";
    public static final String HURT = "Тряска при уроне";
    public static final String WEATHER = "Погода";
    public static final String BOSSBAR = "Боссбар";
    public static final String BUBBLES = "Пузырьки воздуха";
    public static final String GLOW = "Свечение игроков";

    public final Setting.Multi disable = add(new Setting.Multi("Отключить", FIRE, HURT, WEATHER, BOSSBAR, BUBBLES, GLOW));

    public RenderTweaks() {
        super("Render Tweaks", Category.VISUALS);
        description = "Отключение лишних элементов отрисовки";
    }

    /** true, если модуль включён и этот пункт выбран. */
    public static boolean has(String option) {
        if (VClient.modules == null) return false;
        RenderTweaks m = VClient.modules.renderTweaks;
        return m.enabled && m.disable.has(option);
    }
}
