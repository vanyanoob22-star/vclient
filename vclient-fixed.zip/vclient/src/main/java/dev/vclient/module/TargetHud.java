package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;

/** Информация о цели, которую ты недавно ударил. */
public class TargetHud extends HudModule {
    public final Setting.Num seconds = add(new Setting.Num("Показывать, сек", 6, 1, 20, 1));

    public TargetHud() { super("TargetHUD", "Имя и здоровье цели", 50, 62); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        String name;
        float hp, max;
        if (sample) {
            name = "Enemy"; hp = 14.5f; max = 20f;
        } else {
            LivingEntity t = VClient.lastTarget;
            if (t == null || !t.isAlive()) return null;
            if (System.currentTimeMillis() - VClient.lastTargetTime > seconds.get() * 1000) return null;
            name = t.getName().getString();
            hp = t.getHealth();
            max = Math.max(1f, t.getMaxHealth());
        }
        Font f = Minecraft.getInstance().font;
        String hpTxt = String.format("%.1f / %.0f", hp, max);
        int w = Math.max(130, f.width(name) + f.width(hpTxt) + 40), h = 40;
        int[] b = Draw.place(posX.get(), posY.get(), w, h, scale.f());
        Draw.begin(g, b[0], b[1], scale.f());
        Draw.rrect(g, 0, 0, w, h, 6, dev.vclient.gui.Draw.panelBg());
        Draw.rrect(g, 8, 8, 6, 6, 3, Draw.ACCENT);
        g.text(f, name, 19, 7, 0xFFFFFFFF);
        g.text(f, hpTxt, w - 8 - f.width(hpTxt), 7, 0xFFC8C8D0);
        int bw = w - 16;
        Draw.rrect(g, 8, 24, bw, 8, 4, 0xFF3A3A46);
        float ratio = Math.max(0f, Math.min(1f, hp / max));
        int fw = Math.max(0, (int) (bw * ratio));
        if (fw > 0) Draw.rrect(g, 8, 24, fw, 8, 4, ratio > 0.5f ? 0xFF55D26B : ratio > 0.25f ? 0xFFE6B94D : 0xFFFF3232);
        Draw.end(g);
        return b;
    }
}
