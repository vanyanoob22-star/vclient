package dev.vclient.module;

import dev.vclient.gui.Theme;
import dev.vclient.setting.Setting;

/** Цвета интерфейса клиента: акцент (меню, HUD, модули с «Цвет клиента»), фон панелей и его прозрачность. */
public class ThemeSettings extends Module {
    public final Setting.Color accent = add(new Setting.Color("Цвет интерфейса", 0xA64DFF));
    public final Setting.Color panel = add(new Setting.Color("Фон панелей", 0x101015));
    public final Setting.Num alpha = add(new Setting.Num("Прозрачность фона", 200, 60, 255, 5));

    public ThemeSettings() {
        super("Тема интерфейса", Category.SETTINGS);
        description = "Цвет меню и HUD";
        enabled = true;
        tickAlways = true;
    }

    @Override public void onTick() { Theme.apply(accent.get(), panel.get(), alpha.i()); }
}
