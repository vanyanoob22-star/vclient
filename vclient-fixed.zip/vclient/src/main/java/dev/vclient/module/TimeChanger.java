package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.setting.Setting;

/** Клиентское время суток: сервер о нём не знает, меняется только то, что видишь ты. */
public class TimeChanger extends Module {
    public final Setting.Mode preset = add(new Setting.Mode("Время", 1, "Рассвет", "День", "Закат", "Ночь", "Своё"));
    public final Setting.Num custom = add(new Setting.Num("Своё время (тики)", 6000, 0, 24000, 250));

    public TimeChanger() {
        super("Time Changer", Category.VISUALS);
        description = "Своё время суток только у тебя на экране";
    }

    public long ticks() {
        return switch (preset.get()) {
            case 0 -> 23000L;
            case 1 -> 6000L;
            case 2 -> 12500L;
            case 3 -> 18000L;
            default -> (long) custom.get().doubleValue();
        };
    }

    public static boolean on() { return VClient.modules != null && VClient.modules.timeChanger.enabled; }
    public static long time() { return VClient.modules.timeChanger.ticks(); }
}
