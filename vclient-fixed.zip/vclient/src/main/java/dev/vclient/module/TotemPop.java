package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;

/** Анимация на весь экран, когда срабатывает тотем бессмертия (свой или чужой рядом). */
public class TotemPop extends Module {
    private long t0 = -1;
    private String who = "";

    public final Setting.Bool selfOnly = add(new Setting.Bool("Только мой тотем", true));
    public final Setting.Num size = add(new Setting.Num("Размер", 96, 32, 256, 8));
    public final Setting.Num duration = add(new Setting.Num("Длительность, сек", 1.6, 0.5, 4.0, 0.1));
    public final Setting.Bool text = add(new Setting.Bool("Надпись", true));
    public final Setting.Bool sound = add(new Setting.Bool("Доп. звук", false));
    public final Setting.Action test = add(new Setting.Action("Проверить", () -> start("Тест")));

    public TotemPop() {
        super("Totem Pop", Category.MEMES);
        description = "Огурец на весь экран при срабатывании тотема";
    }

    public static void popped(Entity e) {
        if (VClient.modules == null) return;
        TotemPop m = VClient.modules.totemPop;
        if (!m.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (m.selfOnly.get() && e != mc.player) return;
        m.start(e == mc.player ? "ТОТЕМ!" : e.getName().getString());
    }

    private void start(String s) {
        who = s;
        t0 = System.currentTimeMillis();
        if (sound.get()) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.PLAYER_LEVELUP, 1.2f, 0.8f));
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        if (t0 < 0) return;
        double age = (System.currentTimeMillis() - t0) / 1000.0 / duration.get();
        if (age >= 1) { t0 = -1; return; }
        Minecraft mc = Minecraft.getInstance();
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        // выскакивает с перелётом, потом сжимается и исчезает
        double grow = age < 0.25 ? Math.sin(age / 0.25 * Math.PI / 2) * 1.2 : 1.2 - 0.2 * Math.min(1, (age - 0.25) / 0.15);
        double fade = age > 0.7 ? 1 - (age - 0.7) / 0.3 : 1;
        int px = (int) Math.round(size.get() * grow * (age > 0.7 ? fade : 1));
        if (px < 4) return;
        double wob = Math.sin(age * 30) * (1 - age) * 3;
        Draw.badge(g, (int) (sw / 2.0 - px / 2.0 + wob), sh / 2 - px / 2 - 10, px);
        if (text.get() && fade > 0.2) {
            int a = (int) (255 * fade);
            int w = mc.font.width(who);
            Draw.begin(g, sw / 2, sh / 2 + px / 2 + 2, 2f);
            g.text(mc.font, who, -w / 2, 0, Draw.alpha(0xFFE066, a));
            Draw.end(g);
        }
    }
}
