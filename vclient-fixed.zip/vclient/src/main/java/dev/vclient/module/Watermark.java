package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Название клиента на экране с переливающимся цветом. */
public class Watermark extends HudModule {
    public final Setting.Str text = add(new Setting.Str("Текст", "Огурец Клиент"));
    public final Setting.Bool chroma = add(new Setting.Bool("Переливающийся цвет", true));
    public final Setting.Bool badge = add(new Setting.Bool("Значок", true));

    public Watermark() { super("Watermark", "Название клиента на экране", 50, 1); }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        Font f = Minecraft.getInstance().font;
        String s = text.get();
        int w = f.width(s) + 14 + (badge.get() ? 14 : 0), h = 17;
        int[] b = Draw.place(posX.get(), posY.get(), w, h, scale.f());
        Draw.begin(g, b[0], b[1], scale.f());
        Draw.rrect(g, 0, 0, w, h, 6, Draw.panelBg());
        int x = 7;
        if (badge.get()) { Draw.badge(g, 5, 3, 11); x = 19; }
        long now = System.currentTimeMillis();
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            int col = chroma.get() ? 0xFF000000 | Cos.hsv((float) ((now / 12.0 + i * 14) % 360), 0.65f, 1f) : Draw.ACCENT;
            g.text(f, ch, x, 5, col);
            x += f.width(ch);
        }
        Draw.end(g);
        return b;
    }
}
