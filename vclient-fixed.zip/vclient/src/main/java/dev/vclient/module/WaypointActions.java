package dev.vclient.module;

import dev.vclient.VClient;

/** Кнопки для меток: поставить там, куда смотришь, и очистить все. */
public class WaypointActions extends Module {
    private final boolean clear;

    public WaypointActions(String name, String desc, boolean clear) {
        super(name, Category.MARKERS);
        this.clear = clear;
        this.oneShot = true;
        this.description = desc;
    }

    @Override public void onEnable() {
        Waypoints w = VClient.modules.waypoints;
        if (clear) w.list.clear(); else w.addHere();
    }
}
