package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Метки в мире с названием и расстоянием. Хранятся до закрытия игры. */
public class Waypoints extends Module {
    public static class Wp { public String name; public Vec3 pos; }

    public final Setting.Num limit = add(new Setting.Num("Лимит меток", 10, 1, 30, 1));
    public final Setting.Num range = add(new Setting.Num("Дальность показа, блоки", 500, 50, 3000, 50));
    public final Setting.Bool showDist = add(new Setting.Bool("Показывать расстояние", true));
    public final Setting.Str newName = add(new Setting.Str("Название новой метки", "Метка"));
    public final Setting.Color color = add(new Setting.Color("Цвет", 0xFF9A3C));
    public final List<Wp> list = new ArrayList<>();

    public Waypoints() {
        super("Метки", Category.MARKERS);
        description = "Метки в мире с расстоянием";
        enabled = true;
    }

    public void addHere() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Vec3 pos = mc.player.position();
        if (mc.hitResult instanceof BlockHitResult bhr && bhr.getType() != HitResult.Type.MISS) pos = bhr.getLocation();
        Wp w = new Wp();
        w.name = newName.get().isEmpty() ? "Метка" : newName.get();
        w.pos = pos;
        list.add(w);
        while (list.size() > limit.i()) list.remove(0);
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !Projection.ready) return;
        Font f = mc.font;
        for (Wp w : list) {
            double dist = mc.player.position().distanceTo(w.pos);
            if (dist > range.get()) continue;
            double[] s = Projection.project(w.pos.x, w.pos.y + 0.5, w.pos.z);
            if (s == null) continue;
            int x = (int) s[0], y = (int) s[1];
            String d = Math.round(dist) + "m";
            int tw = f.width(w.name) + 12;
            Draw.rrect(g, x - tw / 2, y - 16, tw, 14, 5, dev.vclient.gui.Draw.panelBg());
            g.text(f, w.name, x - tw / 2 + 6, y - 13, 0xFFFFFFFF);
            Draw.rrect(g, x - 3, y + 1, 6, 6, 3, Draw.alpha(color.get(), 0xFF));
            if (showDist.get()) g.text(f, d, x - f.width(d) / 2, y + 10, 0xFFE0E0E8);
        }
    }
}
