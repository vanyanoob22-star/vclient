package dev.vclient.module;

import dev.vclient.gui.Draw;
import dev.vclient.gui.WebScreen;
import dev.vclient.setting.Setting;
import dev.vclient.web.RinkuBridge;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Браузер и музыка из интернета: окно на Shift+Tab, PiP поверх игры, вкладки живут в фоне. */
public class WebHub extends HudModule {
    public static final class Tab {
        public Object browser;
        public String url = "";
        public int bw = 960, bh = 540;
        public long polled;
    }

    public static final List<Tab> tabs = new ArrayList<>();
    public static int cur = -1;
    public static boolean pip;

    public final Setting.Num pipWidth = add(new Setting.Num("Ширина PiP", 320, 160, 800, 10));
    public final Setting.Str home = add(new Setting.Str("Домашняя страница", "https://music.youtube.com"));
    public final Setting.Action openAction = add(new Setting.Action("Открыть браузер", WebHub::openScreen));
    public final Setting.Action closeAll = add(new Setting.Action("Закрыть все вкладки", WebHub::closeAllTabs));

    private boolean comboWas, pipWas, playWas;
    private int ticks;

    public WebHub() {
        super("Browser PiP", "Браузер и музыка с сайтов: Shift+Tab, Shift+P (PiP), Shift+M (пауза)", 70, 5);
        tickAlways = true;
        enabled = true;
    }

    public static Tab current() { return cur >= 0 && cur < tabs.size() ? tabs.get(cur) : null; }

    public static Tab openTab(String url) {
        Object b = RinkuBridge.create(url, 960, 540);
        if (b == null) return null;
        Tab t = new Tab();
        t.browser = b;
        t.url = url;
        tabs.add(t);
        cur = tabs.size() - 1;
        return t;
    }

    public static void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        RinkuBridge.close(tabs.get(i).browser);
        tabs.remove(i);
        if (cur >= tabs.size()) cur = tabs.size() - 1;
    }

    public static void closeAllTabs() {
        for (Tab t : tabs) RinkuBridge.close(t.browser);
        tabs.clear();
        cur = -1;
        pip = false;
    }

    public static void openScreen() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui.screen() == null) mc.gui.setScreen(new WebScreen());
    }

    public static void toggleMedia() {
        Tab t = current();
        if (t != null) RinkuBridge.js(t.browser,
            "(function(){var m=document.querySelector('video,audio');if(m){if(m.paused)m.play();else m.pause();}})();");
    }

    public static void changeVolume(double d) {
        Tab t = current();
        if (t != null) RinkuBridge.js(t.browser,
            "(function(){document.querySelectorAll('video,audio').forEach(function(m){m.volume=Math.max(0,Math.min(1,m.volume+(" + d + ")));});})();");
    }

    private static boolean down(long w, int key) { return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        long w = mc.getWindow().handle();
        boolean shift = down(w, GLFW.GLFW_KEY_LEFT_SHIFT);
        boolean combo = shift && down(w, GLFW.GLFW_KEY_TAB);
        Object s = mc.gui.screen();
        if (combo && !comboWas) {
            if (s instanceof WebScreen) mc.gui.setScreen(null);
            else if (s == null) mc.gui.setScreen(new WebScreen());
        }
        comboWas = combo;
        boolean p = shift && down(w, GLFW.GLFW_KEY_P), m = shift && down(w, GLFW.GLFW_KEY_M);
        if (s == null) {
            if (p && !pipWas && current() != null) pip = !pip;
            if (m && !playWas) toggleMedia();
        }
        pipWas = p;
        playWas = m;
        if (++ticks % 20 == 0) {
            Tab t = current();
            if (t != null) { String u = RinkuBridge.url(t.browser); if (!u.isEmpty()) t.url = u; }
        }
    }

    @Override public int[] draw(GuiGraphicsExtractor g, boolean sample) {
        Minecraft mc = Minecraft.getInstance();
        Tab t = current();
        if (!sample && (!pip || t == null)) return null;
        int w = pipWidth.i();
        int h = sample || t == null ? w * 9 / 16 : Math.max(40, w * t.bh / Math.max(1, t.bw));
        int[] r = Draw.place(posX.get(), posY.get(), w, h, scale.f());
        Draw.begin(g, r[0], r[1], scale.f());
        Draw.rrect(g, -2, -2, w + 4, h + 4, 5, Draw.panelBg());
        Identifier tex = sample || t == null ? null : RinkuBridge.texture(t.browser);
        if (tex != null && RinkuBridge.ready(t.browser)) {
            g.blit(RenderPipelines.GUI_TEXTURED, tex, 0, 0, 0f, 0f, w, h, t.bw, t.bh, t.bw, t.bh);
        } else {
            String msg = sample ? "PiP: браузер" : "Загрузка...";
            g.text(mc.font, msg, (w - mc.font.width(msg)) / 2, h / 2 - 4, 0xFF9A9AAA);
        }
        Draw.end(g);
        return r;
    }
}
