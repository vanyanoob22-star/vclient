package dev.vclient.module;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.gui.Projection;
import dev.vclient.setting.Setting;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Частицы вокруг игрока: звёзды, искры, огонь, снег, сердца и другие. */
public class WorldParticles extends Module {
    static final String[] NAMES = {"Звёзды", "Искры", "Огонь", "Дым", "Снег", "Сердца", "Перья", "Магия", "Руны",
            "Кристаллы", "Пыль", "Пиксели", "Свечение", "Пустота"};
    static final int[] COL = {0xFFE680, 0xFFC14D, 0xFF7A1A, 0x9A9AA8, 0xFFFFFF, 0xFF5C8A, 0xE8E8F0, 0xC45CFF, 0x5CFFE1,
            0x7DE3FF, 0xD8C8A8, 0xA64DFF, 0xFFF3B0, 0x6A00B8};
    private static final String[] HEART = {"01010", "11111", "11111", "01110", "00100"};

    private static class P { double x, y, z, vx, vy, vz; int life, max; }

    public final Setting.Mode type = add(new Setting.Mode("Тип", 0, NAMES));
    public final Setting.Num count = add(new Setting.Num("Количество", 40, 10, 150, 5));
    public final Setting.Num radius = add(new Setting.Num("Радиус", 5, 2, 10, 0.5));
    public final Setting.Num size = add(new Setting.Num("Размер", 0.06, 0.02, 0.2, 0.01));
    public final Setting.Num speed = add(new Setting.Num("Скорость", 1.0, 0.2, 3.0, 0.1));
    public final Setting.Bool custom = add(new Setting.Bool("Свой цвет", false));
    public final Setting.Color color = add(new Setting.Color("Цвет", 0xA64DFF));

    private final List<P> list = new ArrayList<>();

    public WorldParticles() {
        super("World Particles", Category.COSMETICS);
        description = "Частицы вокруг игрока";
    }

    @Override public void onDisable() { list.clear(); }

    private P make(Minecraft mc) {
        P p = new P();
        double a = Math.random() * Math.PI * 2, r = Math.random() * radius.get();
        p.x = mc.player.getX() + Math.cos(a) * r;
        p.z = mc.player.getZ() + Math.sin(a) * r;
        p.y = mc.player.getY() + Math.random() * 2.4;
        int t = type.get();
        double rnd = (Math.random() - 0.5) * 0.016;
        switch (t) {
            case 2 -> { p.vy = 0.03 + Math.random() * 0.03; p.vx = rnd; }
            case 3 -> { p.vy = 0.015; p.vx = rnd; p.vz = rnd; }
            case 4 -> { p.vy = -0.02; p.vx = rnd; }
            case 5 -> p.vy = 0.02;
            case 6 -> { p.vy = -0.012; p.vx = rnd * 2; }
            default -> { p.vx = rnd; p.vy = (Math.random() - 0.5) * 0.016; p.vz = (Math.random() - 0.5) * 0.016; }
        }
        p.life = p.max = 40 + (int) (Math.random() * 50);
        return p;
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { list.clear(); return; }
        int spawned = 0;
        int target = Math.max(4, Math.round(count.i() * dev.vclient.gui.Quality.particles));
        while (list.size() < target && spawned++ < 4) list.add(make(mc));
        while (list.size() > target) list.remove(list.size() - 1);
        double sp = speed.get();
        for (Iterator<P> it = list.iterator(); it.hasNext(); ) {
            P p = it.next();
            p.x += p.vx * sp; p.y += p.vy * sp; p.z += p.vz * sp;
            if (--p.life <= 0) it.remove();
        }
    }

    @Override public void onHud(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !Projection.ready) return;
        int t = type.get();
        int rgb = custom.get() ? color.get() : COL[t];
        float pt = VClient.partial;
        double sp = speed.get();
        for (P p : list) {
            double[] s = Projection.project(p.x + p.vx * sp * pt, p.y + p.vy * sp * pt, p.z + p.vz * sp * pt);
            if (s == null) continue;
            double prog = 1 - p.life / (double) p.max;
            int al = (int) (230 * Math.sin(Math.PI * prog));
            if (al < 10) continue;
            int px = Math.max(2, (int) Math.round(size.get() * Projection.pxPerBlock(s[2]) * 2));
            if (t == 3) px = (int) (px * (1 + prog));
            shape(g, t, (int) s[0], (int) s[1], px, rgb, al);
        }
    }

    private static void shape(GuiGraphicsExtractor g, int t, int cx, int cy, int px, int rgb, int al) {
        int h = Math.max(1, px / 2), th = Math.max(1, px / 4);
        switch (t) {
            case 0, 7 -> { // звезда
                g.fill(cx - h, cy - th / 2, cx + h + 1, cy + th / 2 + 1, Draw.alpha(rgb, al));
                g.fill(cx - th / 2, cy - h, cx + th / 2 + 1, cy + h + 1, Draw.alpha(rgb, al));
            }
            case 4 -> { // снежинка
                g.fill(cx - h, cy, cx + h + 1, cy + 1, Draw.alpha(rgb, al));
                g.fill(cx, cy - h, cx + 1, cy + h + 1, Draw.alpha(rgb, al));
            }
            case 5 -> { // сердце
                int cell = Math.max(1, px / 5);
                for (int r = 0; r < 5; r++)
                    for (int c = 0; c < 5; c++)
                        if (HEART[r].charAt(c) == '1')
                            g.fill(cx + (c - 2) * cell, cy + (r - 2) * cell, cx + (c - 1) * cell, cy + (r - 1) * cell, Draw.alpha(rgb, al));
            }
            case 6 -> Draw.arrow(g, cx, cy, h + 1, (cx * 7 + cy * 3) % 360, Draw.alpha(rgb, al)); // перо
            case 8 -> { // руна
                int c = Draw.alpha(rgb, al);
                g.fill(cx - h, cy - h, cx + h + 1, cy - h + 1, c);
                g.fill(cx - h, cy + h, cx + h + 1, cy + h + 1, c);
                g.fill(cx - h, cy - h, cx - h + 1, cy + h + 1, c);
                g.fill(cx + h, cy - h, cx + h + 1, cy + h + 1, c);
                g.fill(cx - 1, cy - 1, cx + 1, cy + 1, c);
            }
            case 9 -> { // кристалл
                Draw.arrow(g, cx, cy - h / 2, h, 0, Draw.alpha(rgb, al));
                Draw.arrow(g, cx, cy + h / 2, h, 180, Draw.alpha(rgb, al));
            }
            case 12, 13 -> { // свечение
                Draw.rrect(g, cx - px, cy - px, px * 2, px * 2, px, Draw.alpha(rgb, al / 4));
                Draw.rrect(g, cx - h, cy - h, h * 2, h * 2, h, Draw.alpha(rgb, al));
            }
            default -> g.fill(cx - h, cy - h, cx + h, cy + h, Draw.alpha(rgb, al)); // искра, огонь, дым, пыль, пиксели
        }
    }
}
