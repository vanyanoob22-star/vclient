package dev.vclient.module;

import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;

/** Зум через изменение FOV. Работает пока зажата клавиша (по умолчанию C). */
public class Zoom extends Module {
    public final Setting.Num fov = add(new Setting.Num("FOV", 30, 10, 70, 1));
    private int saved = -1;

    public Zoom() {
        super("Zoom", Category.VISUALS);
        key = 67; // C
        hold = true;
        description = "Приближение, пока зажата клавиша";
    }

    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        saved = mc.options.fov().get();
        mc.options.fov().set(Math.max(30, (int) Math.round(fov.get())));
    }

    /** Колёсико мыши меняет зум, пока он включён. */
    public void scroll(double dy) { fov.set(Math.max(10.0, Math.min(70.0, fov.get() - dy * 3))); }

    @Override public void onTick() {
        if (saved != -1) Minecraft.getInstance().options.fov().set(Math.max(30, (int) Math.round(fov.get())));
    }

    @Override public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (saved != -1) mc.options.fov().set(saved);
        saved = -1;
    }
}
