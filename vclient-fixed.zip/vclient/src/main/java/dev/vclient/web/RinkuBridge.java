package dev.vclient.web;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.resources.Identifier;

/** Тонкая обёртка над Rinku (Chromium) через рефлексию: клиент собирается и работает даже без библиотеки. */
public final class RinkuBridge {
    private static final Class<?>[] NONE = new Class<?>[0];
    private static final Map<String, Method> CACHE = new HashMap<>();
    private static Class<?> rinku;
    private static boolean tried, ok;

    private RinkuBridge() { }

    public static boolean available() {
        if (!tried) {
            tried = true;
            try { rinku = Class.forName("de.keksuccino.rinku.Rinku"); ok = true; }
            catch (Throwable t) { ok = false; }
        }
        return ok;
    }

    private static Object callStatic(String name, Class<?>[] types, Object... args) {
        try {
            String key = "S#" + name + Arrays.toString(types);
            Method m = CACHE.get(key);
            if (m == null) { m = rinku.getMethod(name, types); CACHE.put(key, m); }
            return m.invoke(null, args);
        } catch (Throwable t) { return null; }
    }

    private static Object call(Object b, String name, Class<?>[] types, Object... args) {
        if (b == null) return null;
        try {
            String key = b.getClass().getName() + "#" + name + Arrays.toString(types);
            Method m = CACHE.get(key);
            if (m == null) { m = b.getClass().getMethod(name, types); CACHE.put(key, m); }
            return m.invoke(b, args);
        } catch (Throwable t) { return null; }
    }

    public static boolean initialized() { return available() && Boolean.TRUE.equals(callStatic("isInitialized", NONE)); }
    public static boolean initAllowed() { return available() && !Boolean.FALSE.equals(callStatic("isInitializationAllowed", NONE)); }
    public static void init() { if (available()) callStatic("initialize", NONE); }

    public static Object create(String url, int w, int h) {
        if (!initialized()) return null;
        return callStatic("createBrowser", new Class<?>[]{String.class, boolean.class, int.class, int.class}, url, false, w, h);
    }

    public static void load(Object b, String url) { call(b, "loadURL", new Class<?>[]{String.class}, url); }
    public static void back(Object b) { call(b, "goBack", NONE); }
    public static void forward(Object b) { call(b, "goForward", NONE); }
    public static void reload(Object b) { call(b, "reload", NONE); }
    public static void close(Object b) { call(b, "close", NONE); }
    public static void focus(Object b, boolean f) { call(b, "setFocus", new Class<?>[]{boolean.class}, f); }
    public static void resize(Object b, int w, int h) { call(b, "resize", new Class<?>[]{int.class, int.class}, w, h); }
    public static String url(Object b) { Object o = call(b, "getURL", NONE); return o instanceof String s ? s : ""; }
    public static boolean ready(Object b) { return Boolean.TRUE.equals(call(b, "isTextureReady", NONE)); }
    public static Identifier texture(Object b) { Object o = call(b, "getTextureIdentifier", NONE); return o instanceof Identifier i ? i : null; }

    public static void js(Object b, String code) {
        call(b, "executeJavaScript", new Class<?>[]{String.class, String.class, int.class}, code, "", 0);
    }

    public static void mouseMove(Object b, int x, int y) { call(b, "sendMouseMove", new Class<?>[]{int.class, int.class}, x, y); }
    public static void mousePress(Object b, int x, int y, int btn) { call(b, "sendMousePress", new Class<?>[]{int.class, int.class, int.class}, x, y, btn); }
    public static void mouseRelease(Object b, int x, int y, int btn) { call(b, "sendMouseRelease", new Class<?>[]{int.class, int.class, int.class}, x, y, btn); }
    public static void wheel(Object b, int x, int y, double d) { call(b, "sendMouseWheel", new Class<?>[]{int.class, int.class, double.class, int.class}, x, y, d, 0); }
    public static void keyPress(Object b, int key, int mods) { call(b, "sendKeyPress", new Class<?>[]{int.class, long.class, int.class}, key, 0L, mods); }
    public static void keyRelease(Object b, int key, int mods) { call(b, "sendKeyRelease", new Class<?>[]{int.class, long.class, int.class}, key, 0L, mods); }
    public static void typed(Object b, char c) { call(b, "sendKeyTyped", new Class<?>[]{char.class, int.class}, c, 0); }
}
