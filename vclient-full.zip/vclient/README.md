# Огурец Клиент FULL (Minecraft 26.2, Fabric)

Меню: Right Shift (стиль Really Visuals), Ctrl + Right Shift — классическое меню.
Добавлено: Inventory, Death Point, Keystrokes (HUD), Auto Sprint (Утилиты), Оптимизация (Тема).
Сборка: GitHub Actions -> артефакт vclient-full.
