@echo off
setlocal
cd /d "%~dp0"
echo ===== VClient build =====

where javac >nul 2>nul
if errorlevel 1 (
  echo [ERROR] javac not found. Install JDK 25 - Temurin from adoptium.net - and enable Add to PATH.
  pause
  exit /b 1
)

if not exist gradlew.bat (
  echo [ERROR] gradlew.bat not found in this folder.
  echo Copy the folder gradle and the files gradlew and gradlew.bat from the Fabric template here.
  pause
  exit /b 1
)

call gradlew.bat build
if errorlevel 1 (
  echo.
  echo [ERROR] Build failed. Copy ALL the text above and send it to Claude.
  pause
  exit /b 1
)

if not exist out mkdir out
del /q out\*.jar 2>nul
copy /y build\libs\vclient-0.1.0.jar out\ >nul

echo.
echo DONE. The jar is in the folder out. Put it into the mods folder.
pause
