package dev.vclient.gui;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

public final class Draw {
    public static int ACCENT = 0xFFA64DFF, ACCENT_DIM = 0xFF6F2FB5;

    public static int panelBg() { return Theme.panelArgb(); }

    private Draw() {}

    public static int alpha(int rgb, int a) { return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF); }

    private static final int[][] INSETS = new int[17][];

    private static int[] insets(int r) {
        int[] a = INSETS[r];
        if (a == null) {
            a = new int[r];
            for (int i = 0; i < r; i++) {
                double dy = r - i - 0.5;
                a[i] = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            }
            INSETS[r] = a;
        }
        return a;
    }

    public static void rrect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(16, Math.min(r, Math.min(w, h) / 2)));
        if (r == 0) { g.fill(x, y, x + w, y + h, c); return; }
        int[] ins = insets(r);
        for (int i = 0; i < r; i++) {
            g.fill(x + ins[i], y + i, x + w - ins[i], y + i + 1, c);
            g.fill(x + ins[i], y + h - i - 1, x + w - ins[i], y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    public static void rrectLeft(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(16, r));
        int[] ins = insets(Math.max(1, r));
        for (int i = 0; i < r; i++) {
            g.fill(x + ins[i], y + i, x + w, y + i + 1, c);
            g.fill(x + ins[i], y + h - i - 1, x + w, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    private static final Identifier BADGE = Identifier.fromNamespaceAndPath("vclient", "textures/gui/badge.png");

    /** Маленький значок «Огурец Клиент». */
    public static void badge(GuiGraphicsExtractor g, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, BADGE, x, y, 0f, 0f, size, size, 24, 24, 24, 24);
    }

    private static boolean inTri(double px, double py, double ax, double ay, double bx, double by, double cx, double cy) {
        double d1 = (px - bx) * (ay - by) - (ax - bx) * (py - by);
        double d2 = (px - cx) * (by - cy) - (bx - cx) * (py - cy);
        double d3 = (px - ax) * (cy - ay) - (cx - ax) * (py - ay);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }

    /** Стрелка-«навигатор» со сглаженными краями. Остриё вверх при угле 0, угол в градусах по часовой стрелке. */
    public static void arrow(GuiGraphicsExtractor g, int cx, int cy, int r, double deg, int argb) {
        double a = Math.toRadians(deg), sin = Math.sin(a), cos = Math.cos(a);
        double[][] v = {{0, -1.0}, {0.82, 0.95}, {0, 0.42}, {-0.82, 0.95}};
        double[][] q = new double[4][2];
        double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
        for (int i = 0; i < 4; i++) {
            q[i][0] = cx + (v[i][0] * cos - v[i][1] * sin) * r;
            q[i][1] = cy + (v[i][0] * sin + v[i][1] * cos) * r;
            minX = Math.min(minX, q[i][0]); maxX = Math.max(maxX, q[i][0]);
            minY = Math.min(minY, q[i][1]); maxY = Math.max(maxY, q[i][1]);
        }
        int base = argb >>> 24;
        if (base == 0) base = 255;
        int rgb = argb & 0xFFFFFF;
        for (int y = (int) Math.floor(minY); y <= (int) Math.ceil(maxY); y++) {
            for (int x = (int) Math.floor(minX); x <= (int) Math.ceil(maxX); x++) {
                int hit = 0;
                for (int sy = 0; sy < 4; sy++) {
                    for (int sx = 0; sx < 4; sx++) {
                        double px = x + (sx + 0.5) / 4, py = y + (sy + 0.5) / 4;
                        if (inTri(px, py, q[0][0], q[0][1], q[1][0], q[1][1], q[2][0], q[2][1])
                                || inTri(px, py, q[0][0], q[0][1], q[2][0], q[2][1], q[3][0], q[3][1])) hit++;
                    }
                }
                int al = base * hit / 16;
                if (al > 0) g.fill(x, y, x + 1, y + 1, (al << 24) | rgb);
            }
        }
    }

    /** Позиция блока: проценты экрана с учётом размера и масштаба. Возвращает {x, y, ширина, высота} на экране. */
    public static int[] place(double xp, double yp, int w, int h, float scale) {
        Minecraft mc = Minecraft.getInstance();
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        int pw = Math.round(w * scale), ph = Math.round(h * scale);
        int x = (int) (Math.max(0, sw - pw) * xp / 100.0), y = (int) (Math.max(0, sh - ph) * yp / 100.0);
        return new int[]{x, y, pw, ph};
    }

    public static void begin(GuiGraphicsExtractor g, int x, int y, float scale) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(scale, scale);
    }

    public static void end(GuiGraphicsExtractor g) { g.pose().popMatrix(); }

    /** Закрашенный треугольник-стрелка. Остриё вверх при угле 0, угол в градусах по часовой стрелке. */
    public static void triangle(GuiGraphicsExtractor g, int cx, int cy, int r, double deg, int argb) {
        double a = Math.toRadians(deg), sin = Math.sin(a), cos = Math.cos(a);
        double[][] v = {{0, -r}, {-r * 0.75, r * 0.75}, {r * 0.75, r * 0.75}};
        double[][] q = new double[3][2];
        for (int i = 0; i < 3; i++) {
            q[i][0] = cx + v[i][0] * cos - v[i][1] * sin;
            q[i][1] = cy + v[i][0] * sin + v[i][1] * cos;
        }
        int minX = (int) Math.floor(Math.min(q[0][0], Math.min(q[1][0], q[2][0])));
        int maxX = (int) Math.ceil(Math.max(q[0][0], Math.max(q[1][0], q[2][0])));
        int minY = (int) Math.floor(Math.min(q[0][1], Math.min(q[1][1], q[2][1])));
        int maxY = (int) Math.ceil(Math.max(q[0][1], Math.max(q[1][1], q[2][1])));
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                double px = x + 0.5, py = y + 0.5;
                double d1 = (px - q[1][0]) * (q[0][1] - q[1][1]) - (q[0][0] - q[1][0]) * (py - q[1][1]);
                double d2 = (px - q[2][0]) * (q[1][1] - q[2][1]) - (q[1][0] - q[2][0]) * (py - q[2][1]);
                double d3 = (px - q[0][0]) * (q[2][1] - q[0][1]) - (q[2][0] - q[0][0]) * (py - q[0][1]);
                boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
                if (!(neg && pos)) g.fill(x, y, x + 1, y + 1, argb);
            }
        }
    }

    /**
     * HUD-блок: заголовок и строки {слева, справа, угол стрелки}. Третий элемент необязателен:
     * если он задан, справа рисуется стрелка под этим углом (в градусах). Возвращает рамку на экране.
     */
    public static int[] panel(GuiGraphicsExtractor g, String title, List<String[]> rows, double xp, double yp, float scale) {
        Font f = Minecraft.getInstance().font;
        int w = Math.max(120, f.width(title) + 34);
        for (String[] r : rows) {
            int extra = (r.length > 2 && !r[2].isEmpty()) ? 16 : 0;
            w = Math.max(w, f.width(r[0]) + f.width(r[1]) + 34 + extra);
        }
        int h = 24 + rows.size() * 13 + 4;
        int[] b = place(xp, yp, w, h, scale);
        begin(g, b[0], b[1], scale);
        rrect(g, 0, 0, w, h, 6, panelBg());
        rrect(g, 8, 8, 6, 6, 3, ACCENT);
        g.text(f, title, 19, 7, 0xFFFFFFFF);
        int ry = 22;
        for (String[] r : rows) {
            boolean arrow = r.length > 2 && !r[2].isEmpty();
            int extra = arrow ? 16 : 0;
            g.text(f, r[0], 8, ry, 0xFFC8C8D0);
            g.text(f, r[1], w - 8 - extra - f.width(r[1]), ry, 0xFFFFFFFF);
            if (arrow) {
                double deg;
                try { deg = Double.parseDouble(r[2]); } catch (NumberFormatException e) { deg = 0; }
                arrow(g, w - 14, ry + 4, 5, deg, ACCENT);
            }
            ry += 13;
        }
        end(g);
        return b;
    }
}
