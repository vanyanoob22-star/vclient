package dev.vclient.mixin;

import dev.vclient.module.AspectRatio;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Aspect Ratio: масштабируем X в матрице проекции мира. */
@Mixin(GameRenderer.class)
public abstract class AspectMixin {
    @Inject(method = {"getProjectionMatrix"}, at = @At("RETURN"), cancellable = true)
    private void vclient$aspect(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (!AspectRatio.on()) return;
        var w = Minecraft.getInstance().getWindow();
        float cur = (float) w.getWidth() / Math.max(1, w.getHeight());
        Matrix4f m = new Matrix4f(cir.getReturnValue());
        m.scale(cur / AspectRatio.value(), 1f, 1f);
        cir.setReturnValue(m);
    }
}
