package dev.vclient.rv;

import dev.vclient.module.Module;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

import java.lang.reflect.Method;

/**
 * Оптимизация: идея DynamicQualityManager из Motka (профили + подстройка под FPS)
 * и MemoryOptimizer из Really Visuals (редкая принудительная очистка памяти).
 * Ничего не патчит в рендере, меняет только штатные настройки и поэтому безопасна для 26.2.
 */
public class Optimizer extends Module {
	private static final int[][] PROFILE = { // целевой FPS, мин. дальность, макс. дальность
		{ 60, 2, 6 }, { 60, 4, 8 }, { 90, 6, 12 }, { 120, 8, 16 }, { 144, 10, 24 }
	};

	private final Setting.Mode profile = (Setting.Mode) add(new Setting.Mode("Профиль", 2,
		"Картошка", "Низкий", "Средний", "Высокий", "Ультра"));
	private final Setting.Bool dynamic = (Setting.Bool) add(new Setting.Bool("Динамическая дальность", true));
	private final Setting.Bool memory = (Setting.Bool) add(new Setting.Bool("Очистка памяти", true));
	private final Setting.Num memPct = (Setting.Num) add(new Setting.Num("Порог памяти, %", 85, 50, 95, 5));

	private Integer original;
	private int cooldown;
	private int memTicks;

	public Optimizer() {
		super("Оптимизация", Category.UTILITIES);
		description = "Подстраивает дальность прорисовки под FPS и чистит память";
		tickAlways = false;
	}

	@Override
	public void onEnable() {
		OptionInstance<Integer> rd = renderDistance();
		if (rd != null) original = rd.get();
	}

	@Override
	public void onDisable() {
		OptionInstance<Integer> rd = renderDistance();
		if (rd != null && original != null) rd.set(original);
		original = null;
	}

	@Override
	public void onTick() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return;

		if (memory.get() instanceof Boolean b && b && ++memTicks >= 600) {
			memTicks = 0;
			Runtime r = Runtime.getRuntime();
			double used = (r.totalMemory() - r.freeMemory()) * 100.0 / r.maxMemory();
			if (used >= memPct.f()) System.gc();
		}

		if (!(dynamic.get() instanceof Boolean d) || !d) return;
		if (cooldown-- > 0) return;

		OptionInstance<Integer> rd = renderDistance();
		if (rd == null) return;
		int[] p = PROFILE[Math.max(0, Math.min(PROFILE.length - 1, profile.options.indexOf(profile.current())))];
		int fps = mc.getFps();
		int cur = rd.get();
		if (fps < p[0] * 0.8 && cur > p[1]) {
			rd.set(cur - 1);
			cooldown = 100;
		} else if (fps > p[0] * 1.35 && cur < p[2]) {
			rd.set(cur + 1);
			cooldown = 100;
		}
	}

	/** Через рефлексию, чтобы одна неверная сигнатура в 26.2 не ломала весь мод. */
	@SuppressWarnings("unchecked")
	private static OptionInstance<Integer> renderDistance() {
		try {
			Object opts = Minecraft.getInstance().options;
			Method m = opts.getClass().getMethod("renderDistance");
			return (OptionInstance<Integer>) m.invoke(opts);
		} catch (Throwable t) {
			return null;
		}
	}
}
