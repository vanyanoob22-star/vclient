package dev.vclient.rv;

import dev.vclient.VClient;
import dev.vclient.gui.MenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

import java.util.List;

/** Точка входа: подменяет меню Огурца на RV-меню и добавляет модуль оптимизации. */
public class RvClient implements ClientModInitializer {
	private boolean registered;

	@Override
	@SuppressWarnings("unchecked")
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			if (!registered && VClient.modules != null) {
				((List<Object>) (List<?>) VClient.modules.modules).add(new Optimizer());
				registered = true;
			}
			// Огурец открывает свой MenuScreen по клавише меню, на следующем тике меняем его на RV-меню
			if (mc.gui.screen() instanceof MenuScreen) {
				mc.gui.setScreen(new RvScreen());
			}
		});
	}
}
