package dev.vclient.rv;

import dev.vclient.VClient;
import dev.vclient.gui.Draw;
import dev.vclient.module.Module;
import dev.vclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;

/**
 * Меню в стиле Really Visuals: боковая панель категорий, поиск, карточки модулей с раскрытием
 * настроек. ЛКМ по модулю включает/выключает, ПКМ раскрывает настройки.
 * Рисует только через fill/text, поэтому не зависит от шейдеров 1.16.5.
 */
public class RvScreen extends Screen {
	private static final int BG = 0xE60E0F14, SIDE = 0xF0121319, CARD = 0xFF1A1C24, FIELD = 0xFF23252F,
		TXT = 0xFFE8E8EE, SUB = 0xFF8A8D9A, OFF = 0xFF3A3D4A;
	private static final int SIDE_W = 104, HEAD = 22, ROW = 16;

	private Module.Category cat = Module.Category.VISUALS;
	private final List<Module> expanded = new ArrayList<>();
	private final List<int[]> zones = new ArrayList<>();      // x, y, w, h
	private final List<DoubleConsumer[]> acts = new ArrayList<>(); // [left, right] по зонам
	private DoubleConsumer dragging;
	private int dragX, dragW;
	private String search = "";
	private boolean focusSearch;
	private float scroll;
	private int contentH;
	private int px, py, pw, ph;

	public RvScreen() {
		super(Component.literal("Огурец RV"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private static String ru(Module.Category c) {
		return switch (c.name()) {
			case "VISUALS" -> "Визуалы";
			case "HUD" -> "HUD";
			case "COMBAT" -> "Бой";
			case "UTILITIES" -> "Утилиты";
			case "SERVER" -> "Сервер";
			case "MARKERS" -> "Метки";
			case "SETTINGS" -> "Настройки";
			default -> "Мемы";
		};
	}

	private static void rr(GuiGraphicsExtractor g, int x, int y, int w, int h, int c) {
		g.fill(x + 1, y, x + w - 1, y + h, c);
		g.fill(x, y + 1, x + w, y + h - 1, c);
	}

	private void txt(GuiGraphicsExtractor g, String s, int x, int y, int c) {
		g.text(Minecraft.getInstance().font, s, x, y, c);
	}

	private List<Module> visible() {
		List<Module> out = new ArrayList<>();
		String q = search.toLowerCase();
		for (Object o : (List<?>) VClient.modules.modules) {
			Module m = (Module) o;
			boolean ok = q.isEmpty() ? m.category == cat : m.name.toLowerCase().contains(q);
			if (ok) out.add(m);
		}
		return out;
	}

	private int cardH(Module m) {
		if (!expanded.contains(m)) return HEAD;
		int h = HEAD + 4;
		for (Object s : m.settings) h += rowH((Setting) s);
		return h + 2;
	}

	private int rowH(Setting s) {
		if (s instanceof Setting.Multi m) return ROW * (1 + m.options.size());
		if (s instanceof Setting.Mode) return ROW;
		if (s instanceof Setting.Color) return ROW + 8;
		if (s instanceof Setting.Num) return ROW + 4;
		return ROW;
	}

	private void zone(int x, int y, int w, int h, DoubleConsumer left, DoubleConsumer right) {
		zones.add(new int[] { x, y, w, h });
		acts.add(new DoubleConsumer[] { left, right });
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float dt) {
		Minecraft mc = Minecraft.getInstance();
		int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
		pw = Math.min(sw - 16, 520);
		ph = Math.min(sh - 16, 320);
		px = (sw - pw) / 2;
		py = (sh - ph) / 2;
		zones.clear();
		acts.clear();

		g.fill(0, 0, sw, sh, 0x80000000);
		rr(g, px, py, pw, ph, BG);
		rr(g, px, py, SIDE_W, ph, SIDE);
		txt(g, "Огурец", px + 10, py + 9, Draw.ACCENT | 0xFF000000);
		txt(g, "RV", px + 10 + mc.font.width("Огурец ") , py + 9, SUB);

		// категории
		int y = py + 30;
		for (Module.Category c : Module.Category.values()) {
			final Module.Category cc = c;
			boolean sel = c == cat && search.isEmpty();
			if (sel) {
				rr(g, px + 6, y, SIDE_W - 12, 18, FIELD);
				g.fill(px + 6, y + 3, px + 8, y + 15, Draw.ACCENT | 0xFF000000);
			}
			txt(g, ru(c), px + 14, y + 5, sel ? TXT : SUB);
			zone(px + 6, y, SIDE_W - 12, 18, v -> { cat = cc; search = ""; scroll = 0; }, null);
			y += 20;
		}

		// поиск
		int cx = px + SIDE_W + 8, cy = py + 8, cw = pw - SIDE_W - 16;
		rr(g, cx, cy, cw, 18, FIELD);
		String shown = search.isEmpty() && !focusSearch ? "Поиск" : search + (focusSearch ? "_" : "");
		txt(g, shown, cx + 6, cy + 5, search.isEmpty() ? SUB : TXT);
		zone(cx, cy, cw, 18, v -> focusSearch = true, null);

		// карточки со скроллом
		int top = cy + 24, viewH = py + ph - top - 6;
		g.enableScissor(cx, top, cx + cw, top + viewH);
		int yy = top - (int) scroll;
		int total = 0;
		for (Module m : visible()) {
			int h = cardH(m);
			drawCard(g, m, cx, yy, cw, h, top, top + viewH);
			yy += h + 4;
			total += h + 4;
		}
		g.disableScissor();
		contentH = total;
		float max = Math.max(0, total - viewH);
		if (scroll > max) scroll = max;
		if (scroll < 0) scroll = 0;
		if (total > viewH) { // полоса прокрутки
			int bh = Math.max(16, viewH * viewH / total);
			int by = top + (int) ((viewH - bh) * (scroll / max));
			g.fill(cx + cw - 2, by, cx + cw, by + bh, Draw.ACCENT | 0xFF000000);
		}
	}

	private void drawCard(GuiGraphicsExtractor g, Module m, int x, int y, int w, int h, int clipT, int clipB) {
		rr(g, x, y, w, h, CARD);
		boolean on = m.enabled;
		// переключатель
		rr(g, x + w - 30, y + 6, 22, 10, on ? Draw.ACCENT | 0xFF000000 : OFF);
		g.fill(on ? x + w - 18 : x + w - 28, y + 8, on ? x + w - 10 : x + w - 20, y + 14, 0xFFFFFFFF);
		txt(g, m.name, x + 8, y + 7, on ? TXT : SUB);
		String desc = m.description == null ? "" : m.description;
		int maxW = w - 40 - Minecraft.getInstance().font.width(m.name) - 20;
		if (maxW > 30 && !desc.isEmpty())
			txt(g, Minecraft.getInstance().font.plainSubstrByWidth(desc, maxW), x + 16 + Minecraft.getInstance().font.width(m.name), y + 7, OFF | 0xFF000000);
		if (y + HEAD > clipT && y < clipB) {
			zone(x, y, w - 34, HEAD, v -> m.toggle(), v -> {
				if (!expanded.remove(m)) expanded.add(m);
			});
			zone(x + w - 34, y, 34, HEAD, v -> m.toggle(), null);
		}
		if (!expanded.contains(m)) return;

		int ry = y + HEAD + 2;
		for (Object o : m.settings) {
			Setting s = (Setting) o;
			int rh = rowH(s);
			boolean vis = ry + rh > clipT && ry < clipB;
			int lx = x + 10, rw = w - 20;
			txt(g, s.name, lx, ry + 4, SUB);
			if (s instanceof Setting.Bool b) {
				boolean v = (Boolean) b.get();
				rr(g, x + w - 30, ry + 3, 20, 10, v ? Draw.ACCENT | 0xFF000000 : OFF);
				g.fill(v ? x + w - 20 : x + w - 28, ry + 5, v ? x + w - 12 : x + w - 20, ry + 11, 0xFFFFFFFF);
				if (vis) zone(lx, ry, rw, rh, d -> b.toggle(), null);
			} else if (s instanceof Setting.Num n) {
				String val = n.display();
				txt(g, val, x + w - 10 - Minecraft.getInstance().font.width(val), ry + 4, TXT);
				int bx = lx, bw = rw, by = ry + ROW - 1;
				g.fill(bx, by, bx + bw, by + 3, OFF);
				g.fill(bx, by, bx + (int) (bw * n.frac()), by + 3, Draw.ACCENT | 0xFF000000);
				if (vis) zone(bx, by - 3, bw, 9, d -> { dragX = bx; dragW = bw; dragging = f -> n.setFrom(f); n.setFrom(frac(d, bx, bw)); }, null);
			} else if (s instanceof Setting.Mode md) {
				String val = md.current();
				txt(g, val, x + w - 10 - Minecraft.getInstance().font.width(val), ry + 4, TXT);
				if (vis) zone(lx, ry, rw, rh, d -> md.setIndex((md.options.indexOf(md.current()) + 1) % md.options.size()), null);
			} else if (s instanceof Setting.Multi mu) {
				int oy = ry + ROW;
				for (Object oo : mu.options) {
					String opt = (String) oo;
					boolean has = mu.has(opt);
					rr(g, lx + 4, oy + 3, 10, 10, has ? Draw.ACCENT | 0xFF000000 : OFF);
					txt(g, opt, lx + 20, oy + 4, has ? TXT : SUB);
					if (vis) zone(lx, oy, rw, ROW, d -> mu.toggle(opt), null);
					oy += ROW;
				}
			} else if (s instanceof Setting.Color c) {
				g.fill(x + w - 22, ry + 3, x + w - 10, ry + 13, 0xFF000000 | c.argb());
				int bx = lx, bw = rw, by = ry + ROW + 1;
				for (int i = 0; i < bw; i++) g.fill(bx + i, by, bx + i + 1, by + 4, 0xFF000000 | hsv(i / (float) bw));
				if (vis) zone(bx, by - 2, bw, 8, d -> {
					dragX = bx; dragW = bw;
					dragging = f -> c.setHex(String.format("#%06X", hsv((float) f) & 0xFFFFFF));
					c.setHex(String.format("#%06X", hsv((float) frac(d, bx, bw)) & 0xFFFFFF));
				}, null);
			} else if (s instanceof Setting.Action a) {
				rr(g, lx, ry + 1, rw, ROW - 2, FIELD);
				txt(g, s.name, lx + 6, ry + 4, TXT);
				if (vis) zone(lx, ry, rw, rh, d -> a.run(), null);
			} else {
				String val = s.display();
				txt(g, val, x + w - 10 - Minecraft.getInstance().font.width(val), ry + 4, TXT);
			}
			ry += rh;
		}
	}

	private static double frac(double mouseX, int bx, int bw) {
		return Math.max(0, Math.min(1, (mouseX - bx) / bw));
	}

	private static int hsv(float h) {
		float sat = 0.85f, hh = (h - (float) Math.floor(h)) * 6f;
		int i = (int) hh;
		float f = hh - i, p = 1f - sat, q = 1f - sat * f, t = 1f - sat * (1f - f);
		float r, g, b;
		switch (i) {
			case 0 -> { r = 1; g = t; b = p; }
			case 1 -> { r = q; g = 1; b = p; }
			case 2 -> { r = p; g = 1; b = t; }
			case 3 -> { r = p; g = q; b = 1; }
			case 4 -> { r = t; g = p; b = 1; }
			default -> { r = 1; g = p; b = q; }
		}
		return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
		focusSearch = false;
		double mx = e.x(), my = e.y();
		for (int i = zones.size() - 1; i >= 0; i--) {
			int[] z = zones.get(i);
			if (mx >= z[0] && mx < z[0] + z[2] && my >= z[1] && my < z[1] + z[3]) {
				DoubleConsumer a = acts.get(i)[e.button() == 1 ? 1 : 0];
				if (a != null) {
					a.accept(mx);
					return true;
				}
			}
		}
		return super.mouseClicked(e, dbl);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
		if (dragging != null) {
			dragging.accept(frac(e.x(), dragX, dragW));
			return true;
		}
		return super.mouseDragged(e, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent e) {
		dragging = null;
		return super.mouseReleased(e);
	}

	@Override
	public boolean mouseScrolled(double x, double y, double sx, double sy) {
		scroll -= (float) sy * 18f;
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		int k = e.key();
		if (focusSearch) {
			if (k == 259 && !search.isEmpty()) search = search.substring(0, search.length() - 1); // Backspace
			else if (k == 256 || k == 257) focusSearch = false;                                   // Esc / Enter
			return true;
		}
		if (k == 256 || k == VClient.MENU_KEY) {
			onClose();
			return true;
		}
		return super.keyPressed(e);
	}

	@Override
	public boolean charTyped(CharacterEvent e) {
		if (focusSearch && search.length() < 24) {
			search += new String(Character.toChars(e.codepoint()));
			scroll = 0;
			return true;
		}
		return super.charTyped(e);
	}
}
